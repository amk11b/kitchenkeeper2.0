Placeholder Images:
    Lord.svg
    Brian.svg
    Ash.svg
    inventory.svg
    recipes.svg
    shopping.svg

Current KitchenKeeper Logo:
    kk_logo.svg

Hamburger Menu:
    bars-solid.svg

Generic React Logos:
    logo192.png
    logo512.png
