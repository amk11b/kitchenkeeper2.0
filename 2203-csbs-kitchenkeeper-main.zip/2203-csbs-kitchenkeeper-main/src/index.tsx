import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import * as serviceWorkerRegistration from './serviceWorkerRegistration';
import reportWebVitals from './reportWebVitals';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
import _adapter from 'webrtc-adapter';

import './index.css';
import App from './App';

import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';
import firebase from 'firebase/compat/app'
import 'firebase/compat/auth'
import 'firebase/compat/firestore'

import { combineReducers, createStore } from 'redux';
// import { configureStore } from '@reduxjs/toolkit'
import { Provider } from 'react-redux'
import { ReactReduxFirebaseProvider, firebaseReducer } from 'react-redux-firebase'
import { createFirestoreInstance, firestoreReducer } from 'redux-firestore';
import { composeWithDevTools } from '@redux-devtools/extension';

export const DEBUG = (!process.env.NODE_ENV || process.env.NODE_ENV === 'development');

(window as any).FIREBASE_APPCHECK_DEBUG_TOKEN = DEBUG;

const APP_CHECK_TOKEN = process.env.REACT_APP_APPCHECK_TOKEN!!;

const firebaseConfig = {
  apiKey: process.env.REACT_APP_FIREBASE_APIKEY,
  authDomain: 'kitchenkeeper-dev.firebaseapp.com',
  projectId: 'kitchenkeeper-dev',
  storageBucket: 'kitchenkeeper-dev.appspot.com',
  messagingSenderId: '943206888333',
  appId: '1:943206888333:web:a6f5aff067841f3c8003c4',
};

// react-redux-firebase config
const reactReduxFireConfig = {
  userProfile: 'users',
  useFirestoreForProfile: true // Firestore for Profile instead of Realtime DB
}

// Initialize firebase instance
const firebaseApp = firebase.initializeApp(firebaseConfig);
firebase.firestore() //.settings({ timestampsInSnapshots: true });

// Initialize AppCheck
initializeAppCheck(firebaseApp, {
  provider: new ReCaptchaV3Provider(APP_CHECK_TOKEN),
  isTokenAutoRefreshEnabled: true
});

// Add firebase to reducers
const rootReducer = combineReducers({
  firebase: firebaseReducer,
  firestore: firestoreReducer, // <- needed if using firestore
  // meals: mealsReducer
})

// Create store with reducers and initial state
const initialState = {}
export const store = createStore(rootReducer, initialState, composeWithDevTools());

// *** Not Compatible with Non-Serializable values ***
// // Create store with firebase and firestore reducers
// export const store = configureStore({
//   reducer: {
//     firebase: firebaseReducer,
//     firestore: firestoreReducer, // <- needed if using firestore
//   }
// });

// React Redux Firebase Props
const reactReduxFireProps = {
  firebase: firebaseApp,
  config: reactReduxFireConfig,
  dispatch: store.dispatch,
  createFirestoreInstance // <- needed if using firestore
}

// Render stuffs to dom
ReactDOM.render(
  <Provider store={store}>
    <ReactReduxFirebaseProvider {...reactReduxFireProps}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </ReactReduxFirebaseProvider>
  </Provider>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://cra.link/PWA
serviceWorkerRegistration.register();

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
