import { ChangeEvent, KeyboardEvent, MouseEvent, UIEvent } from "react";

export const RECIPE_CONFIRM_REMOVE = "Removing a recipe from your saves will reset the recipe to it's original state. Your ingredients will be unlinked and any changes you have made to the recipe will be reset.";

export enum RecipeCategories {
  Italian = 'Italian',
  American = 'American',
  Thai = 'Thai',
  Chinese = 'Chinese',
  Saved = 'Saved',
  Favorites = 'Favorites',
}

export const simplifiedUnits = [ 'mg', 'g', 'kg', 'oz', 'lb', 't', 'ml', 'l', 'tsp', 'Tbs', 'fl-oz', 'cup', 'pnt', 'qt', 'gal' ];

export interface filter {
  label: string;
  key: string;
  active: boolean;
  direction: 'asc' | 'desc';
}

export const defaultFilter: filter = {
  label: 'unknown',
  key: 'unknown',
  active: false,
  direction: 'desc'
}

export type LocationsStrings = keyof typeof Locations;

export enum Locations {
  Inventory = 'Inventory',
  Pantry = 'Pantry',
  Freezer = 'Freezer',
  Fridge = 'Fridge',
  Spices = 'Spices',
  Other = 'Other',
  All = 'All'
}

export type DaysStrings = keyof typeof Days;

export enum Days {
  SUNDAY = 'Sunday',
  MONDAY = 'Monday',
  TUESDAY = 'Tuesday',
  WEDNSDAY = 'Wednesday',
  THURSDAY = 'Thursday',
  FRIDAY = 'Friday',
  SATURDAY = 'Saturday'
}

export enum DnDType {
  ROW = 'ROW',
  COLUMN = 'COLUMN',
  COMPONENT = 'COMPONENT',
  ITEM = 'ITEM',
  RECIPE = 'RECIPE',
  NOTE = 'NOTE'
}

export type e_change = ChangeEvent<HTMLInputElement>;
export type e_change_textarea = ChangeEvent<HTMLTextAreaElement>;
export type e_key = KeyboardEvent<HTMLInputElement>;
export type e_click = MouseEvent<HTMLButtonElement>;
export type e_scroll = UIEvent<HTMLDivElement>;

export type mode = 'continuous' | 'manual';
export type limit = { max: number, min: number, step: number };
export type resizeMode = 'none' | 'crop-and-scale';

export interface MediaTrackCapabilitiesPlus extends MediaTrackCapabilities {
  torch?: boolean;
  brightness?: limit;
  colorTemperature?: limit;
  contrast?: limit;
  exposureCompensation?: limit;
  exposureMode?: Array<mode>;
  exposureTime?: limit;
  focusDistance?: limit;
  focusMode?: Array<mode>;
  resizeMode?: Array<resizeMode>;
  saturation?: limit;
  sharpness?: limit;
  whiteBalanceMode?: Array<mode>;
  zoom?: number;
}

export interface MediaTrackConstraintSetPlus extends MediaTrackConstraintSet {
  torch?: boolean;
  brightness?: number;
  colorTemperature?: number;
  contrast?: number;
  exposureCompensation?: number;
  exposureMode?: mode;
  exposureTime?: number;
  focusDistance?: number;
  focusMode?: mode;
  resizeMode?: resizeMode;
  saturation?: number;
  sharpness?: number;
  whiteBalanceMode?: mode;
  zoom?: number;
}