import { Timestamp } from "firebase/firestore";

export type IRecipes = Map<string, IRecipe>;

export type IDisplayRecipes = Map<string, IDisplayRecipe>;

export type RecipeSource = 'spoonacular' | 'custom';

export interface ICardRecipe {
  id: string | number;
  title: string;
  image: string;
}

export interface IDisplayRecipe {
  id: string;
  title: string;
  image: string;
  servings: number;
  multiplier: number;
}

export interface IRecipe {
  id: string;
  title: string;
  instructions?: string;
  image: string;
  servings: number;
  multiplier?: number;
  favorite: boolean;
  saved: boolean;
  source: RecipeSource;
  linked_products?: IIngredientProduct[];
  ingredients: IRecipeIngredient[];
  date_added: Timestamp;
}

export interface IRecipeIngredient {
  id: string;
  text: string;
  amount: number;
  unit: string;
  linked_products: IIngredientProduct[];
}

export interface IIngredient {
  id: string;
  linked_products: IIngredientProduct[];
}

export interface IIngredientProduct {
  id: string;
  title: string;
  amount: number;
  unit: string;
}

export type ISpoonacularRecipes = Map<string, ISpoonacularRecipe>;

export type ISpoonacularSearchRecipes = Map<string, ISpoonacularSearchRecipe>;

export type ISpoonacularRecipeSearchResults = { data: { results: ISpoonacularSearchRecipe[] }};

export interface ISpoonacularSearchRecipe {
  id: number;
  title: string;
  image: string;
  imageType: string;
}

export interface ISpoonacularRecipe {
  id: number;
  title: string;
  image: string;
  imageType: string;
  servings: number;
  readyInMinutes: number;
  license: string;
  sourceName: string;
  sourceUrl: string;
  spoonacularSourceUrl: string;
  aggregateLikes?: number;
  healthScore?: number;
  spoonacularScore?: number;
  pricePerServing?: number;
  analyzedInstructions: ISpoonacularAnalyzedInstruction[];
  cheap?: boolean;
  creditsText?: string;
  cuisines: string[];
  dairyFree?: boolean;
  diets: string[];
  gaps?: string;
  glutenFree?: boolean;
  instructions: string;
  ketogenic?: boolean;
  lowFodmap?: boolean;
  occasions: string[];
  sustainable?: boolean;
  vegan?: boolean;
  vegetarian?: boolean;
  veryHealthy?: boolean;
  veryPopular?: boolean;
  whole30?: boolean;
  weightWatcherSmartPoints?:  number;
  dishTypes: string[];
  extendedIngredients: ISpoonacularExtendedIngredient[];
  summary: string;
  winePairing: ISpoonacularWinePairing;
  favorite?: boolean;
  cookingMinutes?: number;
  openLicense?: number;
  originalId?: string | null;
  preparationMinutes?: number;
}

export interface ISpoonacularAnalyzedInstruction {
  name: string;
  steps: ISpoonacularAnalyzedStep[];
}

export interface ISpoonacularAnalyzedStep {
  number: number;
  step: string;
  ingredients: ISpoonacularAnalyzedObject[];
  equipment: ISpoonacularAnalyzedObject[];
  length?: { number: number, unit: string };
}

export interface ISpoonacularAnalyzedObject {
  id: number;
  image: string;
  localizedName: string;
  name: string;
  temperature?: { 
    number: number,
    unit: string
  }
}

export interface ISpoonacularExtendedIngredient {
  aisle: string;
  amount: number;
  consistency: ESpoonacularConsitency;
  id: number;
  image: string;
  measures: ISpoonacularMeasures;
  meta: string[];
  name: string;
  nameClean: string;
  original: string;
  originalName: string;
  unit: string;
}

export type ESpoonacularConsitency = 'SOLID' | 'LIQUID'

export interface ISpoonacularMeasures {
  metric: ISpoonacularMeasure;
  us: ISpoonacularMeasure;
}

export interface ISpoonacularMeasure {
  amount: number;
  unitLong: string;
  unitShort:  string;
}

export interface ISpoonacularWinePairing {
  pairedWines?: string[];
  pairingText?: string;
  productMatches?: ISpoonacularProductMatch[];
}

export interface ISpoonacularProductMatch {
  id: number;
  title: string;
  description: string;
  price: string;
  imageUrl: string;
  averageRating:  number;
  ratingCount: number;
  score: number;
  link: string;
}
