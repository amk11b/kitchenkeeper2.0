import { FieldValue } from 'firebase/firestore';
import { Product as OFFProduct } from 'openfoodfac-ts/dist/OpenFoodFactsApi/types';
import { filter, Locations, defaultFilter } from './types';
import { rng16 } from '../helpers/mini';

export interface ProductFilters {
  product_name: filter;
  package_count: filter;
  brand: filter;
  labels: filter;
  expirations: filter;
  location: Locations;
}

export const DefaultProductFilters: ProductFilters = {
  product_name: {...defaultFilter, key: 'product_name', label: 'Name', active: true },
  package_count:  {...defaultFilter, key: 'package_count', label: 'Count' },
  brand: {...defaultFilter, key: 'brand', label: 'Brand' },
  labels: {...defaultFilter, key: 'labels', label: 'Labels' },
  expirations: {...defaultFilter, key: 'expirations', label: 'Expiration' },
  location: Locations.All
} 

export interface IItem {
  id: string;
  title: string;
  sub_title?: string;
  img_url?: string;
}

export interface IProduct {
  code: string;
  offid: null | string;
  tags: null | string;
  product_name: string;
  package_size: null | string;
  package_size_unit: null | string;
  package_count: number;
  desired_count?: number;
  image_url: null | string;
  categories: null | string;
  brand: null | string;
  image_ingredients_url: null | string;
  ingredients: null | string;
  traces: null | string;
  labels: null | string;
  expirations: null | string[];
  location: Locations;
  track_expiration: boolean;
  keywords: string[];
}

export interface IOrderedProduct extends IProduct {
  id: string;
}

export interface IDisplayProduct {
  code: string;
  product_name: string;
  package_count: number;
  image_url: null | string;
  package_size: null | string;
  package_size_unit: null | string;
  expirations?: null | string[];
}

export interface IDisplayProductExtended extends IDisplayProduct {
  badge?: 'new' | 'edited' | 'recent' | 'scan';
}

export interface IShoppingItem {
  code: string;
  note?: string;
  product_name?: string;
  package_count?: number;
  image_url?: null | string;
  location?: Locations;
  complete?: boolean;
}

export interface IScannerProduct extends IProduct {
  new?: boolean;
  saved?: boolean;
}

export const DefaultProduct: IProduct = {
  code: '',
  location: Locations.Other,
  package_count: 1,
  product_name: '',
  offid: null,
  tags: null,
  package_size: null,
  package_size_unit: null,
  image_url: null,
  categories: null,
  brand: null,
  image_ingredients_url: null,
  ingredients: null,
  traces: null,
  labels: null,
  expirations: null,
  track_expiration: false,
  keywords: []
};

export const getProductDefault = () => ({ ...DefaultProduct, code: rng16() });

export type IProducts = Map<string, IProduct>;
export type IDisplayProducts = Map<string, IDisplayProduct>;
export type IDisplayProductsExtended = Map<string, IDisplayProductExtended>;
export type IScannerProducts = Map<string, IScannerProduct>;
export type IShoppingProducts = Map<string, IShoppingItem>;
export type IProductsUpdate = Map<string, IProduct | FieldValue>;

export const genKeywords = (input: string[]): string[] => {
  const text = input.join(' ');
  if (!text.trim()) return [];
  const keywords = text.toLocaleLowerCase().split(/[^a-zA-Z\d:]/gi).filter(Boolean);
  return Array.from(new Set(keywords));
}

export function fromOFFP(offp: OFFProduct): IProduct {
  let keywords = genKeywords(offp._keywords ?? []);
  keywords = genKeywords([offp.product_name_en ?? '']);
  return ({
    ...DefaultProduct,
    code: offp.code ?? rng16(),
    offid: offp._id ?? null,
    product_name: offp.product_name_en ?? 'Name not found',
    package_size: offp.quantity?.replace(/\D+/, '') ?? null,
    package_size_unit: offp.quantity?.replace(/\d+/g, '').toLocaleLowerCase() ?? null,
    image_url: offp.image_url ?? null,
    categories: offp.categories ?? null,
    brand: offp.brands ?? null,
    image_ingredients_url: offp.image_ingredients_url ?? null,
    ingredients: offp.ingredients_text_en ?? null,
    traces: offp.traces_from_ingredients ?? null,
    keywords: keywords ?? []
  });
}
