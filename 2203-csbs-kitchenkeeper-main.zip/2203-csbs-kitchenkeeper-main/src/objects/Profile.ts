export interface IProfile {
  dataId: string;
  unitSystem: 'metric' | 'imperial';
  expiration_notice: number;
  expiration_notification: boolean;
}