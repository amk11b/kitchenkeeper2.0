import { FieldValue } from 'firebase/firestore';
import { IDisplayProduct } from './Product';
import { IDisplayRecipe } from './Recipe';

export interface IMealCore {
  id: string;
  parentId: string;
  index: number;
  item?: IDisplayProduct;
  recipe?: IDisplayRecipe;
  note?: string;
  made?: boolean;
  remove_on_make: boolean;
}

export type IMealsData = Map<string, IMealCore>;
export type IMealsUpdate = Map<string, IMealCore | FieldValue>;