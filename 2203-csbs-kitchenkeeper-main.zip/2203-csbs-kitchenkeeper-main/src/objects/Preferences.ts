
export class Preferences {
  dataId: undefined | string;
  unitSystem: undefined | 'metric' | 'imperial';
}