import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Axios from 'axios';
import RecipesContainer from './RecipesContainer';
import { ISpoonacularSearchRecipe } from '../../objects/Recipe';

export default function Results() {
  const [recipes, setRecipes] = useState<ISpoonacularSearchRecipe[]>([]);
  const [currentSearch, setCurrentSearch] = useState('');
  const [anError, setAnError] = useState(false);
  const [noResults, setNoResults] = useState(false);
  const params = useParams();

  const getRecipes = async (search: string) => {
    setNoResults(false);
    setAnError(false);
    const response = await Axios.get(`https://api.spoonacular.com/recipes/complexSearch?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&query=${search}`);
    const results = response.data?.results;
    if (!results) return setAnError(true);
    setRecipes(results);
    if (!results.length) setNoResults(true);
  };

  useEffect(() => {
    if (params.search && currentSearch !== params.search) {
      setCurrentSearch(params.search);
      getRecipes(params.search);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.search]);

  return <RecipesContainer recipes={recipes} anError={anError} noResults={noResults} />;
}
