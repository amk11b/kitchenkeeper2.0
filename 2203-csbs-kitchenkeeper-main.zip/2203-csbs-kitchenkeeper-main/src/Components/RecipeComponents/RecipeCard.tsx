import { NavLink } from 'react-router-dom';

export interface PRecipeCard {
  title: string;
  id: string;
  image: string;
  className?: string;
  disableNav?: boolean;
}

export default function RecipeCard({ title, image, id, className, disableNav }: PRecipeCard) {
  const handleClick = (e: any) => disableNav && e.preventDefault();
  return (
    <NavLink onClick={handleClick} to={'/recipes/details/' + id}>
      <div className={'position-relative overflow-hidden shadow ' + className ?? ''} style={{ minHeight: '22rem', width: '18rem', borderRadius: '2rem' }}>
        <img src={image} alt='RecipeImage' className='w-100 h-100 position-absolute start-0' style={{ objectFit: 'cover' }} />
        <span className='position-absolute start-0 end-0 top-0 bottom-0 card-text-bgshadow' />
        <span className='position-absolute bottom-0 w-100 text-center p-3 fw-bold text-white'>{title}</span>
      </div>
    </NavLink>
  );
}
