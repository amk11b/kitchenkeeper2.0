import { useEffect, useState } from 'react';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import '@splidejs/react-splide/css';
import useLocalStorageState from 'use-local-storage-state';
import Axios from 'axios';
import RecipeCard from './RecipeCard';
import LoadingSpinner from '../loadingSpinner';
import { ISpoonacularRecipe } from '../../objects/Recipe';
import moment from 'moment';

export default function Suggested() {
  const [suggestedRecipes, setSuggestedRecipes] = useLocalStorageState<ISpoonacularRecipe[]>('SuggestedRecipes', { defaultValue: [] });
  const [suggestedRecipesLastUpdate, setSuggestedRecipesLastUpdate] = useLocalStorageState('SuggestedRecipesLastUpdate', { defaultValue: moment().format('l') });
  const [anError, setAnError] = useState(false);
  const [noResults, setNoResults] = useState(false);

  useEffect(() => {
    const getSuggested = async () => {
      const response = await Axios.get(`https://api.spoonacular.com/recipes/random?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&number=20`);
      console.log(response);
      const results = response.data?.recipes;
      if (results) setSuggestedRecipes(results);
      if (!results) return setAnError(true);
      if (!results.length) setNoResults(true);
    };

    if (suggestedRecipes.length && moment(suggestedRecipesLastUpdate).isSame(moment(), 'day')) return;

    getSuggested();

    setSuggestedRecipesLastUpdate(moment().format('l'));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!suggestedRecipes.length && !anError && !noResults) return <LoadingSpinner />;

  return (
    <div className='py-4'>
      <Splide
        options={{
          autoplay: true,
          interval: 25000,
          type: 'slide',
          rewind: true,
          rewindByDrag: true,
          speed: 999,
          start: 6,
          focus: 'center',
          arrows: false,
          drag: 'free',
          gap: '1rem',
          fixedWidth: '18rem',
          height: '25rem',
          padding: { left: '15rem', right: '15rem' },
        }}>
        {suggestedRecipes.map((recipe, index) => (
          <SplideSlide key={recipe.id + '-' + index}>
            <RecipeCard title={recipe.title} image={recipe.image} id={recipe.id.toString()} />
          </SplideSlide>
        ))}
      </Splide>
    </div>
  );
}
