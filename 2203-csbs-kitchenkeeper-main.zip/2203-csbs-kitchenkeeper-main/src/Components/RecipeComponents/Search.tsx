import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, FormControl, InputGroup } from 'react-bootstrap';
import { faSearch, faTimes } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { e_key, e_change } from '../../objects/types';

export default function Search() {
  const [input, setInput] = useState('');
  const [showClear, setShowClear] = useState(false);
  const navigate = useNavigate();

  const search = () => navigate('/recipes/results/' + input);
  const keyDown = (e: e_key) => {
    if (e.key === 'Enter') search();
  };
  const clearInput = () => {
    setInput('');
    setShowClear(false);
  };
  const inputChange = (e: e_change) => {
    setInput(e.currentTarget.value.trim());
    setShowClear(!!e.currentTarget.value.trim());
  };

  return (
    <div className='position-relative w-100'>
      <InputGroup>
        <FormControl
          placeholder='Search for New Recipes'
          aria-label='Search existing Pantry Items'
          onChange={inputChange}
          onKeyDown={keyDown}
          value={input}
        />
        <Button variant='primary px-4' onClick={search}>
          <FontAwesomeIcon icon={faSearch} />
        </Button>
      </InputGroup>
      {showClear && (
        <Button
          variant=''
          className='position-absolute top-0'
          style={{ right: '66px', zIndex: 5 }}
          onClick={clearInput}>
          <FontAwesomeIcon className='text-muted' icon={faTimes} />
        </Button>
      )}
    </div>
  );
}
