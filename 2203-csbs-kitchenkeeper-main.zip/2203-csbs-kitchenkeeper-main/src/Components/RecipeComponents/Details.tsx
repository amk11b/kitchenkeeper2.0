import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import Axios from 'axios';
import LoadingSpinner from '../loadingSpinner';
import { Button, ButtonGroup } from 'react-bootstrap';
import { cleanStr } from '../../helpers/mini';
import { IRecipe, ISpoonacularRecipe } from '../../objects/Recipe';
import { ToastNotification } from '../ToastNotification';
import { ViewTab } from '../Modals/AddRecipeModal';
import { useFirestore } from 'react-redux-firebase';
import { useSelector } from 'react-redux';
import { Timestamp } from 'firebase/firestore';
import ConfirmationModal from '../Modals/ConfirmationModal';
import { RECIPE_CONFIRM_REMOVE } from '../../objects/types';

export default function Details() {
  const params = useParams();
  const firestore = useFirestore();
  const profile = useSelector((state: any) => state.firebase.profile);
  const [recipe, setRecipe] = useState<IRecipe>();
  const [tab, setTab] = useState<ViewTab>('instructions');
  const [confirmRemoveState, setConfirmRemoveState] = useState(false);
  const [errorState, setErrorState] = useState(false);
  const [loading, setLoading] = useState(false);

  const recipeId = params.id;
  
  useEffect(() => {
    if (!recipeId) return;
    if (recipeId === recipe?.id.toString()) return;
    fetchRecipe(recipeId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [recipeId]);

  const fetchRecipe = async (recipeId: string) => {
    setLoading(true);
    const firestoreResponse = await firestore.get(`data/${profile.dataId}/recipes/${recipeId}`);
    console.log(firestoreResponse);
    
    if (firestoreResponse.exists) {
      const data = firestoreResponse.data();
      if (!data) return viewError();
      const recipeResult = firestoreResponse.data() as IRecipe;
      setRecipe(recipeResult);
    } else {
      const spoonacularResponse = await Axios.get(`https://api.spoonacular.com/recipes/${recipeId}/information?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}`);
      const recipeResult: ISpoonacularRecipe = spoonacularResponse.data;
      if (!recipeResult) return viewError();
      const recipe: IRecipe = {
        id: recipeResult.id.toString(),
        title: recipeResult.title,
        instructions: cleanStr(recipeResult.instructions),
        image: recipeResult.image,
        servings: recipeResult.servings,
        favorite: false,
        saved: false,
        source: 'custom',
        ingredients: [],
        date_added: Timestamp.now(),
      };
      recipeResult.extendedIngredients.forEach((ingredient) => {
        recipe.ingredients.push({
          id: ingredient.id.toString(),
          text: ingredient.nameClean,
          amount: ingredient.amount,
          unit: ingredient.unit,
          linked_products: [],
        });
      });
      setRecipe(recipe);
    }
    setLoading(false);
  };

  const toggleFavorite = () => {
    if (!recipe || !recipe.id) return viewError();
    setLoading(true);
    try {
      firestore.update(`data/${profile.dataId}/recipes/${recipe.id}`, { favorite: !recipe.favorite });
      setRecipe({...recipe, favorite: !recipe.favorite });
    } catch (error) {
      console.warn(error);
      viewError();
    }
    setLoading(false);
  };

  const toggleSave = () => {
    if (!recipe || !recipe.id) return viewError();
    if (recipe.saved && !confirmRemoveState) return setConfirmRemoveState(true);
    setLoading(true);
    try {
      if (recipe.saved && confirmRemoveState) {
        firestore.delete(`data/${profile.dataId}/recipes/${recipe.id}`);
        setRecipe({...recipe, saved: false, favorite: false });
      } else {
        firestore.set(`data/${profile.dataId}/recipes/${recipe.id}`, {...recipe, saved: true });
        setRecipe({...recipe, saved: true });
      }
    } catch (error) {
      console.warn(error);
      viewError();
    }
    setConfirmRemoveState(false);
    setLoading(false);
  };

  const hideConfirmDelete = () => setConfirmRemoveState(false);
  const viewError = () => setErrorState(true);

  if (!recipe) return <LoadingSpinner />;

  return (
    <>
      <ConfirmationModal show={confirmRemoveState} onHide={hideConfirmDelete} onConfirm={toggleSave} text={RECIPE_CONFIRM_REMOVE} title='Confirm Removal' />
      <ToastNotification show={errorState} onHide={() => setErrorState(false)} />

      {loading && <LoadingSpinner />}

      <div className='d-none d-xl-block mx-auto'>
        <div className='m-5 p-4 d-flex justify-content-center'>
          <div className='flex-shrink-0'>
            <img src={recipe.image} alt='RecipeImage' className='img-fluid align-self-start' style={{ maxWidth: '36rem', borderRadius: '2rem' }} />
          </div>
          <div className='flex-grow-1 ms-5 vstack gap-4 position-relative' style={{ maxWidth: '50rem' }}>
            <div className='position-absolute top-0' style={{ right: '1.5rem' }}>
              <button className='border-0 fs-5 bg-transparent' onClick={toggleFavorite}>
                {!recipe.favorite && recipe.saved && (
                  <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                    <path d='M244 84L255.1 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 0 232.4 0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84C243.1 84 244 84.01 244 84L244 84zM255.1 163.9L210.1 117.1C188.4 96.28 157.6 86.4 127.3 91.44C81.55 99.07 48 138.7 48 185.1V190.9C48 219.1 59.71 246.1 80.34 265.3L256 429.3L431.7 265.3C452.3 246.1 464 219.1 464 190.9V185.1C464 138.7 430.4 99.07 384.7 91.44C354.4 86.4 323.6 96.28 301.9 117.1L255.1 163.9z' />
                  </svg>
                )}
                {recipe.favorite && recipe.saved && (
                  <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                    <path d='M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z' />
                  </svg>
                )}
              </button>
              <button className='border-0 fs-5 bg-transparent' onClick={toggleSave}>
                {!recipe.saved && (
                  <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                    <path d='M336 0h-288C21.49 0 0 21.49 0 48v431.9c0 24.7 26.79 40.08 48.12 27.64L192 423.6l143.9 83.93C357.2 519.1 384 504.6 384 479.9V48C384 21.49 362.5 0 336 0zM336 452L192 368l-144 84V54C48 50.63 50.63 48 53.1 48h276C333.4 48 336 50.63 336 54V452z' />
                  </svg>
                )}
                {recipe.saved && (
                  <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                    <path d='M384 48V512l-192-112L0 512V48C0 21.5 21.5 0 48 0h288C362.5 0 384 21.5 384 48z' />
                  </svg>
                )}
              </button>
            </div>
            <span className='fs-4 fw-bold text-muted'>{recipe.title}</span>
            <ButtonGroup>
              <Button variant={tab === 'instructions' ? 'primary' : 'secondary'} onClick={() => setTab('instructions')}>
                Instructions
              </Button>
              <Button variant={tab === 'ingredients' ? 'primary' : 'secondary'} onClick={() => setTab('ingredients')}>
                Ingredients
              </Button>
            </ButtonGroup>
            {tab === 'instructions' && <span>{recipe.instructions}</span>}
            {tab === 'ingredients' && (
              <ul className='list-group list-group-flush list-group-numbered'>
                {recipe.ingredients.map((ingredient, index) => (
                  <li className='list-group-item' key={ingredient.id + '-' + index}>
                    &emsp;{ingredient.amount}
                    <sub>{ingredient.unit}</sub>
                    &emsp;{ingredient.text}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className='d-block d-xl-none'>
        <div className='my-5 py-4'>
          <div className='text-center mx-auto' style={{ maxWidth: '36rem' }}>
            <img src={recipe.image} alt='RecipeImage' className='img-fluid px-2 mx-auto d-none d-sm-block' style={{ borderRadius: '2rem' }} />
            <img src={recipe.image} alt='RecipeImage' className='img-fluid px-0 mx-0 d-sm-none' />
          </div>
          <div className='vstack gap-4 w-100 my-4 px-4 mx-auto position-relative' style={{ maxWidth: '50rem' }}>
            <div className='position-absolute top-0' style={{ right: '1.5rem' }}>
              <button className='border-0 fs-5 bg-transparent' onClick={toggleFavorite}>
                {!recipe.favorite && recipe.saved && (
                  <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                    <path d='M244 84L255.1 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 0 232.4 0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84C243.1 84 244 84.01 244 84L244 84zM255.1 163.9L210.1 117.1C188.4 96.28 157.6 86.4 127.3 91.44C81.55 99.07 48 138.7 48 185.1V190.9C48 219.1 59.71 246.1 80.34 265.3L256 429.3L431.7 265.3C452.3 246.1 464 219.1 464 190.9V185.1C464 138.7 430.4 99.07 384.7 91.44C354.4 86.4 323.6 96.28 301.9 117.1L255.1 163.9z' />
                  </svg>
                )}
                {recipe.favorite && recipe.saved && (
                  <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                    <path d='M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z' />
                  </svg>
                )}
              </button>
              <button className='border-0 fs-5 bg-transparent' onClick={toggleSave}>
                {!recipe.saved && (
                  <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                    <path d='M336 0h-288C21.49 0 0 21.49 0 48v431.9c0 24.7 26.79 40.08 48.12 27.64L192 423.6l143.9 83.93C357.2 519.1 384 504.6 384 479.9V48C384 21.49 362.5 0 336 0zM336 452L192 368l-144 84V54C48 50.63 50.63 48 53.1 48h276C333.4 48 336 50.63 336 54V452z' />
                  </svg>
                )}
                {recipe.saved && (
                  <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                    <path d='M384 48V512l-192-112L0 512V48C0 21.5 21.5 0 48 0h288C362.5 0 384 21.5 384 48z' />
                  </svg>
                )}
              </button>
            </div>
            <span className='fs-4 fw-bold text-muted mt-2'>{recipe.title}</span>
            <ButtonGroup>
              <Button variant={tab === 'instructions' ? 'primary' : 'secondary'} onClick={() => setTab('instructions')}>
                Instructions
              </Button>
              <Button variant={tab === 'ingredients' ? 'primary' : 'secondary'} onClick={() => setTab('ingredients')}>
                Ingredients
              </Button>
            </ButtonGroup>
            {tab === 'instructions' && <span>{recipe.instructions}</span>}
            {tab === 'ingredients' && (
              <ul className='list-group list-group-flush list-group-numbered'>
                {recipe.ingredients.map((ingredient, index) => (
                  <li className='list-group-item' key={ingredient.id + '-' + index}>
                    &emsp;{ingredient.amount}
                    <sub>{ingredient.unit}</sub>
                    &emsp;{ingredient.text}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
