import { FaPizzaSlice, FaHamburger, FaHeart, FaBookmark } from 'react-icons/fa';
import { GiNoodles, GiChopsticks } from 'react-icons/gi';
import { NavLink, useLocation } from 'react-router-dom';
import { RecipeCategories } from '../../objects/types';

export default function Categories() {
  const location = useLocation();

  const categories = [
    { label: RecipeCategories.Italian, icon: <FaPizzaSlice />, route: '/recipes/cuisine/' + RecipeCategories.Italian },
    { label: RecipeCategories.American, icon: <FaHamburger />, route: '/recipes/cuisine/' + RecipeCategories.American },
    { label: RecipeCategories.Thai, icon: <GiNoodles />, route: '/recipes/cuisine/' + RecipeCategories.Thai },
    { label: RecipeCategories.Chinese, icon: <GiChopsticks />, route: '/recipes/cuisine/' + RecipeCategories.Chinese },
    { label: RecipeCategories.Saved, icon: <FaBookmark />, route: '/recipes/cuisine/' + RecipeCategories.Saved },
    { label: RecipeCategories.Favorites, icon: <FaHeart />, route: '/recipes/cuisine/' + RecipeCategories.Favorites },
  ];

  return (
    <div className='d-flex flex-wrap justify-content-center gap-4'>
      {categories.map((category, index) => (
        <NavLink
          key={index + '-' + category.route}
          to={category.route}
          style={{ width: '4.5rem', height: '4.5rem' }}
          className={
            'position-relative rounded-circle text-decoration-none text-white ' +
            (location.pathname === category.route ? 'bg-primary' : 'bg-secondary')
          }>
          <span className='position-absolute start-50 translate-middle-x' style={{ fontSize: '1.6rem', top: '0.1rem' }}>
            {category.icon}
          </span>
          <span
            className='position-absolute start-50 translate-middle-x'
            style={{ fontSize: '0.8em', bottom: '0.9rem' }}>
            {category.label}
          </span>
        </NavLink>
      ))}
    </div>
  );
}
