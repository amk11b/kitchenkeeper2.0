import RecipeCard from './RecipeCard';
import LoadingSpinner from '../loadingSpinner';
import { ICardRecipe } from '../../objects/Recipe';

export interface PRecipesContainer {
  recipes: ICardRecipe[];
  noResults?: boolean;
  anError?: boolean;
}

export default function RecipesContainer({ recipes, noResults, anError }: PRecipesContainer) {
  return (
    <div className='p-4 d-flex align-content-start justify-content-evenly flex-wrap gap-5'>
      {recipes.map((recipe, index) => (
        <RecipeCard key={recipe.title + index} title={recipe.title} image={recipe.image} id={recipe.id.toString()} />
      ))}
      {anError && <span className='fs-5 fs-bold text-muted'>An error occurred.</span>}
      {noResults && <span className='fs-5 fs-bold text-muted'>No results available.</span>}
      {!recipes.length && !noResults && <LoadingSpinner />}
    </div>
  );
}
