import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Axios from 'axios';
import RecipesContainer from './RecipesContainer';
import { IRecipe, ISpoonacularRecipeSearchResults, ISpoonacularSearchRecipe } from '../../objects/Recipe';
import { Timestamp } from 'firebase/firestore';
import { useFirestore, ReduxFirestoreQuerySetting } from 'react-redux-firebase';
import { useSelector } from 'react-redux';
import { RecipeCategories } from '../../objects/types';
import LoadingSpinner from '../loadingSpinner';
import { Button } from 'react-bootstrap';
import { ToastNotification } from '../ToastNotification';

interface IRecipesHandler {
  Italian: ISpoonacularSearchRecipe[];
  Italian_after: number;
  American: ISpoonacularSearchRecipe[];
  American_after: number;
  Thai: ISpoonacularSearchRecipe[];
  Thai_after: number;
  Chinese: ISpoonacularSearchRecipe[];
  Chinese_after: number;
  Saved: IRecipe[];
  Saved_after: Timestamp | undefined;
  Favorites: IRecipe[];
  Favorites_after: Timestamp | undefined;
}

export default function Cuisine() {
  const firestore = useFirestore();
  const profile = useSelector((state: any) => state.firebase.profile);
  const [currentType, setCurrentType] = useState('');
  const [errorState, setErrorState] = useState(false);
  const [loading, setLoading] = useState(false);
  const params = useParams();

  const [recipes, setRecipes] = useState<IRecipesHandler>({
    Italian: [],
    Italian_after: 0,
    American: [],
    American_after: 0,
    Thai: [],
    Thai_after: 0,
    Chinese: [],
    Chinese_after: 0,
    Saved: [],
    Saved_after: undefined,
    Favorites: [],
    Favorites_after: undefined,
  });

  const resultCount = 25;

  const more_italian = !(recipes.Italian.length % resultCount);
  const more_american = !(recipes.American.length % resultCount);
  const more_thai = !(recipes.Thai.length % resultCount);
  const more_chinese = !(recipes.Chinese.length % resultCount);
  const more_saved = !(recipes.Saved.length % resultCount);
  const more_favorites = !(recipes.Favorites.length % resultCount);

  let showLoadMore = false;

  if (currentType === RecipeCategories.Italian && more_italian && !!recipes.Italian.length) showLoadMore = true;
  if (currentType === RecipeCategories.American && more_american && !!recipes.American.length) showLoadMore = true;
  if (currentType === RecipeCategories.Thai && more_thai && !!recipes.Thai.length) showLoadMore = true;
  if (currentType === RecipeCategories.Chinese && more_chinese && !!recipes.Chinese.length) showLoadMore = true;
  if (currentType === RecipeCategories.Saved && more_saved && !!recipes.Saved.length) showLoadMore = true;
  if (currentType === RecipeCategories.Favorites && more_favorites && !!recipes.Favorites.length) showLoadMore = true;

  let url_italian   = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&cuisine=italian&offset=${recipes.Italian_after}&number=${recipes.Italian_after + resultCount}`;
  let url_american  = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&cuisine=american&offset=${recipes.American_after}&number=${recipes.American_after + resultCount}`;
  let url_thai      = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&cuisine=thai&offset=${recipes.Thai_after}&number=${recipes.Thai_after + resultCount}`;
  let url_chinese   = `https://api.spoonacular.com/recipes/complexSearch?apiKey=${process.env.REACT_APP_SPOONACULAR_APIKEY}&cuisine=chinese&offset=${recipes.Chinese_after}&number=${recipes.Chinese_after + resultCount}`;

  let base_firestore: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'recipes' }], orderBy: ['date_added', 'desc'], limit: resultCount };
  let url_firestore: ReduxFirestoreQuerySetting = {...base_firestore, startAfter: recipes.Saved_after, storeAs: 'RecipeSaveResults' };
  let url_favorites: ReduxFirestoreQuerySetting = {...base_firestore, where: [['favorite', '==', true]], startAfter: recipes.Favorites_after, storeAs: 'FavoriteSearchResults' };

  useEffect(() => {
    if (!params.type) return;
    if (params.type === currentType) return;
    setCurrentType(params.type);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.type]);
  useEffect(() => {    
    if (currentType === RecipeCategories.Italian && !recipes.Italian.length) fetchRecipes();
    if (currentType === RecipeCategories.American && !recipes.American.length) fetchRecipes();
    if (currentType === RecipeCategories.Thai && !recipes.Thai.length) fetchRecipes();
    if (currentType === RecipeCategories.Chinese && !recipes.Chinese.length) fetchRecipes();
    if (currentType === RecipeCategories.Saved && !recipes.Saved.length) fetchRecipes();
    if (currentType === RecipeCategories.Favorites && !recipes.Favorites.length) fetchRecipes();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentType]);

  const fetchRecipes = async () => {
    setLoading(true);
    try {
      if (currentType === RecipeCategories.Saved && more_saved) {
        const response: any = await firestore.get(url_firestore);
        if (!response.docs.length) return setErrorState(true);
        const recipeResults: IRecipe[] = response.docs.map((doc: any) => doc.data());
        recipes.Saved_after = recipeResults.at(-1)?.date_added ?? undefined;
        if (recipes.Saved_after) setRecipes({...recipes, Saved: [...recipes.Saved, ...recipeResults] });
        if (!recipes.Saved_after) setRecipes({...recipes, Saved: recipeResults });
        return;
      }

      if (currentType === RecipeCategories.Favorites && more_favorites) {
        const response: any = await firestore.get(url_favorites);
        if (!response.docs.length) return setErrorState(true);
        const recipeResults: IRecipe[] = response.docs.map((doc: any) => doc.data());
        recipes.Favorites_after = recipeResults.at(-1)?.date_added ?? undefined;
        if (recipes.Favorites_after) setRecipes({...recipes, Favorites: [...recipes.Favorites, ...recipeResults] });
        if (!recipes.Favorites_after) setRecipes({...recipes, Favorites: recipeResults });
        return;
      }

      if (currentType === RecipeCategories.Italian && more_italian) {
        const response: ISpoonacularRecipeSearchResults = await Axios.get(url_italian);
        if (!response.data.results.length) return setErrorState(true);
        recipes.Italian_after = recipes.Italian_after + resultCount;
        if (recipes.Italian_after) setRecipes({...recipes, Italian: [...recipes.Italian, ...response.data.results] });
        if (!recipes.Italian_after) setRecipes({...recipes, Italian: response.data.results });
        return;
      }

      if (currentType === RecipeCategories.American && more_american) {
        const response: ISpoonacularRecipeSearchResults = await Axios.get(url_american);
        if (!response.data.results.length) return setErrorState(true);
        recipes.American_after = recipes.American_after + resultCount;
        if (recipes.American_after) setRecipes({...recipes, American: [...recipes.American, ...response.data.results] });
        if (!recipes.American_after) setRecipes({...recipes, American: response.data.results });
        return;
      }

      if (currentType === RecipeCategories.Thai && more_thai) {
        const response: ISpoonacularRecipeSearchResults = await Axios.get(url_thai);
        if (!response.data.results.length) return setErrorState(true);
        recipes.Thai_after = recipes.Thai_after + resultCount;
        if (recipes.Thai_after) setRecipes({...recipes, Thai: [...recipes.Thai, ...response.data.results] });
        if (!recipes.Thai_after) setRecipes({...recipes, Thai: response.data.results });
        return;
      }

      if (currentType === RecipeCategories.Chinese && more_chinese) {
        const response: ISpoonacularRecipeSearchResults = await Axios.get(url_chinese);
        if (!response.data.results.length) return setErrorState(true);
        recipes.Chinese_after = recipes.Chinese_after + resultCount;
        if (recipes.Chinese_after) setRecipes({...recipes, Chinese: [...recipes.Chinese, ...response.data.results] });
        if (!recipes.Chinese_after) setRecipes({...recipes, Chinese: response.data.results });
        return;
      }

    } catch (error) {
      console.warn(error);
      setErrorState(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <ToastNotification show={errorState} onHide={() => setErrorState(false)} />

      { loading && <LoadingSpinner /> }

      { currentType === RecipeCategories.Italian && <RecipesContainer recipes={recipes.Italian} /> }
      { currentType === RecipeCategories.American && <RecipesContainer recipes={recipes.American} /> }
      { currentType === RecipeCategories.Thai && <RecipesContainer recipes={recipes.Thai} /> }
      { currentType === RecipeCategories.Chinese && <RecipesContainer recipes={recipes.Chinese} /> }
      { currentType === RecipeCategories.Saved && <RecipesContainer recipes={recipes.Saved} /> }
      { currentType === RecipeCategories.Favorites && <RecipesContainer recipes={recipes.Favorites} /> }

      { showLoadMore && <Button variant='primary' className='d-block mx-auto' style={{ width: '25rem' }} onClick={fetchRecipes}>Load More</Button> }
    </>
  );
}
