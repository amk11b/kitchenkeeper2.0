import { Button, ButtonGroup, FormControl, InputGroup, Modal } from 'react-bootstrap';
import { useState, useEffect } from 'react';
import { IRecipe, IRecipes } from '../../objects/Recipe';
import { ToastNotification } from '../ToastNotification';
import LoadingSpinner from '../loadingSpinner';
import { faSearch, faTimes } from '@fortawesome/free-solid-svg-icons';
import { useSelector } from 'react-redux';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { e_change, e_key, RECIPE_CONFIRM_REMOVE } from '../../objects/types';
import { Timestamp } from 'firebase/firestore';
import { genKeywords } from '../../objects/Product';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import ConfirmationModal from './ConfirmationModal';

export interface PAddRecipeCard {
  title: string;
  image: string;
  onClick?: () => void;
  className?: string;
}

export function AddRecipeCard({ className, title, image, onClick }: PAddRecipeCard) {
  return (
    <div className={'position-relative overflow-hidden shadow ' + className ?? ''} style={{ height: '7rem', width: '22rem', borderRadius: '1rem' }} onClick={onClick}>
      <img src={image} alt='RecipeImage' className='w-100 h-100 position-absolute start-0' style={{ objectFit: 'cover' }} />
      <span className='position-absolute start-0 end-0 top-0 bottom-0 card-text-bgshadow' />
      <span className='position-absolute bottom-0 w-100 ps-3 py-2 fw-bold text-white'>{title}</span>
    </div>
  );
}

export type RecipeTab = 'favorites' | 'saved';
export type ViewTab = 'instructions' | 'ingredients';

export interface PAddRecipeModal {
  show: boolean;
  onHide: () => void;
  resultCallback: (recipe: IRecipe) => void;
}

export default function AddRecipeModal({ show, onHide, resultCallback }: PAddRecipeModal) {
  const firestore = useFirestore();
  const profile = useSelector((state: any) => state.firebase.profile);
  const [recipes_favorites, setFavorites] = useState<IRecipes>(new Map());
  const [recipes_saved, setSaved] = useState<IRecipes>(new Map());
  const [recipeTab, setRecipeTab] = useState<RecipeTab>('favorites');
  const [viewRecipe, setViewRecipe] = useState<IRecipe | undefined>();
  const [errorState, setErrorState] = useState(false);
  const [after_saved, setAfter_saved] = useState<Timestamp | undefined>();
  const [after_favorites, setAfter_favorites] = useState<Timestamp | undefined>();
  const [input, setInput] = useState('');
  const [confirmRemoveState, setConfirmRemoveState] = useState(false);
  const [detailsTab, setDetailsTab] = useState<ViewTab>('instructions');
  const [detailsLoading, setDetailsLoading] = useState(false);


  const keywords = genKeywords([input]);

  const showClear = !!input.trim();

  const resultCount = 25;

  const more_saved = !(recipes_saved.size % resultCount);
  const more_favorites = !(recipes_favorites.size % resultCount);

  let showLoadMore = false;

  if (recipeTab === 'favorites' && !!recipes_favorites.size && more_favorites) showLoadMore = true;
  if (recipeTab === 'saved' && !!recipes_saved.size && more_saved) showLoadMore = true;

  let base_firestore: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'recipes' }], orderBy: ['date_added', 'desc'], limit: resultCount };
  let url_firestore: ReduxFirestoreQuerySetting = { ...base_firestore, ...keywords.length && { where: [['keywords', 'array-contains-any', keywords]] }, startAfter: after_saved, storeAs: 'RecipeSearchResults' };
  let url_favorites: ReduxFirestoreQuerySetting = { ...base_firestore, where: [['favorite', '==', true]], startAfter: after_favorites, storeAs: 'FavoriteSearchResults' };

  useEffect(() => {
    fetchRecipes('favorites');
    fetchRecipes('saved');
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => hideViewRecipe(), [recipeTab]);
  useEffect(() => show ? hideViewRecipe() : undefined, [show]);

  const confirmRecipe = () => resultCallback(viewRecipe!);
  const hideViewRecipe = () => setViewRecipe(undefined);
  const clearInput = () => setInput('');
  const inputChange = (e: e_change) => setInput(e.currentTarget.value);
  const keyDown = (e: e_key) => e.key === 'Enter' && cleanAndFetch();

  const cleanAndFetch = () => {
    if (recipeTab === 'favorites') setAfter_favorites(undefined);
    if (recipeTab === 'saved') setAfter_saved(undefined);
    setViewRecipe(undefined);
    fetchRecipes();
  };

  const viewError = () => {
    setViewRecipe(undefined);
    setErrorState(true);
  };

  const toggleFavorite = () => {
    try {
      if (!viewRecipe) return viewError();
      firestore.update(`data/${profile.dataId}/recipes/${viewRecipe.id}`, { favorite: !viewRecipe.favorite });
      setViewRecipe({ ...viewRecipe, favorite: !viewRecipe.favorite });
    } catch (error) {
      console.warn(error);
      viewError();
    }
  };

  const toggleSave = () => {
    if (!viewRecipe || !viewRecipe.id) return viewError();
    if (viewRecipe.saved && !confirmRemoveState) return setConfirmRemoveState(true);
    setDetailsLoading(true);
    try {
      if (viewRecipe.saved && confirmRemoveState) {
        firestore.delete(`data/${profile.dataId}/recipes/${viewRecipe.id}`);
        setViewRecipe({...viewRecipe, saved: false, favorite: false });
      } else {
        firestore.set(`data/${profile.dataId}/recipes/${viewRecipe.id}`, {...viewRecipe, saved: true });
        setViewRecipe({...viewRecipe, saved: true });
      }
    } catch (error) {
      console.warn(error);
      viewError();
    }
    setConfirmRemoveState(false);
    setDetailsLoading(false);
  };

  const hideConfirmDelete = () => setConfirmRemoveState(false);

  const fetchRecipes = async (tabOverride?: RecipeTab) => {
    try {
      if ((tabOverride ?? recipeTab) === 'saved' && more_saved) {
        const response: any = await firestore.get(url_firestore);
        if (!response.docs.length) return;
        const recipeResults: IRecipes = new Map();
        response.docs.forEach((doc: any) => recipeResults.set(doc.id, doc.data()));
        setAfter_saved(response.docs.at(-1).data().date_added ?? undefined);
        if (after_saved) setSaved(new Map([...recipes_saved, ...recipeResults]));
        if (!after_saved) setSaved(recipeResults);
        return;
      }

      if ((tabOverride ?? recipeTab) === 'favorites' && more_favorites) {
        if (keywords.length) url_favorites.where?.push(['keywords', 'array-contains-any', keywords]);
        const response: any = await firestore.get(url_favorites);
        if (!response.docs.length) return;
        const recipeResults: IRecipes = new Map();
        response.docs.forEach((doc: any) => recipeResults.set(doc.id, doc.data()));
        setAfter_favorites(response.docs.at(-1).data().date_added ?? undefined);
        if (after_favorites) setFavorites(new Map([...recipes_favorites, ...recipeResults]));
        if (!after_favorites) setFavorites(recipeResults);
        return;
      }
    } catch (error) {
      console.warn(error);
      viewError();
    }
  };

  const setupViewRecipe = async (recipeId: string) => {
    setDetailsLoading(true);
    const firestoreResponse = await firestore.get(`data/${profile.dataId}/recipes/${recipeId}`);
    if (!firestoreResponse.exists) return viewError();
    const data = firestoreResponse.data();
    if (!data) return viewError();
    const recipeResult = firestoreResponse.data() as IRecipe;
    setViewRecipe(recipeResult);
    setDetailsLoading(false);
  };

  const favoritesCards: JSX.Element[] = [];
  const savedCards: JSX.Element[] = [];

  recipes_favorites.forEach((recipe, key) => {
    favoritesCards.push(<AddRecipeCard key={key} title={recipe.title} image={recipe.image} onClick={() => setupViewRecipe(recipe.id)} className='my-3' />);
  });

  recipes_saved.forEach((recipe, key) => {
    savedCards.push(<AddRecipeCard key={key} title={recipe.title} image={recipe.image} onClick={() => setupViewRecipe(recipe.id)} className='my-3' />);
  });

  return (
    <>
      <ConfirmationModal show={confirmRemoveState} onHide={hideConfirmDelete} onConfirm={toggleSave} text={RECIPE_CONFIRM_REMOVE} title='Confirm Removal' />
      <ToastNotification show={errorState} onHide={() => setErrorState(false)} />

      <Modal show={show && !confirmRemoveState} onHide={onHide} scrollable>
        <Modal.Header>
          <div className='position-relative w-100'>
            <InputGroup className='w-100'>
              <FormControl placeholder='Search...' aria-label='Search existing Pantry Items' autoFocus onChange={inputChange} onKeyDown={keyDown} value={input} />
              <Button variant='primary px-4' onClick={cleanAndFetch}>
                <FontAwesomeIcon icon={faSearch} />
              </Button>
            </InputGroup>
            {showClear && (
              <Button variant='' className='position-absolute top-0' style={{ right: '66px', zIndex: 5 }} onClick={clearInput}>
                <FontAwesomeIcon className='text-muted' icon={faTimes} />
              </Button>
            )}
            <ButtonGroup className='w-100 px-5 mt-2'>
              <Button variant={recipeTab === 'favorites' ? 'primary' : 'secondary'} onClick={() => setRecipeTab('favorites')}>
                Favorites
              </Button>
              <Button variant={recipeTab === 'saved' ? 'primary' : 'secondary'} onClick={() => setRecipeTab('saved')}>
                Saved
              </Button>
            </ButtonGroup>
          </div>
        </Modal.Header>
        {detailsLoading && <LoadingSpinner />}
        <Modal.Body className='scrollable-shadowed p-0 ' style={{ height: !!viewRecipe ? 0 : '80vh', maxHeight: '600px' }}>
          <div className='mx-auto' style={{ width: '22rem' }}>
            {recipeTab === 'favorites' && favoritesCards}
            {recipeTab === 'saved' && savedCards}
            {recipeTab === 'favorites' && !favoritesCards.length && <span className='position-absolute top-50 start-50 translate-middle text-muted'>No favorite recipes available</span>}
            {recipeTab === 'saved' && !savedCards.length && <span className='position-absolute top-50 start-50 translate-middle text-muted'>No saved recipes available</span>}

            {showLoadMore && (
              <Button variant={showLoadMore ? 'outline-primary' : 'outline-secondary'} disabled={!showLoadMore} className='w-100 my-4 btn-primary-only-onHover' onClick={() => fetchRecipes()}>
                Load More
              </Button>
            )}
          </div>
        </Modal.Body>
        <Modal.Body className='p-0 bg-white' style={{ height: !!viewRecipe ? '80vh' : 0, maxHeight: '600px' }}>
          {!!viewRecipe && (
            <>
              <img src={viewRecipe.image} alt='RecipeImage' style={{ maxHeight: '22rem', width: '100%' }} />
              <div className='vstack gap-4 w-100 mx-auto' style={{ maxWidth: '46rem', padding: '1.5rem 2rem' }}>
                <div className='position-relative'>
                  <span className='fs-4 fw-bold text-muted'>{viewRecipe.title}</span>
                  <div className='position-absolute end-0 top-0'>
                    <button className='border-0 fs-5 bg-transparent' onClick={toggleFavorite}>
                      {!viewRecipe.favorite && viewRecipe.saved && (
                        <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                          <path d='M244 84L255.1 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 0 232.4 0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84C243.1 84 244 84.01 244 84L244 84zM255.1 163.9L210.1 117.1C188.4 96.28 157.6 86.4 127.3 91.44C81.55 99.07 48 138.7 48 185.1V190.9C48 219.1 59.71 246.1 80.34 265.3L256 429.3L431.7 265.3C452.3 246.1 464 219.1 464 190.9V185.1C464 138.7 430.4 99.07 384.7 91.44C354.4 86.4 323.6 96.28 301.9 117.1L255.1 163.9z' />
                        </svg>
                      )}
                      {viewRecipe.favorite && viewRecipe.saved && (
                        <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                          <path d='M0 190.9V185.1C0 115.2 50.52 55.58 119.4 44.1C164.1 36.51 211.4 51.37 244 84.02L256 96L267.1 84.02C300.6 51.37 347 36.51 392.6 44.1C461.5 55.58 512 115.2 512 185.1V190.9C512 232.4 494.8 272.1 464.4 300.4L283.7 469.1C276.2 476.1 266.3 480 256 480C245.7 480 235.8 476.1 228.3 469.1L47.59 300.4C17.23 272.1 .0003 232.4 .0003 190.9L0 190.9z' />
                        </svg>
                      )}
                    </button>
                    <button className='border-0 fs-5 bg-transparent' onClick={toggleSave}>
                      {!viewRecipe.saved && (
                        <svg fill='#6c757d' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                          <path d='M336 0h-288C21.49 0 0 21.49 0 48v431.9c0 24.7 26.79 40.08 48.12 27.64L192 423.6l143.9 83.93C357.2 519.1 384 504.6 384 479.9V48C384 21.49 362.5 0 336 0zM336 452L192 368l-144 84V54C48 50.63 50.63 48 53.1 48h276C333.4 48 336 50.63 336 54V452z' />
                        </svg>
                      )}
                      {viewRecipe.saved && (
                        <svg fill='#DC8B32' aria-hidden focusable={false} className='svg-inline--fa' role='img' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'>
                          <path d='M384 48V512l-192-112L0 512V48C0 21.5 21.5 0 48 0h288C362.5 0 384 21.5 384 48z' />
                        </svg>
                      )}
                    </button>
                  </div>
                </div>
                <ButtonGroup>
                  <Button variant={detailsTab === 'instructions' ? 'primary' : 'secondary'} onClick={() => setDetailsTab('instructions')}>
                    Instructions
                  </Button>
                  <Button variant={detailsTab === 'ingredients' ? 'primary' : 'secondary'} onClick={() => setDetailsTab('ingredients')}>
                    Ingredients
                  </Button>
                </ButtonGroup>
                {detailsTab === 'instructions' && <span>{viewRecipe.instructions}</span>}
                {detailsTab === 'ingredients' && (
                  <ul className='list-group list-group-flush list-group-numbered'>
                    {viewRecipe.ingredients.map((ingredient, index) => (
                      <li className='list-group-item' key={ingredient.id + '-' + index}>
                        &emsp;{ingredient.amount}
                        <sub>{ingredient.unit}</sub>
                        &emsp;{ingredient.text}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          {!viewRecipe && (
            <Button variant='secondary' onClick={onHide}>
              Back
            </Button>
          )}
          {!!viewRecipe && (
            <Button variant='secondary' onClick={hideViewRecipe}>
              Cancel
            </Button>
          )}
          {!!viewRecipe && viewRecipe.saved && (
            <Button variant='primary' onClick={confirmRecipe}>
              Confirm
            </Button>
          )}
        </Modal.Footer>
      </Modal>
    </>
  );
}

// export const TempSpoonacularRecipe: ISpoonacularRecipe = {
//   vegetarian: false,
//   vegan: false,
//   glutenFree: false,
//   dairyFree: false,
//   veryHealthy: false,
//   cheap: false,
//   veryPopular: false,
//   sustainable: false,
//   lowFodmap: false,
//   weightWatcherSmartPoints: 9,
//   gaps: 'no',
//   preparationMinutes: -1,
//   cookingMinutes: -1,
//   aggregateLikes: 1,
//   healthScore: 3,
//   creditsText: 'Foodista.com – The Cooking Encyclopedia Everyone Can Edit',
//   license: 'CC BY 3.0',
//   sourceName: 'Foodista',
//   pricePerServing: 58.84,
//   extendedIngredients: [
//     {
//       id: 20081,
//       aisle: 'Baking',
//       image: 'flour.png',
//       consistency: 'SOLID',
//       name: 'all purpose flour',
//       nameClean: 'wheat flour',
//       original: 'cup All Purpose Flour – 2 500mL',
//       originalName: 'All Purpose Flour – 2 500mL',
//       amount: 1,
//       unit: 'cup',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'cup',
//           unitLong: 'cup',
//         },
//         metric: {
//           amount: 236.588,
//           unitShort: 'ml',
//           unitLong: 'milliliters',
//         },
//       },
//     },
//     {
//       id: 18010,
//       aisle: 'Baking',
//       image: 'buttermilk-biscuits.jpg',
//       consistency: 'SOLID',
//       name: 'baking mix',
//       nameClean: 'baking mix',
//       original: 'tablespoon Baking Power – 1 15 mL',
//       originalName: 'Baking Power – 1 15 mL',
//       amount: 1,
//       unit: 'tablespoon',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'Tbsp',
//           unitLong: 'Tbsp',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'Tbsp',
//           unitLong: 'Tbsp',
//         },
//       },
//     },
//     {
//       id: 18372,
//       aisle: 'Baking',
//       image: 'white-powder.jpg',
//       consistency: 'SOLID',
//       name: 'baking soda',
//       nameClean: 'baking soda',
//       original: 'teaspoon Baking Soda – ½ 2mL',
//       originalName: 'Baking Soda – ½ 2mL',
//       amount: 1,
//       unit: 'teaspoon',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//       },
//     },
//     {
//       id: 2047,
//       aisle: 'Spices and Seasonings',
//       image: 'salt.jpg',
//       consistency: 'SOLID',
//       name: 'salt',
//       nameClean: 'table salt',
//       original: 'teaspoon Salt – ½ 2mL',
//       originalName: 'Salt – ½ 2mL',
//       amount: 1,
//       unit: 'teaspoon',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//       },
//     },
//     {
//       id: 2044,
//       aisle: 'Produce',
//       image: 'fresh-basil.jpg',
//       consistency: 'SOLID',
//       name: 'basil',
//       nameClean: 'fresh basil',
//       original: 'teaspoon Dried Basil – ½ 2mL',
//       originalName: 'Dried Basil – ½ 2mL',
//       amount: 1,
//       unit: 'teaspoon',
//       meta: ['dried'],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//       },
//     },
//     {
//       id: 2027,
//       aisle: 'Produce;Spices and Seasonings',
//       image: 'oregano.jpg',
//       consistency: 'SOLID',
//       name: 'oregano',
//       nameClean: 'oregano',
//       original: 'teaspoon Dried Oregano – ½ 2mL',
//       originalName: 'Dried Oregano – ½ 2mL',
//       amount: 1,
//       unit: 'teaspoon',
//       meta: ['dried'],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//       },
//     },
//     {
//       id: 1022020,
//       aisle: 'Spices and Seasonings',
//       image: 'garlic-powder.png',
//       consistency: 'SOLID',
//       name: 'garlic powder',
//       nameClean: 'garlic powder',
//       original: 'teaspoon Garlic Powder – ½ 2mL',
//       originalName: 'Garlic Powder – ½ 2mL',
//       amount: 1,
//       unit: 'teaspoon',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'tsp',
//           unitLong: 'teaspoon',
//         },
//       },
//     },
//     {
//       id: 1123,
//       aisle: 'Milk, Eggs, Other Dairy',
//       image: 'egg.png',
//       consistency: 'SOLID',
//       name: 'egg',
//       nameClean: 'egg',
//       original: 'Large Egg – 1',
//       originalName: 'Large Egg – 1',
//       amount: 1,
//       unit: '',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: '',
//           unitLong: '',
//         },
//         metric: {
//           amount: 1,
//           unitShort: '',
//           unitLong: '',
//         },
//       },
//     },
//     {
//       id: 1077,
//       aisle: 'Milk, Eggs, Other Dairy',
//       image: 'milk.png',
//       consistency: 'LIQUID',
//       name: 'milk',
//       nameClean: 'milk',
//       original: 'cup Milk – 1 250mL',
//       originalName: 'Milk – 1 250mL',
//       amount: 1,
//       unit: 'cup',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'cup',
//           unitLong: 'cup',
//         },
//         metric: {
//           amount: 236.588,
//           unitShort: 'ml',
//           unitLong: 'milliliters',
//         },
//       },
//     },
//     {
//       id: 4582,
//       aisle: 'Oil, Vinegar, Salad Dressing',
//       image: 'vegetable-oil.jpg',
//       consistency: 'LIQUID',
//       name: 'cooking oil',
//       nameClean: 'cooking oil',
//       original: 'cup Cooking Oil – ¼ 60mL',
//       originalName: 'Cooking Oil – ¼ 60mL',
//       amount: 1,
//       unit: 'cup',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'cup',
//           unitLong: 'cup',
//         },
//         metric: {
//           amount: 236.588,
//           unitShort: 'ml',
//           unitLong: 'milliliters',
//         },
//       },
//     },
//     {
//       id: 19335,
//       aisle: 'Baking',
//       image: 'sugar-in-bowl.png',
//       consistency: 'SOLID',
//       name: 'granulated sugar',
//       nameClean: 'sugar',
//       original: 'tablespoon Granulated Sugar – 2 30mL',
//       originalName: 'Granulated Sugar – 2 30mL',
//       amount: 1,
//       unit: 'tablespoon',
//       meta: [],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'Tbsp',
//           unitLong: 'Tbsp',
//         },
//         metric: {
//           amount: 1,
//           unitShort: 'Tbsp',
//           unitLong: 'Tbsp',
//         },
//       },
//     },
//     {
//       id: 11531,
//       aisle: 'Canned and Jarred',
//       image: 'tomatoes-canned.png',
//       consistency: 'SOLID',
//       name: 'canned diced tomatoes',
//       nameClean: 'canned diced tomatoes',
//       original: 'Diced Tomatoes – 1/2 can',
//       originalName: 'Diced Tomatoes – 1/2 can',
//       amount: 0.5,
//       unit: 'can',
//       meta: ['diced'],
//       measures: {
//         us: {
//           amount: 0.5,
//           unitShort: 'can',
//           unitLong: 'cans',
//         },
//         metric: {
//           amount: 0.5,
//           unitShort: 'can',
//           unitLong: 'cans',
//         },
//       },
//     },
//     {
//       id: 1041009,
//       aisle: 'Cheese',
//       image: 'cheddar-cheese.png',
//       consistency: 'SOLID',
//       name: 'cheese',
//       nameClean: 'cheese',
//       original: 'cup Grated Cheese – ⅔ (or more!) 150mL',
//       originalName: 'Grated Cheese – ⅔ (or more!) 150mL',
//       amount: 1,
//       unit: 'cup',
//       meta: ['grated', '(!)'],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'cup',
//           unitLong: 'cup',
//         },
//         metric: {
//           amount: 236.588,
//           unitShort: 'ml',
//           unitLong: 'milliliters',
//         },
//       },
//     },
//     {
//       id: 7057,
//       aisle: 'Meat',
//       image: 'pepperoni.png',
//       consistency: 'SOLID',
//       name: 'pepperoni',
//       nameClean: 'pepperoni',
//       original: 'ounce Pepperoni Stick – 2 ½ (or more!) 70g (cut up into squares)',
//       originalName: 'Pepperoni Stick – 2 ½ (or more!) 70g (cut up into squares)',
//       amount: 1,
//       unit: 'ounce',
//       meta: ['(!)', '(cut up into squares)'],
//       measures: {
//         us: {
//           amount: 1,
//           unitShort: 'oz',
//           unitLong: 'ounce',
//         },
//         metric: {
//           amount: 28.35,
//           unitShort: 'g',
//           unitLong: 'grams',
//         },
//       },
//     },
//   ],
//   id: 655698,
//   title: 'Pepperoni Pizza Muffins',
//   readyInMinutes: 45,
//   servings: 6,
//   sourceUrl: 'https://www.foodista.com/recipe/ZBB4CYW8/pepperoni-pizza-muffins',
//   openLicense: -1,
//   image: 'https://spoonacular.com/recipeImages/655698-556x370.jpg',
//   imageType: 'jpg',
//   summary:
//     'Pepperoni Pizza Muffins might be just the <b>Mediterranean</b> recipe you are searching for. This recipe serves 6 and costs 59 cents per serving. This breakfast has <b>270 calories</b>, <b>11g of protein</b>, and <b>15g of fat</b> per serving. It is brought to you by Foodista. 1 person were impressed by this recipe. If you have cup all purpose flour - 2 500ml, teaspoon garlic powder - ½ 2ml, egg, and a few other ingredients on hand, you can make it. From preparation to the plate, this recipe takes roughly <b>roughly 45 minutes</b>. Taking all factors into account, this recipe <b>earns a spoonacular score of 25%</b>, which is rather bad. If you like this recipe, you might also like recipes such as <a href="https://spoonacular.com/recipes/pepperoni-pizza-muffins-519589">Pepperoni Pizza Muffins</a>, <a href="https://spoonacular.com/recipes/pepperoni-pizza-muffins-390711">Pepperoni Pizza Muffins</a>, and <a href="https://spoonacular.com/recipes/pepperoni-pizza-muffins-768964">Pepperoni Pizza Muffins</a>.',
//   cuisines: ['Mediterranean', 'Italian', 'European'],
//   dishTypes: ['morning meal', 'brunch', 'breakfast'],
//   diets: [],
//   occasions: [],
//   winePairing: {},
//   instructions:
//     'Measure first 7 dry ingredients into a large bowl.  Stir.  Make a well in the centre.  Combine the next 4 ingredients in a medium bowl.  Add to well.  Add tomato, cheese, and pepperoni to well.  Stir until just moistened.  Fill 12 greased muffin cups 3/4 full. (I had extra mix, so I made mini muffins too!) Bake in a 3750F (1900C) oven for about 20 minutes until a wooden pick inserted into the center of the muffin comes clean.  Let stand in pan for about 5 minutes before removing to wire rack to cool.',
//   analyzedInstructions: [
//     {
//       name: '',
//       steps: [
//         {
//           number: 1,
//           step: 'Measure first 7 dry ingredients into a large bowl.  Stir.  Make a well in the centre.',
//           ingredients: [],
//           equipment: [
//             {
//               id: 404783,
//               name: 'bowl',
//               localizedName: 'bowl',
//               image: 'bowl.jpg',
//             },
//           ],
//         },
//         {
//           number: 2,
//           step: 'Combine the next 4 ingredients in a medium bowl.',
//           ingredients: [],
//           equipment: [
//             {
//               id: 404783,
//               name: 'bowl',
//               localizedName: 'bowl',
//               image: 'bowl.jpg',
//             },
//           ],
//         },
//         {
//           number: 3,
//           step: 'Add to well.',
//           ingredients: [],
//           equipment: [],
//         },
//         {
//           number: 4,
//           step: 'Add tomato, cheese, and pepperoni to well.  Stir until just moistened.  Fill 12 greased muffin cups 3/4 full. (I had extra mix, so I made mini muffins too!)',
//           ingredients: [
//             {
//               id: 7057,
//               name: 'pepperoni',
//               localizedName: 'pepperoni',
//               image: 'pepperoni.png',
//             },
//             {
//               id: 1041009,
//               name: 'cheese',
//               localizedName: 'cheese',
//               image: 'cheddar-cheese.png',
//             },
//             {
//               id: 11529,
//               name: 'tomato',
//               localizedName: 'tomato',
//               image: 'tomato.png',
//             },
//           ],
//           equipment: [
//             {
//               id: 404676,
//               name: 'muffin liners',
//               localizedName: 'muffin liners',
//               image: 'muffin-or-cupcake-forms.png',
//             },
//           ],
//         },
//         {
//           number: 5,
//           step: 'Bake in a 3750F (1900C) oven for about 20 minutes until a wooden pick inserted into the center of the muffin comes clean.',
//           ingredients: [],
//           equipment: [
//             {
//               id: 404784,
//               name: 'oven',
//               localizedName: 'oven',
//               image: 'oven.jpg',
//               temperature: {
//                 number: 3750,
//                 unit: 'Fahrenheit',
//               },
//             },
//           ],
//           length: {
//             number: 20,
//             unit: 'minutes',
//           },
//         },
//         {
//           number: 6,
//           step: 'Let stand in pan for about 5 minutes before removing to wire rack to cool.',
//           ingredients: [],
//           equipment: [
//             {
//               id: 405900,
//               name: 'wire rack',
//               localizedName: 'wire rack',
//               image: 'wire-rack.jpg',
//             },
//             {
//               id: 404645,
//               name: 'frying pan',
//               localizedName: 'frying pan',
//               image: 'pan.png',
//             },
//           ],
//           length: {
//             number: 5,
//             unit: 'minutes',
//           },
//         },
//       ],
//     },
//   ],
//   originalId: null,
//   spoonacularSourceUrl: 'https://spoonacular.com/pepperoni-pizza-muffins-655698',
// };
