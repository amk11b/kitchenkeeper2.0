import { useCallback, useLayoutEffect, useState, useEffect, ChangeEvent, useRef, MutableRefObject } from 'react';
import { ToggleButton, ButtonGroup, Button, Modal } from 'react-bootstrap';
import Quagga, { MediaTrackConstraintsWithDeprecated, QuaggaJSResultObject } from '@ericblade/quagga2';
import { faGear, faBolt, faCircleExclamation, faCalendarXmark, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import useLocalStorageState from 'use-local-storage-state'
import { IScannerProduct, IScannerProducts, fromOFFP, IProduct, DefaultProduct } from '../../objects/Product';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import { increment } from 'firebase/firestore';
import OpenFoodFactsApi from 'openfoodfac-ts';
import LoadingSpinner from '../loadingSpinner';
import { ProductConverter } from '../../helpers/converters';
import { e_click, MediaTrackCapabilitiesPlus, MediaTrackConstraintSetPlus } from '../../objects/types';
import ProductDetailsModal from './ProductDetailsModal';
import ExpirationsModal from './ExpirationsModal';

// Modal

export interface PScannerModal {
  show: boolean;
  path: ReduxFirestoreQuerySetting;
  onHide: () => void;
  resultCallback?: (products: IScannerProducts) => void;
}

export default function ScannerModal({ show, onHide, path, resultCallback }: PScannerModal) {
  const [detailsProduct, setDetailsProduct] = useState<IProduct>(DefaultProduct);
  const [expirationsProduct, setExpirationsProduct] = useState<IScannerProduct>(DefaultProduct);
  const [scans, setScans] = useState<IScannerProducts>(new Map());
  const [upc, setUpc] = useState('');
  const [detailsState, setDetailsState] = useState(false);
  const [expirationsState, setExpirationsState] = useState(false);
  const [showCamOptions, setCamOpt] = useState(false);
  const [placeholder, setPlaceholder] = useState(false);
  const [loading, setLoading] = useState(false);
  const [check, setCheck] = useState(false);
  const [notice, setNotice] = useState(false);
  const [calendar, setCalendar] = useState(false);
  const [upload, setUpload] = useState(false);
  let pause = placeholder || loading || check || notice || calendar;
  const openFoodFactsApi = new OpenFoodFactsApi();
  const firestore = useFirestore();

  useEffect(() => {
    if (upc) saveScan();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [upc]);

  const saveScan = async () => {
    if (!upc) return;
    setLoading(true);
    const scanned = scans.get(upc);
    if (scanned) {
      scans.set(upc, {...scanned, package_count: scanned.package_count + 1 });
      scanned.track_expiration ? setCalendar(true) : setCheck(true);
    } else {
      setPlaceholder(true);
      // Get product from inventory if possible, otherwise get from open food facts
      const inventoryProduct = await firestore.get({...path, subcollections: [{ collection: 'products', doc: upc, storeAs: 'scan-' + upc }] });
      if (inventoryProduct.exists) {
        scans.set(upc, {...ProductConverter.fromFirestore(inventoryProduct.data()), package_count: 1 });
        setCheck(true);
      } else {
        const offproduct = await openFoodFactsApi.findProductByBarcode(upc);
        if (offproduct) {
          scans.set(upc, {...fromOFFP(offproduct), code: upc, package_count: 1, new: true });
          setNotice(true);
        } else {
          scans.set(upc, {...DefaultProduct, code: upc, new: true });
          setNotice(true);
        }
      }
    }
  
    setPlaceholder(false);
    setLoading(false);
    setTimeout(() => {
      setCheck(false);
      setNotice(false);
      setCalendar(false);
      setUpc('');
    }, 3750);
  }

  const saveScans = () => {
    setLoading(true);
    const batch = firestore.batch();
    scans.forEach(product => {
      const docRef = firestore.collection('data').doc(path.doc).collection('products').doc(product.code)
      if (product.new) {
        const newProduct = {...product};
        delete newProduct.new;
        delete newProduct.saved;
        batch.set(docRef, newProduct);
      }
      else
        batch.update(docRef, { package_count: increment(product.package_count), expirations: product.expirations });
    });
    
    setUpload(true);
    batch.commit().then(() => {
      setCheck(true);
      resultCallback?.(scans);
      setTimeout(() => {
        setCheck(false);
        setNotice(false);
        onHide();
      }, 3750);
    }).catch((error) => {
      console.warn(error);
    }).finally(() => {
      scans.clear();
      setLoading(false);
      setUpload(false);
    });
  }

  const saveProduct = (product: IProduct) => {
    const scanProduct = scans.get(product.code);
    if (!scanProduct) return;
    scans.set(product.code, { ...scanProduct, ...product, saved: true });
    setDetailsState(false);
  }

  const saveExpirations = (expirations: string[]) => {
    scans.set(expirationsProduct.code, {...expirationsProduct, expirations: expirations });
    setExpirationsState(false);
  }

  const noticeActions = (upc: string, actions: notices) => {
    const product = scans.get(upc);
    if (!product) return;
    if (actions.includes('incomplete')) {
      setDetailsProduct(product);
      setDetailsState(true);
    } else if (actions.includes('expiration')) {
      setExpirationsProduct(product);
      setExpirationsState(true);
    }
  }

  const removeScan = (upc: string) => {
    setTimeout(() => {
      scans.delete(upc);
      setScans(new Map(scans));
    }, 1000);
  }

  const hideDetails = () => {
    setDetailsProduct(DefaultProduct);
    setDetailsState(false);
  }

  return (
    <>
      <ProductDetailsModal show={ detailsState && !expirationsState } path={ path } edit={ true } onHide={ hideDetails } onRemove={ removeScan } onSave={ saveProduct } product_data={ detailsProduct } />
      <ExpirationsModal show={ expirationsState } expirations={ detailsProduct.expirations ?? undefined } count={ detailsProduct.package_count } onHide={ () => setExpirationsState(false) } onSubmit={ saveExpirations } />

      <Modal show={ show && !detailsState && !expirationsState } onHide={ onHide }>
        <Modal.Body>
          { loading && <LoadingSpinner style={{ zIndex: 11 }} /> }
          { check && <div className='notice__wrapper' style={{ zIndex: 11 }}>
            <svg className='notice__base checkmarkNotice notice__svg-primary' viewBox='0 0 52 52'>
              <circle className='notice__circleBase notice__circle-primary' cx='26' cy='26' r='25' fill='none'/>
              <path className='checkmarkNotice__check' fill='none' d='M14.1 27.2l7.1 7.2 16.7-16.8'/>
            </svg>
          </div> }
          { notice && <div className='notice__wrapper' style={{ zIndex: 11 }}>
            <svg className='notice__base notice__svg-danger' viewBox='0 0 52 52'>
              <circle className='notice__circleBase notice__circle-danger' cx='26' cy='26' r='25' fill='none'/>
              <path className='exclamationNotice__exclamation' d='M28 32l0-21.6c0-2.4-3.2-2.4-3.2 0v21.6c0 2.4 3.2 2.4 3.2 0m-4 8a2.4 2.4 90 114.8 0 2.4 2.4 90 11-4.8 0'/>
            </svg>
          </div> }
          { calendar && <div className='notice__wrapper' style={{ zIndex: 11 }}>
            <svg className='notice__base calendarNotice notice__svg-info' viewBox='0 0 52 52'>
              <circle className='notice__circleBase notice__circle-info' cx='26' cy='26' r='25' fill='none'/>
              <path className='calendarNotice__calendar' fill='none' d='M12 15v3h28v-3c0-2-1-3-3-3h-4v-2c0-2-3-2-3 0v2h-8v-2c0-2-3-2-3 0v2h-4c-2 0-3 1-3 3m0 8v13c0 2 1 3 3 3h22c2 0 3-1 3-3v-13h-29'/>
            </svg>
          </div> }
          { upload && <div className='notice__wrapper' style={{ zIndex: 11 }}>
            <svg className='notice__base calendarNotice notice__svg-primary' viewBox='0 0 52 52'>
              <circle className='notice__circleBase notice__circle-primary' cx='26' cy='26' r='25' fill='none'/>
              <path className='calendarNotice__calendar' fill='none' d='M23.5 10l-6.561 6.561c-2.187 2.187.729 5.103 2.916 2.916l4.374-4.374v13.122c0 2.187 3.645 2.187 3.645 0v-13.122l4.374 4.374c2.187 2.187 5.103-.729 2.916-2.916l-6.561-6.561c-1.458-1.458-3.645-1.458-5.103 0m-6.561 21v2.916c0 .729.729 1.458 1.458 1.458h15.309c.729 0 1.458-.729 1.458-1.458v-2.916c0-2.187 2.916-2.187 2.916 0v4.374c0 1.458-1.458 2.916-2.916 2.916h-18.225c-1.458 0-2.916-1.458-2.916-2.916v-4.374c0-2.187 2.916-2.187 2.916 0'/>
            </svg>
          </div> }
          <Scanner onResult={ (result: string) => setUpc(result) } active={ show } pause={ pause || !!upc } forceOptions={ showCamOptions } />
        </Modal.Body>
        <Modal.Footer>
          <Button variant='' className='me-auto text-secondary' onClick={ () => setCamOpt(!showCamOptions) }><FontAwesomeIcon icon={ faGear } /></Button>
          <Button variant='secondary' onClick={ onHide }>Back</Button>
          <Button variant='primary' disabled={ pause || (scans.size < 1) } onClick={ saveScans }>Save</Button>
        </Modal.Footer>
        <Modal.Footer className='position-relative d-block overflow-hidden'>
          <ScanResults scans={ scans } actions={ noticeActions } remove={ removeScan } />
        </Modal.Footer>
      </Modal>
    </>
  );
}

// Results

export type noticeType = 'expiration' | 'incomplete' | undefined;
export type notices = Array<noticeType>;

export interface PScanResults {
  scans: IScannerProducts;
  remove: (upc: string) => void;
  actions: (upc: string, actions: notices) => void;
}

export function ScanResults({ scans, remove, actions }: PScanResults) {
  const products: JSX.Element[] = [];

  scans.forEach((product, key) => {
    let notice: notices = [];
    if (product.track_expiration) notice.push('expiration');
    if (product.new && !product.saved) notice.push('incomplete');
    products.push(<ScanResult
      key={ 'ScanResult#' + key }
      onClick={ () => actions(key, notice) }
      onRemove={ () => remove(key) }
      label={ product.product_name }
      count={ product.package_count }
      notices={ notice } />
    );
  });

  products.reverse();

  return (
    <div className='list-group list-group-flush'>
      { products }
    </div>);
}

export interface PScanResult {
  label: string;
  count: number;
  notices: notices;
  onClick: () => void;
  onRemove: () => void;
}

export function ScanResult({ label, count, notices, onClick, onRemove }: PScanResult) {
  const [remove, setRemove] = useState(false);
  let noticeBadges = [];

  const handleRemove = (e: e_click) => {
    e.stopPropagation();
    setRemove(true);
    onRemove();
  }
  
  if (notices.includes('expiration'))
    noticeBadges.push(<span key={ label + 'expiration' } className='px-1'><FontAwesomeIcon className='text-info fs-5' icon={ faCalendarXmark } /></span>);
  if (notices.includes('incomplete'))
    noticeBadges.push(<span key={ label + 'incomplete' } className='px-1'><FontAwesomeIcon className='text-danger fs-5' icon={ faCircleExclamation } /></span>);
  noticeBadges.push(<span key={ label + 'count' } className='badge bg-primary rounded-pill' style={{ height: '22px' }}>{ count }</span>);

  return (
    <button className={ 'list-group-item list-group-item-action rounded p-0 ' + (remove ? 'slide-left' : '') } onClick={ onClick }>
      <div className='position-relative d-flex flex-row justify-content-between textFadeout-wrapper py-2 px-3'>
        <button className='btn btn-danger-onHover position-absolute top-0 start-0 bottom-0' onClick={ handleRemove } style={{ zIndex: 1 }}>
          <FontAwesomeIcon icon={ faTrash } />
        </button>
        <div className='textFadeout ps-4'>
          <span className='ps-1 list-group-item-action text-decoration-none text-nowrap'>{ label }</span>
        </div>
        <div className='d-flex flex-row'>
          { noticeBadges }
        </div>
      </div>
    </button>
  );
}

// Scanner

export const mediaConstraints = { video: { aspectRatio: { ideal: 1.333 }, facingMode: 'environment' } };

export interface PInnerScanner {
  active: boolean;
  pause: boolean;
  cameraId: string;
  onDetected: (result: string) => void;
  containerRef: MutableRefObject<any>;
}

function InnerScanner({ cameraId, onDetected, containerRef, active, pause }: PInnerScanner): null {

  const getMedian = (arr: any[]) => {
    arr.sort((a, b) => a - b);
    const half = Math.floor(arr.length / 2);
    if (arr.length % 2 === 1) return arr[half];
    return (arr[half - 1] + arr[half]) / 2;
  }

  useEffect(() => {
    if (active) return;
    Quagga.stop();
    Quagga.CameraAccess.release();
  }, [active]);

  const errorCheck = useCallback((result: QuaggaJSResultObject) => {
      if (!onDetected || !result.codeResult.code || !active || pause) return;
      const err = getMedian(result.codeResult.decodedCodes.filter(x => x.error !== undefined).map(x => x.error));
      if (err < 0.15) onDetected(result.codeResult.code);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [onDetected]
  );

  useLayoutEffect(() => {
    if (!containerRef.current) return;

    Quagga.init({
      frequency: 10,
      inputStream: {
        name: 'Scanner',
        type: 'LiveStream',
        target: containerRef.current,
        constraints: {
          aspectRatio: mediaConstraints.video.aspectRatio,
          ...(cameraId === 'default' ? { facingMode: mediaConstraints.video.facingMode } : { deviceId: cameraId })
        },

      },
      decoder: { 
        readers: [
          'upc_reader',
          'ean_reader',
          'upc_e_reader',
          'code_39_reader',
        ]
      },
    },
    (err) => {
      Quagga.onDetected(errorCheck);
      if (err) return console.log('Error starting Quagga:', err);
      Quagga.start();
    });
    
    
    return () => {
      Quagga.offDetected(errorCheck);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cameraId, containerRef.current]);

  return null;
}

export interface PScanner {
  onDenied?: () => void;
  onResult: (result: string) => void;
  active: boolean;
  pause: boolean;
  forceOptions?: boolean;
}

export function Scanner({ onDenied, onResult, active, pause, forceOptions }: PScanner) {
  const defaultOption: MediaDeviceInfo = { deviceId: 'default', groupId: 'none', kind: 'videoinput', label: 'Default', toJSON: () => JSON.stringify(defaultOption) };
  const [camera, setCamera, { removeItem }] = useLocalStorageState<MediaDeviceInfo>('BarcodeScannerSelectedCamera', { ssr: true, defaultValue: defaultOption });
  const [devices, setDevices] = useState<MediaDeviceInfo[] | null>(null);
  const [showOptions, setShowOptions] = useState(false);
  const [noDevice, setNoDevice] = useState(false);
  const scannerContainerRef = useRef<HTMLDivElement>(null);
  const [torch, setTorch] = useState(false);

  useEffect(() => {
    // Get environment facing camera perms
    Quagga.CameraAccess.request(null, mediaConstraints as MediaTrackConstraintsWithDeprecated).then(() => {
      // Release camera so other things can use it
      Quagga.CameraAccess.release().then(function() {
        handleVideoDevices();
        // Listen for new media devices and update component as needed
        navigator.mediaDevices.ondevicechange = handleVideoDevices;
      });
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (devices)
      devices.some(cam => cam.deviceId === camera.deviceId) ? setNoDevice(false) : setNoDevice(true);
  }, [devices, camera.deviceId]);

  const handleVideoDevices = () => {
    // Get list of environment facing cameras
    Quagga.CameraAccess.enumerateVideoDevices().then(devices => {
      if (devices.length <= 0) onDenied?.();
      const newDevices = [...devices, defaultOption];
      // Save device list
      setDevices(newDevices);
      // Show options if user selected camera is unavailable
      newDevices.some(cam => cam.deviceId === camera.deviceId) ? setNoDevice(false) : setNoDevice(true);
    });
  }

  const handleResult = (result: string) => {
    setShowOptions(false);
    onResult(result);
  }

  const handleSelect = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.currentTarget.value === 'default') return removeItem();
    setCamera(devices?.find(cam => cam.label === e.currentTarget.value) ?? defaultOption);
  };

  const handleTorch = () => {
    const stream = Quagga.CameraAccess.getActiveTrack();
    const capabilities = stream?.getCapabilities() as MediaTrackCapabilitiesPlus;
    if (!stream || !capabilities || !capabilities.torch) return;
    stream?.applyConstraints({ advanced: [{ torch: !torch } as MediaTrackConstraintSetPlus] });
    setTorch(!torch);
  }

  const handleReFocus = () => {
    const stream = Quagga.CameraAccess.getActiveTrack();
    const capabilities = stream?.getCapabilities() as MediaTrackCapabilitiesPlus;
    if (!stream || !capabilities || !capabilities.focusMode || !capabilities.focusDistance) return;
    stream?.applyConstraints({ advanced: [{ focusMode: 'manual', focusDistance: 0 } as MediaTrackConstraintSetPlus] });
    setTimeout(() => {
      stream?.applyConstraints({ advanced: [{ focusMode: 'continuous' } as MediaTrackConstraintSetPlus] });
    }, 1000);
  }

  return (
    <>
      <div className='ratio ratio-16x9'>
        <div>
          <div id='canvas-scanner_container' className='position-absolute start-0 end-0 top-0 bottom-0 overflow-hidden rounded' ref={scannerContainerRef} onClick={handleReFocus} >
            <InnerScanner cameraId={camera!.deviceId} containerRef={scannerContainerRef} onDetected={handleResult} active={active} pause={pause} />
            <svg viewBox='0 0 700 700' className='position-absolute' style={{ top: '17%', bottom: '17%', left: '17%', right: '17%', strokeWidth: '0.75rem' }}>
              <path stroke='rgba(220,139,50,0.8)' fill='none' d='M50 5h100m400 0h100v100m0 200v100h-100m-400 0h-100v-100m0-200v-105'/>
            </svg>
            <canvas onClick={handleReFocus} className='drawingBuffer position-absolute start-0 top-0 w-100 h-100' style={{ zIndex: 9 }} />
          </div>
          {noDevice && <span className={'position-absolute start-50 top-50 translate-middle fs-3 fw-bold'} >No Device</span>}
          <div style={{ position: 'absolute', top: '20px', bottom: '20px', right: '0px', width: '100%', height: '100%', zIndex: 10 }} className={'justify-content-center ' + (noDevice || showOptions || forceOptions ? 'd-block' : 'd-none')}>
            <ButtonGroup vertical className='d-grid'>
              {devices?.map(device => (
                <ToggleButton
                key={device.deviceId}
                id={`radio-${device.deviceId}`}
                type='radio'
                variant='outline-primary'
                name='radio'
                value={device.label}
                checked={camera.deviceId === device.deviceId}
                onChange={handleSelect}>
                  {device.label}
                </ToggleButton>
              ))}
            </ButtonGroup>
          </div>
          <Button variant='' onClick={handleTorch} style={{ zIndex: 10 }} className='position-absolute top-0 end-0 text-primary'><FontAwesomeIcon icon={ faBolt } /></Button>
        </div>
      </div>
    </>
  );
}
