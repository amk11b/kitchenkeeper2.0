import { useEffect, useState } from 'react';
import { Modal, Button } from 'react-bootstrap';
import { FaTrash } from 'react-icons/fa';
import { e_change_textarea } from '../../objects/types';

export interface PNoteModal {
  show: boolean;
  note?: string;
  onRemove?: () => void;
  onHide: () => void;
  resultCallback: (note: string) => void;
}

export default function NoteModal({ note, show, onHide, onRemove, resultCallback }: PNoteModal) {
  const [input, setInput] = useState('');
  const [valid, setValid] = useState(false);

  useEffect(() => {
    if (show) setInput(note ?? '');
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show]);

  const onConfirm = () => resultCallback(input);

  const inputChange = (e: e_change_textarea) => {
    const value = e.currentTarget.value;
    setInput(value);
    setValid(!!value.trim().length);
  };

  return (
    <Modal show={show} onHide={onHide}>
      <Modal.Body className='scrollable-shadowed p-5' style={{ height: '18rem', maxHeight: '600px' }}>
        <textarea className='form-control w-100 h-100' autoFocus placeholder='Note...' onChange={inputChange} value={input}></textarea>
      </Modal.Body>
      <Modal.Footer>
        { onRemove && <Button variant='' className='me-auto btn-danger-onHover' onClick={onRemove}><FaTrash /></Button> }
        <Button variant='secondary' onClick={onHide}>Cancel</Button>
        <Button variant='primary' disabled={!valid} onClick={onConfirm}>Confirm</Button>
      </Modal.Footer>
    </Modal>
  );
}
