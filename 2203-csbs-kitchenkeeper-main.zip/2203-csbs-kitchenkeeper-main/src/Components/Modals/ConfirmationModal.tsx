import { Modal, Button } from 'react-bootstrap';

export interface PConfirmationModal {
  show: boolean;
  title?: string;
  titleClasses?: string;
  text?: string;
  textClasses?: string;
  btn1Text?: string;
  btn2Text?: string;
  onHide: () => void;
  onConfirm: () => void;
}

export default function ConfirmationModal({ show, title, titleClasses, text, textClasses, btn1Text, btn2Text, onHide, onConfirm }: PConfirmationModal) {

  return (
    <Modal show={show} onHide={onHide} centered >
      { title && <Modal.Header className='fs-5 fw-bold text-muted'>
        <span className={titleClasses}>{title}</span>
      </Modal.Header> }
      <Modal.Body className='scrollable-shadowed p-5'>
        <span className={textClasses}>{text}</span>
      </Modal.Body>
      <Modal.Footer>
        <Button variant='secondary' onClick={onHide}>
          { btn1Text ?? 'Cancel'}
        </Button>
        <Button variant='primary' onClick={onConfirm}>
          { btn2Text ?? 'Confirm'}
        </Button>
      </Modal.Footer>
    </Modal>
  );
}