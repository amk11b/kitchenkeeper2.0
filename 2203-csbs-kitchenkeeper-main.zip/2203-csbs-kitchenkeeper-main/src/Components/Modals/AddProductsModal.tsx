import { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { faBarsStaggered, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Badge, Button, Modal } from 'react-bootstrap';
import ItemCard from '../ItemCard';
import { IProducts } from '../../objects/Product';
import { ReduxFirestoreQuerySetting, isLoaded, isEmpty } from 'react-redux-firebase';
import { ProductsConverter } from '../../helpers/converters';
import InventorySearch from '../InventorySearch';

export interface PAddProductsModal {
  show: boolean;
  onHide: () => void;
  resultCallback: (items: IProducts) => void;
  path: ReduxFirestoreQuerySetting;
}

export default function AddProductsModal({ show, onHide, resultCallback, path }: PAddProductsModal) {
  const [searchResults, setSearchResults] = useState<IProducts>(new Map());
  const [selectedItems, setSelectedItems] = useState<IProducts>(new Map());
  const [viewSelected, setViewSelected] = useState(false);
  const InventorySearchResults = useSelector((state: any) => state.firestore.data.InventorySearchResults);

  useEffect(() => {
    if (show) setSelectedItems(new Map());
  }, [show])
  // Convert search results from firestore to Products
  useEffect(() => {
    if (!isLoaded(InventorySearchResults)) return;
    if (isEmpty(InventorySearchResults)) return;
    setSearchResults(ProductsConverter.fromFirestore(InventorySearchResults));
  }, [InventorySearchResults]);
  // Copy item to selected items
  const handleSelect = (id: string) => {
    const selectedItem = searchResults.get(id);
    if (!!!selectedItem) return;
    setSelectedItems(new Map([...selectedItems, [id, selectedItem]]));
  };
  // Remove item from selected items
  const removeSelected = (id: string) => {
    const newSelectedItems = new Map(selectedItems);
    if (newSelectedItems.delete(id))
      // only updates if delete worked
      setSelectedItems(newSelectedItems);
  };
  // Return result and close modal
  const confirmSelected = () => resultCallback(selectedItems);
  // Hide View Selected Modal
  const hideViewSelected = () => setViewSelected(false);
  // Assemble Item Cards
  const ItemCards: JSX.Element[] = [];
  searchResults.forEach((item, key) => {
    ItemCards.push(<ItemCard key={key} title={item.product_name ?? 'Name not Available'} img={item.image_url} selected={selectedItems.has(key)} onClick={() => handleSelect(key)} className='py-2' displayValue={item.package_count} />);
  });

  return (
    <>
      <ProductViewSelectionModal show={show && viewSelected} onHide={hideViewSelected} products={selectedItems} onRemove={removeSelected} onConfirm={confirmSelected} />

      <Modal show={show && !viewSelected} onHide={onHide} scrollable>
        <Modal.Header>
          <InventorySearch path={path} autofocus className='w-100' />
        </Modal.Header>
        <Modal.Body className='scrollable-shadowed p-0' style={{ height: '80vh', maxHeight: '600px' }}>
          <div className='mx-auto' style={{ width: '343px' }}>
            {ItemCards}
            {!ItemCards.length && <span className='position-absolute top-50 start-50 translate-middle text-muted'>Search for items in your Pantry</span>}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant='secondary' className='me-auto fw-bold position-relative' onClick={() => setViewSelected(true)}>
            <FontAwesomeIcon icon={faBarsStaggered} />
            {!!selectedItems.size && (
              <Badge bg='primary' className='position-absolute top-0 start-100 translate-middle rounded-pill fs-6'>
                {selectedItems.size}
              </Badge>
            )}
          </Button>
          <Button variant='secondary' onClick={onHide}>
            Cancel
          </Button>
          <Button variant='primary' onClick={confirmSelected}>
            Confirm
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export interface PProductViewSelectionModal {
  show: boolean;
  onHide: () => void;
  products: IProducts;
  onRemove: (id: string) => void;
  onConfirm: () => void;
}

export function ProductViewSelectionModal({ show, onHide, products, onRemove, onConfirm }: PProductViewSelectionModal) {
  // Assemble Item Cards
  const ItemCards: JSX.Element[] = [];
  products.forEach((product, key) => {
    ItemCards.push(
      <div key={key} className='position-relative'>
        <ItemCard title={product.product_name ?? 'Name not Available'} img={product.image_url} className='py-2' displayValue={product.package_count} />
        <Button variant='danger' onClick={() => onRemove(key)} className='position-absolute top-50 start-100 translate-middle'>
          <FontAwesomeIcon icon={faTrash} />
        </Button>
      </div>
    );
  });

  return (
    <Modal show={show} onHide={onHide} scrollable>
      <Modal.Header style={{ height: '71px' }} />
      <Modal.Body className='scrollable-shadowed p-0' style={{ height: '80vh', maxHeight: '600px' }}>
        <div className='mx-auto' style={{ width: '343px' }}>
          {ItemCards}
          {!ItemCards.length && <span className='position-absolute top-50 start-50 translate-middle text-muted'>You have not selected anything yet</span>}
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant='secondary' onClick={onHide}>
          Back
        </Button>
        <Button variant='primary' onClick={onConfirm}>
          Confirm
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
