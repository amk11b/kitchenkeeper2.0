import { useState, useEffect } from 'react';
import { Button, FloatingLabel, Form, Modal } from 'react-bootstrap';
import { e_change } from '../../objects/types';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash } from '@fortawesome/free-solid-svg-icons';

export interface PExpirationsModal {
  show: boolean;
  expirations?: string[] | null;
  onHide: () => void;
  onSubmit: (expirations: string[]) => void;
  count?: number | null;
}

export default function ExpirationsModal({ show, expirations, onHide, onSubmit, count }: PExpirationsModal) {
  const [inputValues, setInputValues] = useState<string[]>([]);

  useEffect(() => {
    if (!show) return;
    if (!expirations) setInputValues([]);
    if (expirations && !count) setInputValues([...expirations]);
    if (expirations && count) setInputValues(Array.from({length: count}, (_, i) => expirations[i] ?? ''));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show])

  const handleSubmit = () => onSubmit(inputValues);
  const handleCancel = () => onHide();

  const handleChange = (value: string | null, index: number) => {
    if (inputValues.length < index) return;
    if (value === null) inputValues.splice(index);
    if (value) inputValues[index] = value;
    setInputValues([...inputValues]);
  }

  let inputs: JSX.Element[] = [];

  inputValues.forEach(( val, index ) => {
    inputs.push( <ExpirationInput key={ 'expiration-' + index } index={ index } value={ val } showRemove={ !count } onChange={ handleChange } /> );
  });

  if (count && inputs.length < count)
    while (inputs.length < count)
      inputs.push( <ExpirationInput key={ 'expiration-' + inputs.length } index={ inputs.length } onChange={ handleChange } /> );

  return (
    <Modal show={ show } onHide={ onHide }>
      <Modal.Body>
        <Form>
          { inputs }
          { !count && <ExpirationInput key={ 'expiration-' + inputValues.length } index={ inputValues.length } onChange={ handleChange } /> }
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant='secondary' onClick={handleCancel}>Cancel</Button>
        <Button variant='primary' onClick={handleSubmit} >Save</Button>
      </Modal.Footer>
    </Modal>
  );
}

export interface PExpirationInput {
  value?: string;
  defaultValue?: string;
  index: number;
  onChange?: (value: string | null, index: number) => void;
  showRemove?: boolean
}

export function ExpirationInput({ value, defaultValue, index, onChange, showRemove }: PExpirationInput) {
  const handleChange = (e: e_change) => {
    const val = e.currentTarget.value.trim();
    onChange?.(val, index ?? 0);
  }

  const handleRemove = () => onChange?.(null, index ?? 0);

  return (
    <div className='hstack'>
      { showRemove && <Button variant='' className='mb-3 me-3 btn-danger-onHover' onClick={ handleRemove }><FontAwesomeIcon icon={ faTrash } /></Button> }
      <FloatingLabel label={ 'Expiration - ' + index++ } className='mb-3 w-100'>
        <Form.Control type='date' onChange={ handleChange } value={ value } defaultValue={ defaultValue } />
      </FloatingLabel>
    </div>
  );
}