import { Button, Dropdown, FloatingLabel, Form, Modal, Overlay, Tooltip } from 'react-bootstrap';
import { fromOFFP, IProduct, DefaultProduct, genKeywords } from '../../objects/Product';
import { useState, useEffect, useRef } from 'react';
import OpenFoodFactsApi from 'openfoodfac-ts';
import { Locations } from '../../objects/types';
import LoadingSpinner from '../loadingSpinner';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faCalendar, faTrash, faArrowRight, faQuestionCircle } from '@fortawesome/free-solid-svg-icons';
import { TagsInput } from '../TagsInput';
import { units } from '../../helpers/mini';
import ExpirationsModal from './ExpirationsModal';
import { ProductConverter } from '../../helpers/converters';
import moment from 'moment';

export interface PProductDetailsModal {
  path: ReduxFirestoreQuerySetting;
  show: boolean;
  onHide: () => void;
  product_data: IProduct;
  upc?: string;
  fetch?: boolean;
  edit?: boolean;
  onRemove?: (key: string) => void;
  onSave?: (product: IProduct) => void;
}

export default function ProductDetailsModal({ path, show, onHide, onRemove, product_data, upc, fetch, edit, onSave }: PProductDetailsModal) {
  const firestore = useFirestore();
  const openFoodFactsApi = new OpenFoodFactsApi();
  const [editProduct, setProduct] = useState<IProduct>(DefaultProduct);
  const [loading, setLoading] = useState(false);
  const [editState, setEditState] = useState(false);
  const [offAutoFill, setOffAutoFill] = useState(false);
  const [showExpirations, setShowExpirations] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [resetForm, setResetForm] = useState(false);
  const [savedEdit, setSavedEdit] = useState(false);
  const [desiredState, setDesiredState] = useState(false);
  const desiredTarget = useRef(null);

  const product = editState || fetch || savedEdit ? editProduct : product_data;
  const productPath = { ...path, subcollections: [{ collection: 'products', doc: product.code }] };

  useEffect(() => {
    if (!show) return;
    setProduct(product_data);
    setLoading(false);
    setEditState(edit ?? false);
    setOffAutoFill(false);
    setShowExpirations(false);
    setShowConfirm(false);
    setSavedEdit(false);
    formReset();
    if (fetch) fetchProduct();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show]);

  useEffect(() => {
    if (resetForm) formReset();
  }, [resetForm]);

  const fetchProduct = async () => {
    setLoading(true);
    const inventoryProduct = await firestore.get({...path, subcollections: [{ collection: 'products', doc: upc }], storeAs: 'details-' + upc });
    if (!inventoryProduct.exists) return;
    const product: IProduct = ProductConverter.fromFirestore(inventoryProduct.data());
    setProduct(product);
    setLoading(false);
  };

  const autoFill = async () => {
    setLoading(true);
    const offproduct = await openFoodFactsApi.findProductByBarcode(product.code);
    if (offproduct) {
      setProduct({ ...fromOFFP(offproduct), code: product.code, package_count: product.package_count });
      setResetForm(true);
    }
    setLoading(false);
  };

  const saveProduct = () => {
    const saveProduct: IProduct = { ...DefaultProduct, ...product, keywords: genKeywords([...(product.keywords ?? []), product.product_name]) };
    firestore.set(productPath, saveProduct);
    setShowConfirm(false);
    setEditState(false);
    setSavedEdit(true);
    setProduct(saveProduct);
    onSave?.(saveProduct);
  };

  const deleteProduct = () => {
    firestore.delete(productPath);
    onRemove?.(product.code);
    onHide();
  };

  const toggleEdit = () => {
    setEditState(!editState);
    setShowConfirm(false);
    if (edit && editState) onHide();
  };

  const formReset = () => (document.getElementById('ProductDetailsForm') as any)?.reset?.();
  const toggleDesiredState = () => setDesiredState(!desiredState);
  const updateKeywords = (keywords: string[]) => setProduct({ ...product, keywords: keywords });
  const updateUnit = (unit: string) => setProduct({ ...product, package_size_unit: unit });
  const updateLocation = (location: Locations) => setProduct({ ...product, location: location });

  const updateExpirations = (expirations: string[]) => {
    const updatedProduct = { ...product, expirations: expirations };
    firestore.set(productPath, updatedProduct);
    setProduct(updatedProduct);
    setShowExpirations(false);
    setSavedEdit(true);
    onSave?.(updatedProduct);
  };

  const editExpirations = () => setShowExpirations(true);
  const confirmDelete = () => setShowConfirm(true);

  const handleChange = (e: any) => {
    const name = e.target.name;
    let value = e.target.value;
    if (!name) return;
    if (name === 'keywords') return;
    if (name === 'code') setOffAutoFill(true);
    if (name === 'track_expiration') value = e.target.checked ? true : false;
    if (name === 'desired_count') value = parseInt(value);
    setProduct({ ...product, [name]: typeof value === 'string' ? value.trim() : value });
  };

  return (
    <>
      <ExpirationsModal show={showExpirations} onHide={() => setShowExpirations(false)} onSubmit={updateExpirations} expirations={product.expirations} count={product.package_count} />

      <Modal show={(show ?? true) && !showExpirations} onHide={onHide}>
        <Modal.Header>
          <Modal.Title>{product.product_name ?? 'Product Details'}</Modal.Title>
          {editState && !showConfirm && (
            <Button variant='' className='ms-auto me-3 text-white-200' onClick={confirmDelete}>
              <FontAwesomeIcon icon={faTrash} />
            </Button>
          )}
          {editState && showConfirm && (
            <Button variant='danger' className='ms-auto me-3' onClick={deleteProduct}>
              Confirm
            </Button>
          )}
          <Button variant='' className='btn-primary-onHover' onClick={toggleEdit}>
            <FontAwesomeIcon icon={faPenToSquare} />
          </Button>
        </Modal.Header>
        <Modal.Body>
          {loading && <LoadingSpinner />}

          {!editState && (
            <div className='vstack gap-2 px-4'>
              {product.image_url && <img src={product.image_url} className='mw-100 rounded mx-auto' alt='ProductImage' />}

              <DetailItem label='Brand' text={product.brand} />
              <DetailItem label='Size' text={product.package_size} sub={product.package_size_unit} />
              <DetailItem label='Quantity' text={product.package_count} />
              <DetailItem label='Maintain Quantity' text={product.desired_count} />
              <DetailItem label='Location' text={product.location} />
              <DetailItem label='Ingredients' text={product.ingredients} />
              <DetailItem label='Traces' text={product.traces} />
              <DetailItem label='Labels' text={product.labels} />
              <DetailItem label='UPC' text={product.code} />

              {product.track_expiration && (
                <div className='vstack'>
                  <span className='text-muted' style={{ fontSize: '.75rem' }}>
                    Expirations
                  </span>
                  <ul className='mt-2 list-group list-group-flush'>
                    {product.expirations?.map((date, index) => (
                      <li key={index + '-expiration'} className='list-group-item'>
                        {moment(date).format('dddd, MMMM Do YYYY')}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <div className='vstack'>
                <span className='text-muted' style={{ fontSize: '.75rem' }}>
                  Keywords
                </span>
                {!product.keywords?.length && <span className='text-muted ms-2'>No keywrods</span>}
                <TagsInput editMode={false} tagsOverride={product.keywords} />
              </div>
            </div>
          )}

          {editState && (
            <Form id='ProductDetailsForm' onChange={handleChange}>
              <FloatingLabel label='UPC' className='mb-3'>
                <Form.Control name='code' disabled={loading} data-lpignore type='text' defaultValue={product.code} autoComplete='off' />
                {offAutoFill && (
                  <Button variant='' title='Attempt to autofill based on UPC' className='position-absolute top-0 bottom-0 end-0 px-3 text-muted' onClick={autoFill}>
                    <FontAwesomeIcon icon={faArrowRight} />
                  </Button>
                )}
              </FloatingLabel>

              <FloatingLabel label='Product Name' className='mb-3'>
                <Form.Control name='product_name' disabled={loading} data-lpignore type='text' defaultValue={product.product_name} />
              </FloatingLabel>

              <FloatingLabel label='Package Size' className='mb-3'>
                <Form.Control name='package_size' disabled={loading} data-lpignore type='number' defaultValue={product.package_size ?? undefined} autoComplete='off' />
                <Dropdown className='position-absolute top-0 bottom-0 end-0 text-muted'>
                  <Dropdown.Toggle name='package_size_unit' variant='' disabled={loading} className='w-100 h-100 px-3 text-muted'>
                    {product.package_size_unit ?? 'Select unit'}
                  </Dropdown.Toggle>
                  <Dropdown.Menu variant='dark'>
                    {units.all.map((unit) => (
                      <Dropdown.Item key={unit + '-selector'} onClick={() => updateUnit(unit)}>
                        {unit}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </FloatingLabel>

              <FloatingLabel label='Maintain Quantity' className='mb-3 position-relative'>
                <Form.Control name='desired_count' disabled={loading} data-lpignore type='number' defaultValue={product.desired_count ?? undefined} autoComplete='off' />
                <Button variant='' className='position-absolute end-0 top-0 bottom-0 text-white-200' ref={desiredTarget} onClick={toggleDesiredState}>
                  <FontAwesomeIcon icon={faQuestionCircle} />
                </Button>
                <Overlay target={desiredTarget.current} show={desiredState} placement='right'>
                  {(props) => (
                    <Tooltip id='overlay-example' {...props}>
                      Automatically add product to your shopping list when quantity becomes less then this number
                    </Tooltip>
                  )}
                </Overlay>
              </FloatingLabel>

              <FloatingLabel label='Product Image url' className='mb-3'>
                <Form.Control name='image_url' disabled={loading} data-lpignore type='text' defaultValue={product.image_url ?? undefined} />
              </FloatingLabel>

              <Form.Group className='hstack gap-3'>
                <Form.Check name='track_expiration' disabled={loading} type='checkbox' defaultChecked={product.track_expiration} label='Track Expiration' className='mb-3 ms-4' />

                <Dropdown className='mb-3 ms-auto me-3'>
                  <Dropdown.Toggle name='location' disabled={loading} variant='' className='px-4 border border-2 border-grey text-muted'>
                    {product.location ?? 'Storage Location'}
                  </Dropdown.Toggle>
                  <Dropdown.Menu variant='dark'>
                    {Object.values(Locations).map((location) => (
                      <Dropdown.Item key={location + '-selector'} onClick={() => updateLocation(location)}>
                        {location}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </Form.Group>

              <FloatingLabel label='Ingredients' className='mb-3'>
                <Form.Control name='ingredients' disabled={loading} data-lpignore as='textarea' rows={6} defaultValue={product.ingredients ?? undefined} />
              </FloatingLabel>

              <TagsInput placeholder='New Keyword...' editMode={true} tagsOverride={product.keywords} onChange={updateKeywords} />
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          {product.track_expiration && (
            <Button variant='primary' className='me-auto' onClick={editExpirations}>
              <FontAwesomeIcon icon={faCalendar} />
            </Button>
          )}
          {!editState && (
            <Button variant='secondary' onClick={onHide}>
              back
            </Button>
          )}
          {editState && (
            <Button variant='secondary' onClick={toggleEdit}>
              Cancel
            </Button>
          )}
          {editState && (
            <Button variant='primary' onClick={saveProduct}>
              Save
            </Button>
          )}
        </Modal.Footer>
      </Modal>
    </>
  );
}

export interface PDetailItem {
  label?: string | null | number;
  text?: string | null | number;
  sub?: string | null | number;
  fw?: string;
  fs?: string;
  nowrap?: boolean;
  center?: 'label' | 'text' | 'both';
}

export function DetailItem({ label, text, sub, fw, fs, nowrap, center }: PDetailItem) {
  if (!text) return <></>;

  return (
    <div className={center === 'both' ? 'vstack text-center' : 'vstack'}>
      <span className={'text-muted ' + (center === 'label' ? ' mx-auto ' : ' ')} style={{ fontSize: '.75rem' }}>
        {label}
      </span>
      <span className={`overflow-hidden fw-${fw} fs-${fs} ` + (nowrap ? ' text-nowrap ' : ' ') + (center === 'text' ? ' mx-auto ' : ' ms-3 ')}>
        {text}
        {!!sub && <sub className='text-muted'>{sub}</sub>}
      </span>
    </div>
  );
}
