import { CSSProperties, useState, useEffect } from 'react';
import { e_key } from "../objects/types";

export interface PTagsInput {
  placeholder?: string;
  count?: { 
    min: number,
    max: number
  };
  style?: CSSProperties;
  className?: string;
  editMode?: boolean;
  tagsOverride?: string[];
  onChange?: (tags: string[]) => void;
}

export function TagsInput({ placeholder, editMode, tagsOverride, onChange, count, style, className }: PTagsInput) {
  const [tags, setTags] = useState<string[]>([]);

  useEffect(() => {
    if (tagsOverride && tagsOverride !== tags)
      return setTags(tagsOverride);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tagsOverride])

  const inputState = editMode && (count ? tags.length < count.max : true);

  const handleKeyDown = (e: e_key) => {
    if(e.key !== 'Enter') return
    const value = e.currentTarget.value;
    if(!value.trim()) return;
    const newTag = value.trim().toLocaleLowerCase();
    const updatedTags = [...tags, newTag];
    setTags(updatedTags);
    e.currentTarget.value = '';
    onChange?.(updatedTags);
  }

  const removeTag = (index: number) => {
    if (!count || (count && tags.length > count.max)) {
      const updatedTags = tags.filter((el, i) => i !== index);
      setTags(updatedTags);
      onChange?.(updatedTags);
    }
  }

  return (
    <div className={'tags-input-container ' + className} style={style}>
      { tags.map(( tag, index ) => (
        <div key={ 'tag-' + index + '-' + tag } className='tag-item'>
          <span className='text'>{tag}</span>
          { editMode && <span className='close' onClick={() => removeTag(index)}>&times;</span> }
        </div>
      )) }
      { inputState && <input name='keywords' onKeyDown={ handleKeyDown } data-lpignore type='text' className='tags-input' placeholder={ placeholder ?? 'New tag...' } /> }
    </div>
  );
}