import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { isEmpty, useFirebase } from 'react-redux-firebase';

import { ProSidebar, Menu, MenuItem, SidebarHeader, SidebarContent } from 'react-pro-sidebar';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { RiFileList3Line } from 'react-icons/ri';
import { BiCog, BiFoodMenu, BiInfoCircle, BiLogOut, BiRegistered } from 'react-icons/bi';
import { GiMeal } from 'react-icons/gi';
import { MdDashboard, MdFastfood, MdOutlineLogin} from 'react-icons/md';
import { faBars } from '@fortawesome/free-solid-svg-icons';

import './sidebar.css';

export default function Sidebar() {
  const [menuCollapse, setMenuCollapse] = useState(true);
  const path = useLocation().pathname;
  const auth = useSelector((state: any) => state.firebase.auth);
  const firebase = useFirebase();

  const toggleCollapse = () => setMenuCollapse(!menuCollapse);
  const sidebarExpand = () => setMenuCollapse(false);
  const sidebarCollapse = () => setMenuCollapse(true);

  useEffect(() => sidebarCollapse, [path]);

  return (
    <>
      <FontAwesomeIcon id='sidebar-hamburger' onClick={toggleCollapse} icon={faBars} />
      <div id='sidebar'>
        <ProSidebar collapsed={menuCollapse} onMouseEnter={ sidebarExpand } onMouseLeave={ sidebarCollapse }>      
          <SidebarHeader>
            <div className='brand'>
              <img alt='kk logo' src='/kk_logo.png' />
              <span>Kitchen Keeper</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            { !isEmpty(auth) ? 
              <Menu>
                <MenuItem active={path === '/dashboard'} icon={<MdDashboard size={25} />}>Dashboard<Link to='/dashboard' /></MenuItem>
                <MenuItem active={path === '/meals'} icon={<GiMeal size={25} />}>Meal Plan<Link to='/meals' /></MenuItem>
                <MenuItem active={path === '/shopping'} icon={<RiFileList3Line size={25} />}>Shopping List<Link to='/shopping' /></MenuItem>
                <MenuItem active={path === '/inventory'} icon={<MdFastfood size={25} />}>Pantry<Link to='/inventory' /></MenuItem>
                <MenuItem active={path === '/recipes/suggested'} icon={<BiFoodMenu size={25} />}>Recipes<Link to='/recipes/suggested' /></MenuItem>
                <MenuItem active={path === '/about'} icon={<BiInfoCircle size={25} />}>About<Link to='/about' /></MenuItem>
                <hr />
                <MenuItem active={path === '/settings'} icon={<BiCog size={25} />}>Settings<Link to='/settings' /></MenuItem>
                <MenuItem onClick={e => firebase.logout() } icon={<BiLogOut size={25} />}>Sign Out<Link to='/' /></MenuItem>
              </Menu>
              :
              <Menu>
                <MenuItem active={path === '/'} icon={<GiMeal size={25} />}>Landing<Link to='/' /></MenuItem>
                <MenuItem active={path === '/login'} icon={<MdOutlineLogin size={25} />}>Login<Link to='/login' /></MenuItem>
                <MenuItem active={path === '/register'} icon={<BiRegistered size={25} />}>Register<Link to='/register' /></MenuItem>
                <MenuItem active={path === '/about'} icon={<BiInfoCircle size={25} />}>About<Link to='/about' /></MenuItem>
              </Menu>
            }
          </SidebarContent>
        </ProSidebar>
      </div>
      <div id='sidebar-touchclose' className={menuCollapse ? '' : 'expanded'} onClick={sidebarCollapse} />
    </>
  );
}
