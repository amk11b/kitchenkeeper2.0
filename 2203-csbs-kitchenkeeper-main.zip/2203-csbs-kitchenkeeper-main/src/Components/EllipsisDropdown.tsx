import { forwardRef } from "react";
import { e_click } from "../objects/types";

type Props = {
  onClick: (e: e_click) => void,
  value: string
}
type RefType = number
export const EllipsisDropdown = forwardRef<RefType, Props>(({ children, onClick }, ref: any) => (
  <button ref={ref} className='border-0 py-2 px-3 bg-transparent text-secondary' onClick={(e) => { e.preventDefault(); onClick(e); }}>
    {children}
  </button>
));