import { useSelector } from 'react-redux';
import { isEmpty, isLoaded } from 'react-redux-firebase';
import LoadingSpinner from '../Components/loadingSpinner';

export default function RequireProfile({ children }: { children: JSX.Element }) {
  const auth = useSelector((state: any) => state.firebase.auth);
  const profile = useSelector((state: any) => state.firebase.profile);

  if (!isLoaded(auth) || !isLoaded(profile)) return <LoadingSpinner />;
  if (isLoaded(profile) && !isEmpty(profile)) return children;
  
  return null;
}
