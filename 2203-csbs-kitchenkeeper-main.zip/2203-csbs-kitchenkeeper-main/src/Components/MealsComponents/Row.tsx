import { Ref } from 'react';
import { Droppable } from 'react-beautiful-dnd';
import { Card } from 'react-bootstrap';
import { ReduxFirestoreQuerySetting } from 'react-redux-firebase';
import { IMealsData } from '../../objects/Meals';
import { Days, DnDType } from '../../objects/types';
import { TSyncState } from '../SyncIndicator';
import { Column } from './Column';
import { getChildren } from './helpers';

export interface PRow {
  rowId: Days;
  data: IMealsData;
  label?: string;
  docPath: ReduxFirestoreQuerySetting;
  syncState?: (state: TSyncState) => void;
  addComponent?: (type: DnDType, parentId: string) => void;
  isOnly?: boolean;
  innerRef?: Ref<HTMLDivElement>;
  onClick?: (e: any) => void;
}

export default function Row({ rowId, data, docPath, label, syncState, addComponent, isOnly, innerRef, onClick }: PRow) {
  const children = getChildren(data, rowId);

  return (
    <Droppable droppableId={rowId} direction='horizontal' type={DnDType.ROW}>
      {(provided) => (
        <div ref={innerRef} onClick={onClick}>
          <Card ref={provided.innerRef} className='border-0 my-2 py-2' style={{ minHeight: '13rem' }}>
            {!isOnly && (
              <div className='fs-6 fw-bold text-white-200 px-5'>
                <div className='rounded border border-2 border-white-200 bg-white-200'></div>&nbsp;&nbsp;
                {label ?? rowId.toUpperCase()}
              </div>
            )}
            <Card.Body
              {...provided.droppableProps}
              className='d-flex flex-row px-5 noScrollbar'
              style={{ overflowY: 'auto' }}>
              {children.map((column) => (
                <Column
                  key={column.id}
                  index={column.index}
                  columnId={column.id}
                  parentId={rowId}
                  data={data}
                  docPath={docPath}
                  syncState={syncState}
                  addComponent={addComponent}
                />
              ))}
              {addComponent && <Column
                key={rowId + '-isLast'}
                index={children.length}
                columnId={rowId + '-isLast'}
                parentId={rowId}
                data={data}
                docPath={docPath}
                syncState={syncState}
                isLast
              />}
              {!addComponent && !children.length && <span className='ms-5 text-muted'>You don't have any meals setup for today.</span>}
              {provided.placeholder}
            </Card.Body>
          </Card>
        </div>
      )}
    </Droppable>
  );
}
