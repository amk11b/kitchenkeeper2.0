import { styled } from '@mui/material/styles';
import TextField from '@mui/material/TextField';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { StaticDatePicker } from '@mui/x-date-pickers/StaticDatePicker';
import { PickersDay, PickersDayProps } from '@mui/x-date-pickers/PickersDay';
import moment, { Moment } from 'moment';
import { ComponentType, useState, useEffect } from 'react';
import { Button, Modal } from 'react-bootstrap';

type CustomPickerDayProps = PickersDayProps<Moment> & {
  dayIsBetween: boolean;
  isFirstDay: boolean;
  isLastDay: boolean;
};

const CustomPickersDay = styled(PickersDay, { shouldForwardProp: (prop) =>
    prop !== 'dayIsBetween' && prop !== 'isFirstDay' && prop !== 'isLastDay',
})<CustomPickerDayProps>(({ dayIsBetween, isFirstDay, isLastDay }) => ({
  backgroundColor: '#f5f2ea',
  ...(dayIsBetween && {
    borderRadius: 0,
    backgroundColor: '#dc8b32',
    color: '#f5f2ea',
    '&:hover, &:focus': {
      backgroundColor: '#bb762b',
    },
  }),
  ...(isFirstDay && {
    borderTopLeftRadius: '50%',
    borderBottomLeftRadius: '50%',
  }),
  ...(isLastDay && {
    borderTopRightRadius: '50%',
    borderBottomRightRadius: '50%',
  }),
})) as ComponentType<CustomPickerDayProps>;

export interface PWeekPicker {
  show: boolean;
  current: Moment;
  onHide: () => void;
  onSubmit: (date: Moment) => void;
}

export default function WeekPickerModal({ show, current, onHide, onSubmit }: PWeekPicker) {
  const [value, setValue] = useState<Moment | null | undefined>(moment());

  useEffect(() => {
    if (show) setValue(current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show])

  const renderWeekPickerDay = ( date: Moment, selectedMoments: Array<Moment | null>, pickersDayProps: PickersDayProps<Moment> ) => {
    if (!value) return <PickersDay {...pickersDayProps} />;

    const start =  moment(value).startOf('week');
    const end =  moment(value).endOf('week');

    const isBetween = moment(date).isBetween(start, end, 'date', '[]');
    const isFirst = moment(date).isSame(start, 'day');
    const isLast = moment(date).isSame(end, 'day');

    return <CustomPickersDay
      {...pickersDayProps}
      disableMargin
      showDaysOutsideCurrentMonth
      dayIsBetween={isBetween}
      isFirstDay={isFirst}
      isLastDay={isLast}
    />
  };

  const handleSubmit = () => {
    if (!value) return onHide();
    onSubmit(value.startOf('week'));
  }

  return (
    <Modal show={show} onHide={onHide}>
    <Modal.Body className='px-0'>
      <LocalizationProvider dateAdapter={AdapterMoment}>
        <StaticDatePicker
          displayStaticWrapperAs="desktop"
          value={value}
          onChange={(newValue) => setValue(newValue?.startOf('week')) }
          renderDay={renderWeekPickerDay}
          renderInput={(params) => <TextField {...params} />}
        />
      </LocalizationProvider>
    </Modal.Body>
    <Modal.Footer>
      <Button variant='secondary' onClick={onHide}>Cancel</Button>
      <Button variant='primary' onClick={handleSubmit}>Confirm</Button>
    </Modal.Footer>
  </Modal>
  );
}
