import { faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Droppable } from 'react-beautiful-dnd';
import { Button } from 'react-bootstrap';
import { DnDType } from '../../objects/types';

interface PRemove {
  onClick: () => void;
  parentId: string;
}

export function Remove({ onClick, parentId }: PRemove) {
  
  return (
    <Droppable droppableId={'remove-' + parentId} type={DnDType.COLUMN} >
      {(provided, snapshot) => (
        <Button
        id={parentId + '-removebtn'}
        onClick={onClick}
        className='border-0 btn-danger-onHover'
        variant=''
        ref={provided.innerRef}
        {...provided.droppableProps}>
          <FontAwesomeIcon icon={faTrash} />
          <div style={{ width: '0', height: '0' }} >{ provided.placeholder }</div>
        </Button>
      )}
    </Droppable>
  );
}
