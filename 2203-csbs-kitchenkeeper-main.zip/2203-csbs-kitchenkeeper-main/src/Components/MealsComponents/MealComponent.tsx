import { isEmpty } from 'lodash';
import { useState } from 'react';
import { Draggable } from 'react-beautiful-dnd';
import { createPortal } from 'react-dom';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import { useNavigate } from 'react-router-dom';
import { IMealsData } from '../../objects/Meals';
import ItemCard from '../ItemCard';
import NoteModal from '../Modals/NoteModal';
import { ToastNotification } from '../ToastNotification';

export interface PMealComponent {
  index: number;
  componentId: string;
  data: IMealsData;
  docPath: ReduxFirestoreQuerySetting;
}

export function MealComponent({ index, componentId, data, docPath }: PMealComponent) {
  const [removeOnMakeNotification, setROMN] = useState(false);
  const [noteState, setNoteState] = useState(false);
  const firestore = useFirestore();
  const comp = data.get(componentId);
  const navigate = useNavigate();

  if (!comp) return null;

  const parent = data.get(comp?.parentId);
  
  const item = comp.item;
  const recipe = comp.recipe;
  const note = comp.note;

  if (!item && !recipe && !note) return null;

  const stepperChange = (value: number) => {
    let update: any = {};

    if (!!item) update = { [componentId + '.item.package_count']: value };
    if (!!recipe) update = { [componentId + '.recipe.servings']: value };
    if (!!note) update = undefined;

    if (!isEmpty(update)) firestore.update(docPath, update);
  };

  const navRecipe = () => navigate('/recipes/details/' + recipe?.id);
  const hideNote = () => setNoteState(false);
  const showNote = () => setNoteState(true);
  
  const saveROMNToggle = () => {
    firestore.update(docPath, { [componentId + '.remove_on_make']: !comp.remove_on_make });
    setROMN(true);
  }

  const saveNote = (newNote: string) => {
    firestore.update(docPath, { [componentId + '.note']: newNote });
    hideNote();
  }

  const ROMN = <ToastNotification 
    show={removeOnMakeNotification}
    onHide={() => setROMN(false)}
    bg={comp.remove_on_make ? 'success' : 'danger'}
    prefix={comp.remove_on_make ? 'On' : 'Off'}
    text='reduce product on use'
  />;

  return (
    <>
      { createPortal( ROMN, document.body )}

      <NoteModal show={noteState} onHide={hideNote} resultCallback={saveNote} note={note} />

      <Draggable draggableId={componentId} isDragDisabled={parent?.made} index={index}>
        {(provided) => (
          <div className='mb-2' {...provided.draggableProps} {...provided.dragHandleProps} ref={provided.innerRef}>
            {!!item && (
              <ItemCard
                title={item.product_name}
                img={item.image_url}
                disabled={parent?.made}
                onToggle={saveROMNToggle}
                toggleState={comp.remove_on_make}
                border={false}
                stepper={{
                  value: item.package_count,
                  minValue: 0,
                  stepValue: 0.1,
                  thumbStepValue: 1,
                  onChange_Total: stepperChange,
                }}
              />
            )}

            {!!recipe && (
              <ItemCard
                title={recipe.title}
                img={recipe.image}
                disabled={parent?.made}
                onToggle={saveROMNToggle}
                toggleState={comp.remove_on_make}
                valueLabel={'Multiplier: ' + (Math.round(( recipe.servings / recipe.multiplier ) * 100 ) / 100)}
                border={false}
                onClick={navRecipe}
                stepper={{
                  value: recipe.servings,
                  minValue: 0,
                  stepValue: 0.1,
                  thumbStepValue: recipe.multiplier,
                  onChange_Total: stepperChange,
                }}
              />
            )}

            {!!note && (
              <ItemCard
                note={note}
                disabled={parent?.made}
                onEdit={showNote}
              />
            )}
          </div>
        )}
      </Draggable>
    </>
  );
}
