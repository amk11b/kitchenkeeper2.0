import { deleteField } from 'firebase/firestore';
import { nanoid } from 'nanoid';
import { DropResult } from 'react-beautiful-dnd';
import { DEBUG } from '../..';
import { IMealCore, IMealsData, IMealsUpdate } from '../../objects/Meals';
import { DnDType } from '../../objects/types';

// Returns an array of components that contain the smae @parentId sorted by the contained index value
export function getChildren(data: IMealsData, parentId: string) {
  const children: IMealCore[] = [];
  data.forEach(element => {
    if (element.parentId === parentId) children.push(element);
  });
  children.sort((a, b) => a.index < b.index ? -1 : 1 );
  return children;
}

// Bulids and update for firestore, only changes whats needed
export const buildUpdateFromMove = (data: IMealsData, result: DropResult) => {
  if (!result.destination) return; // No destination, no layout change

  const dragged = data.get(result.draggableId);

  const dragType = result.type

  const dId = result.destination.droppableId;
  const sId = result.source.droppableId;

  const dChildren = getChildren(data, result.destination.droppableId);
  const sChildren = getChildren(data, result.source.droppableId);
  const dChildCount = dChildren.length;
  const sChildCount = sChildren.length;
  const drIn = result.destination.index;
  
  const dIn = (result.type === DnDType.COLUMN) ? (drIn) // If dragged is a component, just use the returned index
    : (drIn < dChildCount) ? (drIn) : (drIn > 0) ? drIn - 1 : drIn; // If dragged is a meal, ensure index does not include New Meal button
  const sIn = result.source.index;

  const sameParent = sId === dId;
  const sameIndex = sIn === dIn;

  const splitId = dId.split('-');
  const dropType = splitId[0] ?? 'other';
  const dropTypeDestination = splitId[1] ?? 'other';

  if (DEBUG) {
    if (dropType !== dId) console.log('Drop Type: ', dropType);
    console.log('Drag Type: ', dragType);
    console.log('Destination Id: ', dId);
    console.log('Source Id: ', sId);
    console.log('Destination Indexes: Calculated -', dIn, 'Raw -', drIn);
    console.log('Source Index: ', sIn);
  }

  if (!dragged || (sameParent && sameIndex)) return; // Fake draggable or dropped in same spot, no change

  const update: IMealsUpdate = new Map();

  // Remove components that are dropped in the trash
  if (dropType === 'remove') {
    // Delete component
    update.set(dragged.id, deleteField());
    // Delete meal if empty
    if (sChildCount === 1) 
      update.set(sId, deleteField());
    // No need for anything else if component was being removed
    return update; 
  }

  // Make new Meal and move Component to it
  if (dropType === 'new') {
    if (dropTypeDestination === 'other') return;
    // Get index
    const index = getChildren(data, dropTypeDestination).length;
    // New Meal Id
    const mealId = nanoid();
    // Create empty meal
    update.set(mealId, { id: mealId, parentId: dropTypeDestination, index: index, made: false, remove_on_make: true });
    // Set components parent to new meal
    update.set(dragged.id, { ...dragged, parentId: mealId });
    // Delete meal if empty
    if (sChildCount === 1) 
      update.set(sId, deleteField());
    // No need for anything else
    return update;
  }

  // Update draggables parent and index
  update.set(dragged.id, {...dragged, parentId: dId, index: dIn });

  // Update necessary indexes to remove draggable
  for (let x = sIn; x < sChildCount; x++) {
    const element = sChildren[x];
    if (element.id === dragged.id) continue;
    update.set(element.id, {...element, index: element.index - 1 });
  }

  // Remove meal if was emptied by current drag
  if (dragType === 'COLUMN' && sChildCount === 1) 
    update.set(sId, deleteField());

  // Update necessary index to add draggable
  for (let x = dIn; x < dChildCount; x++) {
    const element = dChildren[x];
    if (element.id === dragged.id) continue;
    update.set(element.id, {...element, index: element.index + (update.has(element.id) ? -1 : 1) });
  }

  return update;
}