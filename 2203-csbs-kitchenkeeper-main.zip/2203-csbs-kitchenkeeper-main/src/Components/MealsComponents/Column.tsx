import { faPlus, faBook, faDoorOpen, faClipboard } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { deleteField, increment } from 'firebase/firestore';
import { nanoid } from 'nanoid';
import { useState } from 'react';
import { Draggable, Droppable } from 'react-beautiful-dnd';
import { Button, Card, ButtonGroup } from 'react-bootstrap';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import { IMealCore, IMealsData } from '../../objects/Meals';
import { DnDType } from '../../objects/types';
import { TSyncState } from '../SyncIndicator';
import { getChildren } from './helpers';
import { Remove } from './Remove';
import { MealComponent } from './MealComponent';

export interface PColumn {
  index: number;
  columnId: string;
  parentId: string;
  data: IMealsData;
  docPath: ReduxFirestoreQuerySetting;
  syncState?: (state: TSyncState) => void;
  addComponent?: (type: DnDType, parentId: string) => void;
  isLast?: boolean;
  onClick?: (e: any) => void;
}

export function Column({ index, columnId, parentId, data, docPath, syncState, addComponent, isLast, onClick }: PColumn) {
  const firestore = useFirestore();
  const columnData = data.get(columnId);

  // Update firestore with sync indicator
  const pushUpdate = (update: any, path?: ReduxFirestoreQuerySetting) => {
    // Update Sync Indicator
    syncState?.('saving');
    // Push update and update sync indicator accordingly
    firestore.update(path ?? docPath, update).then(() => {
      syncState?.('saved');
    }).catch(() => {
      syncState?.('error');
    });
  };
  // Add empty meal
  const addMeal = () => {
    // Create empty meal
    const newMeal: IMealCore = { id: nanoid(), parentId: parentId, index: index, made: false, remove_on_make: true };
    // Apply update
    pushUpdate({ [newMeal.id]: newMeal });
  };
  // Remove meal and update indexes accordingly
  const removeMeal = () => {
    const parentChildren = getChildren(data, parentId);
    const children = getChildren(data, columnId);
    const update: any = { [columnId]: deleteField() };
    // Update only necessary indexes
    for (let x = index + 1; x < parentChildren.length; x++) {
      const element = parentChildren[x];
      update[element.id] = { ...element, index: x - 1 };
    }
    children.forEach((child) => {
      update[child.id] = deleteField();
    });
    // Apply update
    pushUpdate(update);
  };
  // Make the meal - Remove the components from inventory
  const handleMakeMeal = () => {
    // Keep track of totals, helps with with duplicates
    const updateTotals = new Map<string, number>();
    const setTotal = (key: string, amount: number) => updateTotals.set(key, (updateTotals.get(key) ?? 0) + amount);
    // Get components in meal
    const components = getChildren(data, columnId);
    components.forEach((comp) => {
      // Decrement amount in inventory
      if (comp.item && comp.remove_on_make)
        setTotal(comp.item.code, Math.round(( comp.item.package_count ) * 10 ) / 10);
      // Decrement products in inventory that make up a recipe
      if (comp.recipe) console.warn('Remove products used to make recipe from inventory');
      // comp.recipe.products.forEach((prod: { code: string; package_count: number }) => {
      //   setTotal(prod.code, prod.package_count);
      // });
    });
    // Convert to firestore update object
    pushUpdate({ [columnId + '.made']: !data.get(columnId)?.made });
    updateTotals.forEach((total, key) => {
      pushUpdate({ package_count: increment(data.get(columnId)?.made ? total : -Math.abs(total)) }, { ...docPath, subcollections: [{ collection: 'products', doc: key }] });
    });
  };

  const addItem = () => {
    if (addComponent) addComponent(DnDType.ITEM, columnId);
  };
  const addRecipe = () => {
    if (addComponent) addComponent(DnDType.RECIPE, columnId);
  };
  const addNote = () => {
    if (addComponent) addComponent(DnDType.NOTE, columnId);
  };

  const normal = 'outline-secondary';
  const active = 'outline-primary';
  const [isHover, setIsHover] = useState(false);

  const isMade = columnData?.made;

  // Add Meal button if last column
  if (!!isLast)
    return (
      <Draggable draggableId={columnId} index={index} isDragDisabled>
        {(provided) => (
          <div {...provided.draggableProps} ref={provided.innerRef}>
            <Droppable droppableId={'new-' + columnId} direction='horizontal' type={DnDType.COLUMN}>
              {(providedInner) => (
                <div ref={providedInner.innerRef} {...providedInner.droppableProps} className='position-relative h-100 ms-2' style={{ width: '50px' }}>
                  <Button variant={isHover ? active : normal} onClick={addMeal} className='h-75 position-absolute top-50 start-0 translate-middle-y' onMouseEnter={() => setIsHover(true)} onMouseLeave={() => setIsHover(false)}>
                    <FontAwesomeIcon icon={faPlus} />
                    {providedInner.placeholder}
                  </Button>
                </div>
              )}
            </Droppable>
          </div>
        )}
      </Draggable>
    );

  const children = getChildren(data, columnId);

  return (
    <Draggable draggableId={columnId} index={index}>
      {(provided) => (
        <div {...provided.draggableProps} ref={provided.innerRef}>
          <Card className='border-0 m-1 bg-transparent' onClick={onClick} style={{ minWidth: '349px', width: '359px' }}>
            <div {...provided.dragHandleProps} className='d-flex justify-content-between shadow rounded p-2 bg-white' style={{ height: '54px' }}>
              { addComponent && <Remove key={columnId + '-remove'} parentId={columnId} onClick={removeMeal} /> }
              { addComponent && <ButtonGroup aria-label='Add Recipes, Items, and Notes to your meal'>
                <Button variant='secondary' onClick={addRecipe} data-bs-toggle='tooltip' title='Add a Recipe'>
                  <FontAwesomeIcon icon={faBook} className={!children.length ? 'pulsate-color-primary' : ''} />
                </Button>
                <Button variant='secondary' onClick={addItem} data-bs-toggle='tooltip' title='Add an Item'>
                  <FontAwesomeIcon icon={faDoorOpen} className={!children.length ? 'pulsate-color-primary' : ''} />
                </Button>
                <Button variant='secondary' onClick={addNote} data-bs-toggle='tooltip' title='Add a Note'>
                  <FontAwesomeIcon icon={faClipboard} className={!children.length ? 'pulsate-color-primary' : ''} />
                </Button>
              </ButtonGroup> }
            </div>
            <Card.Body className='pe-0'>
              <Droppable droppableId={columnId} isDropDisabled={isMade} direction='vertical' type={DnDType.COLUMN}>
                {(providedInner) => (
                  <div {...providedInner.droppableProps} ref={providedInner.innerRef}>
                    {children.map((component) => (
                      <MealComponent key={component.id} index={component.index} componentId={component.id} data={data} docPath={docPath} />
                    ))}
                    {providedInner.placeholder}
                    {children.length === 0 ? <div className='rounded bg-white py-2 px-3 shadow text-muted'>This meal is empty</div> : null}
                  </div>
                )}
              </Droppable>
              <Button variant={isMade ? 'secondary' : 'primary'} className='w-100 shadow mt-3' onClick={handleMakeMeal}>
                {isMade ? 'Undo' : 'Make'}
              </Button>
            </Card.Body>
          </Card>
        </div>
      )}
    </Draggable>
  );
}
