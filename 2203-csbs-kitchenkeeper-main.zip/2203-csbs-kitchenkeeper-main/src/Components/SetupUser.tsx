import { Button, FormControl, InputGroup, Modal } from 'react-bootstrap';
import { useState } from 'react';
import { ScaleLoader } from 'react-spinners';
import { QrReader } from '@blackbox-vision/react-qr-reader';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faQrcode } from '@fortawesome/free-solid-svg-icons'
import { useFirestore } from 'react-redux-firebase';
import { useSelector } from 'react-redux';
import { e_change } from '../objects/types';

export default function SetupUser() {
  const firestore = useFirestore();
  const auth = useSelector((state: any) => state.firebase.auth);
  const [show] = useState(true);
  const [showQr, setShowQr] = useState(false);
  const [create, setCreate] = useState(false);
  const [startJoin, setStartJoin] = useState(false);
  const [join, setJoin] = useState(false);
  const [dataId, setDataId] = useState('');

  const [ranCreate, setRanCreate] = useState(false);
  const [ranJoin, setRanJoin] = useState(false);

  const createUserData = async () => {
    await firestore.collection('data').doc(auth.uid).set({ active: true, dataId: auth.uid });
    setDataId(auth.uid);
    setJoin(true);
  }

  if (create && !ranCreate) {
    setRanCreate(true);
    console.log('Create user data file...');
    createUserData();
  }

  if (join && !ranJoin) {
    setRanJoin(true);
    console.log('Create user profile...');
    firestore.collection('users').doc(auth.uid).set({ dataId: dataId, unitSystem: 'imperial' });
  }

  const validateDataId = (value: string) => value.length === 20 && /^[A-Za-z0-9]*$/.test(value);
  const isInvalidDataId = dataId.length > 20 && !(/^[A-Za-z0-9]*$/.test(dataId));
// this is a test of the wakatime plugin thingy
  return (
    <>
    <Modal size='sm' backdrop='static' keyboard={false} show={show} centered>
      <Modal.Header>
        <Modal.Title>Initial Setup</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="d-grid gap-2">
          { startJoin ? <>
            <InputGroup hasValidation>
              <FormControl placeholder='Join Code' aria-label='Join Code' aria-describedby='startQr' value={dataId} onChange={(e: e_change) => setDataId(e.currentTarget.value)} isInvalid={isInvalidDataId} isValid={validateDataId(dataId)} />
              <Button variant='outline-secondary' disabled={join} id='startQr' onClick={() => setShowQr(true)}><FontAwesomeIcon icon={ faQrcode } /></Button>
            </InputGroup>
            <Button variant='primary' disabled={!validateDataId(dataId) || join} onClick={() => setJoin(true)}>{ join ? <ScaleLoader color='#DC8B32' /> : 'Join' }</Button>
            <Button variant='secondary' disabled={join} onClick={() => setStartJoin(false)}>back</Button>
          </> : <>
            <Button variant='primary' disabled={create} onClick={() => setStartJoin(true)}>Join Another</Button>
            <Button variant='secondary' disabled={create} onClick={() => setCreate(true)}>{ create ? <ScaleLoader color='#DC8B32' /> : 'Create Personal' }</Button>
          </> }
        </div>
      </Modal.Body>
    </Modal>

    <Modal size='sm' show={showQr} onHide={() => setShowQr(false)} centered>
      <Modal.Header closeButton />
      <Modal.Body>
        { showQr ? <DataIdReader onRead={value => { setDataId(value); setShowQr(!validateDataId(value)); }} /> : 'Cannot Load Qr Reader' }
      </Modal.Body>
    </Modal>
    </>
  );
}

function DataIdReader(props: { onRead: (value: string) => void }) {
  return <QrReader 
    onResult={(result, error) => error ? (error.name !== 'NotFoundException' ? console.log(error) : null) : result?.getText() ? props.onRead(result.getText()) : null }
    scanDelay={500}
    videoContainerStyle={{ paddingTop: '75%' }}
    constraints={{ facingMode: 'environment' }} />
}