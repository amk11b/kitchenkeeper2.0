import { nanoid } from 'nanoid';
import { CSSProperties } from 'react';

export interface PCustomText {
  text: string;
  wrapPoints?: number[];
  className?: string;
  style?: CSSProperties;
  wrapProps?: {};
  center?: boolean;
  shadowPoint?: number;
  noWrap?: boolean;
}

export function CustomText({ text, wrapPoints, noWrap, shadowPoint, className, wrapProps, style, center }: PCustomText) {
  const textArr = text.split(' ');
  const formattedText: string[] = [];

  if (wrapPoints) {
    let wrapPointIndex = 0;
    textArr.forEach((value) => {
      const wrapPoint = wrapPoints[wrapPointIndex] ?? wrapPoints.at(-1);
      if (value.length + (formattedText[wrapPointIndex]?.length ?? 0) > wrapPoint) wrapPointIndex++;
      formattedText[wrapPointIndex] = (formattedText[wrapPointIndex] ?? '') + ' ' + value;
    });
  }

  const textClasses: string[] = [];

  if (center) textClasses.push('text-center');
  if (shadowPoint && text.length > shadowPoint) textClasses.push('textFadeout');
  if (noWrap) textClasses.push('text-nowrap')

  return (
    <span {...wrapProps} style={style} className={'vstack ' + className}>
      {wrapPoints ? formattedText.map((value) => <span key={nanoid()}>{value}</span>) :
        <span className={textClasses.join(' ')}>{text}</span> }
    </span>
  );
}
