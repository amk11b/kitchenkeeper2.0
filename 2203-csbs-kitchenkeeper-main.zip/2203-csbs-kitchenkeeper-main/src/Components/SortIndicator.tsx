import { faSortUp, faSortDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Form } from 'react-bootstrap';
import { filter } from '../objects/types';

export interface PSortIndicator {
  filter: filter;
  setFilter: (filter: filter) => void;
}

export function SortIndicator({ filter, setFilter }: PSortIndicator) {
  const toggleSort = () => setFilter({...filter, direction: ( filter.direction === 'asc' ? 'desc' : 'asc' ) });
  const toggleState = () => setFilter({...filter, active: !filter.active });

  return (
    <div className='hstack gap-3' onClick={ (e) => e.stopPropagation() }>
      <Form.Check type='checkbox' label={filter.label} checked={filter.active} onChange={toggleState} />
      <div className='ms-auto hstack gap-0' onClick={toggleSort}>
        <FontAwesomeIcon className={filter.direction === 'asc' ? '' : 'text-muted'} icon={faSortUp} />
        <FontAwesomeIcon className={filter.direction === 'desc' ? '' : 'text-muted'} icon={faSortDown} />
      </div>
    </div>
  );
}