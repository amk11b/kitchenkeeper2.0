import { useEffect } from 'react';
import { ToastContainer, Toast } from 'react-bootstrap';
import { CustomText } from './CustomText';

export interface PToastNotification {
  show: boolean;
  text?: string;
  prefix?: string;
  bg?: 'primary' | 'danger' | 'info' | 'success' | 'warning';
  delay?: number;
  onHide: () => void;
}

export function ToastNotification({ show, onHide, text = 'An Error Occurred', bg = 'danger', delay = 3000, prefix }: PToastNotification) {
  useEffect(() => {
    if (show) setTimeout(onHide, delay);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [show]);

  return (
    <ToastContainer className='p-3' position='bottom-end'>
      <Toast bg={bg} show={show}>
        <Toast.Body className='text-white fw-bold hstack gap-3 px-4'>
          { prefix && <span>{prefix}</span> }
          <CustomText text={text} wrapPoints={[32]} />
        </Toast.Body>
      </Toast>
    </ToastContainer>
  );
}
