import { faSearch, faTimes } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Button, FormControl, InputGroup } from 'react-bootstrap';
import { e_change, e_key } from '../objects/types';
import { ReduxFirestoreQuerySetting, useFirestore } from 'react-redux-firebase';
import { useState } from 'react';

export interface PInventorySearch {
  path: ReduxFirestoreQuerySetting;
  autofocus?: boolean;
  className?: string;
  isActive?: (state?: boolean) => void;
}

export default function InventorySearch({ path, autofocus, className, isActive }: PInventorySearch) {
  const firestore = useFirestore();
  const [searchText, setSearchText] = useState('');
  const [showClear, setShowClear] = useState(false);

  const search = () => {
    isActive?.(true);
    const keywords = searchText.split(' ').map((text) => text.toLocaleLowerCase());
    firestore.get({ ...path, subcollections: [{ collection: 'products', where: [['keywords', 'array-contains-any', keywords]] }], storeAs: 'InventorySearchResults' });
  };

  const clear = () => {
    setSearchText('');
    setShowClear(false);
    isActive?.(false);
  };

  const handleInputChange = (e: e_change) => {
    const txt = e.currentTarget.value;
    setSearchText(txt);
    setShowClear(!!txt.trim());
    if (!txt) isActive?.(false);
  };

  return (
    <div className={className + ' position-relative'}>
      <InputGroup>
        <FormControl placeholder='Search...' aria-label='Search existing Pantry Items' autoFocus={autofocus} onChange={handleInputChange} onKeyDown={(e: e_key) => e.key === 'Enter' && search()} value={searchText} />
        <Button variant='primary px-4' onClick={search}>
          <FontAwesomeIcon icon={faSearch} />
        </Button>
      </InputGroup>

      {showClear && (
        <Button variant='' className='position-absolute top-0' style={{ right: '66px', zIndex: 5 }} onClick={clear}>
          <FontAwesomeIcon className='text-muted' icon={faTimes} />
        </Button>
      )}
    </div>
  );
}
