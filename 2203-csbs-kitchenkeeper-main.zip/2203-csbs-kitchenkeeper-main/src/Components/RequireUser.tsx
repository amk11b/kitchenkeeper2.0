import { useSelector } from 'react-redux';
import { isEmpty, isLoaded } from 'react-redux-firebase';
import { Navigate } from 'react-router';
import LoadingSpinner from './loadingSpinner';
import SetupUser from './SetupUser';

export default function RequireUser({ children }: { children: JSX.Element }) {
  const auth = useSelector((state: any) => state.firebase.auth);
  const profile = useSelector((state: any) => state.firebase.profile);

  if (!isLoaded(auth)) return <LoadingSpinner />;
  if (isEmpty(auth)) return <Navigate to="/login" />;
  if (!isLoaded(profile)) return <LoadingSpinner />;
  if (isLoaded(profile) && isEmpty(profile)) return <SetupUser />;
  
  return children;
}