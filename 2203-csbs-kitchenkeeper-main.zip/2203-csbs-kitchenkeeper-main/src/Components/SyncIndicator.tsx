import { faCheck, faCloud, faCloudArrowDown, faCloudArrowUp, faExclamation } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useCallback, useEffect, useState } from 'react';
import { debounce } from 'lodash';
import { useSelector } from 'react-redux';

export type TSyncState = 'saving' | 'saved' | 'error' | 'downloading' | 'done' | 'auto';

export interface PSyncIndicator {
  forceState?: TSyncState;
  className?: string;
}

export default function SyncIndicator({ forceState, className }: PSyncIndicator) {
  const [styles, setStyles] = useState('text-secondary');
  const [icon, setIcon] = useState(faCloud);
  const [state, setState] = useState(forceState ?? 'done');
  const status = useSelector((state: any) => state.firestore.status.requesting);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedStyles = useCallback(debounce(style => setStyles(style), 2000), []);

  useEffect(() => {
    setState(forceState ?? getStateFromStatus());
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, forceState]);

  useEffect(() => {
    styleIndicator();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  function getStateFromStatus(): TSyncState {
    if ( Object.values(status).some( val => val ) )
      return 'downloading';
    return 'done';
  }

  function styleIndicator() {
    switch(state) { 
      case 'saving': { 
        setIcon(faCloudArrowUp);
        setStyles('text-warning');
        break; 
      }
      case 'downloading': { 
        setIcon(faCloudArrowDown);
        setStyles('text-warning');
        break; 
      }
      case 'saved': {
        setIcon(faCloud);
        setStyles('text-success');
        debouncedStyles('text-secondary');
        break; 
      }
      case 'done': {
        setIcon(faCheck);
        setStyles('text-success');
        debouncedStyles('text-secondary');
        break;
      } 
      case 'error': {
        setIcon(faExclamation);
        setStyles('text-danger');
        break;
      }
      default: {
        setIcon(faCloud);
        setStyles('text-secondary');
        break; 
      } 
    }
  }

  return (
    <span className={ 'px-2 my-auto ' + styles + ' ' + className }>
      <FontAwesomeIcon icon={ icon } className='pe-2' />
      { state }
    </span>
  );
}
