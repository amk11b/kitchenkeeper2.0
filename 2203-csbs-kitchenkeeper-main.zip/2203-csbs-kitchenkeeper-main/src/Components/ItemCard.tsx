import { NumericStepper } from './numericStepper';
import { CustomText } from './CustomText';
import { debounce } from 'lodash';
import { useCallback, useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faCheck } from '@fortawesome/free-solid-svg-icons';
import { Button } from 'react-bootstrap';
import { FaRegSquare } from 'react-icons/fa';
import { e_click } from '../objects/types';

export interface PItemCard {
  stepper?: {
    minValue?: number;
    maxValue?: number;
    stepValue?: number;
    thumbStepValue?: number;
    value: number;
    onChange_Total?: (value: number) => void;
    onChange_Amount?: (value: number) => void;
    valueOverride?: number;
  };
  badge?: {
    bg: CardColor;
    text: string;
  };
  thumb?: {
    bg?: CardColor;
    valuePrefix?: string;
  };
  note?: null | string;
  img?: null | string;
  title?: string;
  labels?: null | string;
  displayValue?: null | number;
  subDisplayValue?: null | number;
  subDisplayValueUnit?: null | string;
  valueLabel?: null | string;
  onEdit?: () => void;
  onToggle?: () => void;
  toggleState?: boolean;
  className?: string;
  borderColor?: CardColor;
  border?: boolean;
  selected?: null | boolean;
  onClick?: () => void;
  disabled?: boolean;
}

export enum CardColor {
  'primary' = '#DC8B32' as any,
  'danger' = '#E74C3C' as any,
  'success' = '#2ECC71' as any,
  'info' = '#3498DB' as any,
}

export const cardColorKey = (color: CardColor) => CardColor[color];

export default function ItemCard(props: PItemCard) {
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const changeValueDebounce = useCallback(
    debounce((value, valRef) => {
      props.stepper?.onChange_Total?.(value);
      props.stepper?.onChange_Amount?.(value - valRef);
      setCardValue(value);
    }, 999),
    []
  );

  useEffect(() => {
    setCardValue(props.stepper?.value ?? props.displayValue ?? (props.note ? 1 : 0));
  }, [props.stepper?.value, props.displayValue, props.note]);

  const [cardValue, setCardValue] = useState(props.stepper?.value ?? props.displayValue ?? (props.note ? 1 : 0));
  const [liveValue, setLiveValue] = useState(cardValue);

  const handleStepper = (value: number) => {
    if (props.disabled) return;
      changeValueDebounce(value, cardValue);
      setLiveValue(value);
  }

  // Set border color to red if quantity is 0 or orange if selected is true
  let border = liveValue <= 0 ? 'border-danger' : props.borderColor ? `border-${cardColorKey(props.borderColor)}` : 'border-white';
  if (props.selected) border = 'border-primary'; // Selection overrides quantity notice
  if (props.border === false) border = 'border-white';

  const colors = props.stepper ? { c1: '#DC8B32', c2: 'rgba(108 117 125, .1)', c3: '#adadad' } : { c1: '#DC8B32', c2: '#f5f2ea', c3: '#fff' };

  // @ts-ignore
  if (props.thumb?.bg) colors.c1 = props.thumb.bg;
  if (liveValue <= 0) colors.c1 = '#E74C3C';

  if (props.note)
    return (
      <div className={props.className} onClick={props.disabled ? undefined : props.onClick} style={{ width: '340px' }}>
        <div className='position-relative'>
          <span data-disabled={props.disabled} className='noteCard-disable' />
          <div className={'bg-white rounded shadow position-relative border border-2 p-4 text-center ms-auto ' + border } style={{ width: '332px' }}>
            <span>{props.note}</span>
          </div>
          { props.onEdit && <Button variant='' className='position-absolute end-0 top-0 text-white-200 pe-2 pt-2' onClick={(e: e_click) => { e.stopPropagation(); props.onEdit?.(); }} style={{ zIndex: 2 }}>
            <FontAwesomeIcon icon={faEdit} />
          </Button> }
          { props.onToggle && <Button variant='' className='position-absolute end-0 bottom-0 pe-2 pt-2' onClick={(e: e_click) => { e.stopPropagation(); props.onToggle?.(); }} style={{ zIndex: 2 }}>
            { props.toggleState && <FontAwesomeIcon icon={faCheck} className='text-primary' /> }
            { !props.toggleState && <FaRegSquare className='text-white-200' /> }
          </Button> }
        </div>
      </div>
    );

  return (
    <div className={props.className} onClick={props.disabled ? undefined : props.onClick}>
      <div className='position-relative' style={{ width: '335px', paddingLeft: '50px' }}>
        <span data-disabled={props.disabled} className='itemCard-disable' />
        <div className={'card-wrapper bg-white rounded shadow position-relative border border-2 ' + border}>
          {props.badge && (
            <span className={'position-absolute top-0 start-100 translate-middle badge rounded-pill bg-' + cardColorKey(props.badge.bg)} style={{ zIndex: 1 }}>
              {props.badge.text}
            </span>
          )}
          {props.img && <img className='rounded position-absolute top-50 start-0 translate-middle bg-secondary' style={{ objectFit: 'cover', width: '86px', height: '86px', zIndex: 3 }} src={props.img} alt='' />}
          <span className='position-absolute' style={{ top: '2px', left: props.img ? '60px' : '16px', right: '16px' }}>
            { props.title && <CustomText className='text-secondary fw-bold' shadowPoint={28} noWrap text={props.title} center /> }
          </span>
          <span className='position-absolute text-muted' style={{ bottom: '6px', left: props.img ? '60px' : '16px' }}>
            {props.labels}
          </span>
          <span className='position-absolute text-muted' style={{ bottom: '6px', right: '16px' }}>
            {props.subDisplayValue}
            <sub>{props.subDisplayValueUnit}</sub>
          </span>
          { props.onEdit && <Button variant='' className='position-absolute end-0 text-white-200 pe-1' onClick={(e: e_click) => { e.stopPropagation(); props.onEdit?.(); }} style={{ top: '65%', zIndex: 2 }}>
            <FontAwesomeIcon icon={faEdit} />
          </Button> }
          { props.onToggle && <Button variant='' className='position-absolute end-0 pe-2' onClick={(e: e_click) => { e.stopPropagation(); props.onToggle?.(); }} style={{ top: '65%', zIndex: 2 }}>
            { props.toggleState && <FontAwesomeIcon icon={faCheck} className='text-primary' /> }
            { !props.toggleState && <FaRegSquare className='text-white-200' /> }
          </Button> }
          <div className='position-absolute end-0 text-muted' style={{ paddingRight: '32px', top: '70%' }}>
            {props.valueLabel}
          </div>
          <div className='position-absolute top-50 end-0 translate-middle-y' style={{ paddingRight: '16px' }} onClick={ (e) => e.stopPropagation() }>
            <NumericStepper
              size='xsm'
              enabled={!!props.stepper && !props.disabled}
              thumbColor={colors.c1}
              activeButtonColor={colors.c2}
              inactiveIconColor={colors.c3}
              inactiveTrackColor={colors.c2}
              activeTrackColor={colors.c3}
              disabledIconColor={colors.c2}
              hoverIconColor={colors.c2}
              valuePrefix={props.thumb?.valuePrefix}
              initialValue={props.stepper?.value}
              minimumValue={props.stepper?.minValue ?? 0}
              maximumValue={props.stepper?.maxValue}
              stepValue={props.stepper?.stepValue ?? 1}
              thumbStepValue={props.stepper?.thumbStepValue ?? 1}
              valueOverride={props.stepper?.valueOverride ?? props.displayValue ?? undefined}
              thumbShadowAnimationOnTrackHoverEnabled={false}
              onChange={handleStepper}
              // onIncrement={ }
              // onDecrement={ }
            />
          </div>
        </div>
      </div>
    </div>
  );
}
