import { useCallback, useEffect, useState, MouseEvent } from 'react';
import { useSelector } from 'react-redux';
import moment, { Moment } from 'moment';
import { Button, ButtonGroup, Dropdown, ToggleButton, ToggleButtonGroup } from 'react-bootstrap';
import { faAngleLeft, faAngleRight, faCalendarWeek } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import SyncIndicator, { TSyncState } from '../Components/SyncIndicator';
import { Days, DnDType } from '../objects/types';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import Row from '../Components/MealsComponents/Row';
import { ReduxFirestoreQuerySetting, useFirestore, useFirestoreConnect } from 'react-redux-firebase';
import { IMealsData } from '../objects/Meals';
import { buildUpdateFromMove, getChildren } from '../Components/MealsComponents/helpers';
import LoadingSpinner from '../Components/loadingSpinner';
import AddProductsModal from '../Components/Modals/AddProductsModal';
import { IProducts } from '../objects/Product';
import { MealsConverter, RecipeToDisplay } from '../helpers/converters';
import { nanoid } from 'nanoid';
import WeekPickerModal from '../Components/MealsComponents/WeekPicker';
import { debounce } from 'lodash';
import { IRecipe } from '../objects/Recipe';
import AddRecipeModal from '../Components/Modals/AddRecipeModal';
import NoteModal from '../Components/Modals/NoteModal';

export default function Meals() {
  const firestore = useFirestore();
  const [mealsIndex, setMealsIndex] = useState(0);
  const [liveMealsIndex, setLiveMealsIndex] = useState(0);
  const currentWeek = moment().startOf('week');
  const selectedDate = moment().add(mealsIndex, 'weeks');
  const selectedWeek = selectedDate.clone().startOf('week');
  const weekId = selectedWeek.format('YYYYMD').toString();
  const profile = useSelector((state: any) => state.firebase.profile);
  const docPath: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'meals', doc: weekId }] };
  useFirestoreConnect({ ...docPath, storeAs: 'meals' });
  const firestoreMeals = useSelector((state: any) => state.firestore.data.meals);
  const [data, setData] = useState<IMealsData>(new Map());
  const [syncState, setSyncState] = useState<TSyncState>('downloading');
  const [addComponent, setAddComponent] = useState({ show: false, type: DnDType.ITEM, parentId: '' });
  const today = moment().format('dddd') as Days;
  const [filter, setFilter] = useState<Days | 'View All'>(today);
  const showAll = filter === 'View All';
  const [showDate, setShowWeek] = useState(false);

  // Debounce for the meals indexing to reduce reads when user spams button
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const debouncedIndex = useCallback(debounce((index) => setMealsIndex(index), 500), []);
  // Generate/Reset meals doc if needed
  useEffect(() => {
    if (firestoreMeals !== undefined && firestoreMeals === null) firestore.set(docPath, {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [docPath, firestoreMeals]);
  // Update local state to match cloud state
  useEffect(() => {
    if (firestoreMeals) {
      setData(MealsConverter.fromFirestore(firestoreMeals));
      setSyncState(data.size === 0 ? 'done' : 'saved');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firestoreMeals]);
  // Wait for meals doc to be generated/reset
  if (!firestoreMeals) return <LoadingSpinner />;
  // Handle layout changes
  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return; // No destination, no layout change
    // Update only whats needed where its needed
    const update = buildUpdateFromMove(data, result);
    if (!update) return;
    // push update
    pushUpdate(MealsConverter.toFirestore(update));
    // Save local layout to prevent visual glitches
    setData(new Map([...data, ...(update as IMealsData)]));
  };

  // Push updates to firestore with syncstate updates
  const pushUpdate = (update: any) => {
    // Update Sync Indicator
    setSyncState('saving');
    // Push update and update sync indicator accordingly
    firestore.update(docPath, update).then(() => {
      setSyncState('saved');
    }).catch(() => {
      setSyncState('error');
    });
  };
  // Handle setting syncstate
  const handleSyncState = (state: TSyncState) => setSyncState(state);
  // Set show, type, and id of the column that requested to add a component
  const handleAddComponent = (type: DnDType, parentId: string) => setAddComponent({ show: true, type: type, parentId: parentId });
  // Hide Add Component Modals
  const handleHideAddComponent = () => setAddComponent({ ...addComponent, show: false });
  // Handle adding new Items from results
  const handleAddProductsResults = (products: IProducts) => {
    // Find initial index for components
    let index = getChildren(data, addComponent.parentId).length;
    // Create new components while incrementing index
    const components: IMealsData = new Map();
    products.forEach((product) => {
      const id = nanoid();
      components.set(id, { id: id, parentId: addComponent.parentId, index: index, remove_on_make: true, item: {
        code: product.code,
        product_name: product.product_name,
        package_count: 1, // Default quantity to 1
        image_url: product.image_url,
        package_size: product.package_size,
        package_size_unit: product.package_size_unit,
      }});
    });
    pushUpdate(MealsConverter.toFirestore(components));
    handleHideAddComponent();
  };
  // Handle adding new Recipes from results
  const handleAddRecipeResult = (recipe: IRecipe) => {
    // Find initial index for components
    let index = getChildren(data, addComponent.parentId).length;
    const id = nanoid();
    pushUpdate({ [id]: { id: id, parentId: addComponent.parentId, index: index, stepper_type: 'Servings', remove_on_make: true, recipe: RecipeToDisplay(recipe) } });
    handleHideAddComponent();
  };
  const handleAddNoteResult = (note: string) => {
    let index = getChildren(data, addComponent.parentId).length;
    const id = nanoid();
    pushUpdate({ [id]: { id: id, parentId: addComponent.parentId, index: index, note: note } });
    handleHideAddComponent();
  };
  // Handle returned moment from week picker. Find week endex and save
  const handleWeekPickerSubmit = (newWeek: Moment) => {
    const index = newWeek.diff(currentWeek, 'weeks');
    setMealsIndex(index);
    setLiveMealsIndex(index);
    setShowWeek(false);
  };
  // Hide Week Picker Modal
  const handleHideWeekPicker = () => setShowWeek(false);

  const handleChangeMealsIndex = (e: MouseEvent<HTMLButtonElement>) => {
    const change = e.currentTarget.getAttribute('data-change');
    e.stopPropagation();
    if (change === 'weekpicker') return setShowWeek(true);
    debouncedIndex(liveMealsIndex + (change === 'remove' ? -1 : 1));
    setLiveMealsIndex(liveMealsIndex + (change === 'remove' ? -1 : 1));
  };

  return (
    <>
      <AddProductsModal show={addComponent.show && addComponent.type === DnDType.ITEM} onHide={handleHideAddComponent} resultCallback={handleAddProductsResults} path={docPath} />
      <AddRecipeModal show={addComponent.show && addComponent.type === DnDType.RECIPE} onHide={handleHideAddComponent} resultCallback={handleAddRecipeResult} />
      <NoteModal show={addComponent.show && addComponent.type === DnDType.NOTE} onHide={handleHideAddComponent} resultCallback={handleAddNoteResult} />
      <WeekPickerModal show={showDate} current={selectedWeek} onHide={handleHideWeekPicker} onSubmit={handleWeekPickerSubmit} />

      <div className='d-flex text-nowrap flex-nowrap justify-content-between gap-3 px-5 py-3'>
        {/* <h4 className='text-muted d-none d-sm-block'>Meal Plan</h4> */}
        <div className='d-none d-sm-block'></div>

        <div className='d-flex gap-3'>
          {/* Visible on anything larger then md */}
          <Button className='d-none d-lg-block' variant={filter === 'View All' ? 'primary' : 'secondary'} onClick={() => setFilter('View All')}>
            View All
          </Button>
          {/* Visible on extra large screens or bigger */}
          <ToggleButtonGroup className='d-none d-xl-block' type='radio' name='daySelector' value={filter}>
            {Object.values(Days).map((day) => (
              <ToggleButton key={'daySelectorXl' + day} onClick={() => setFilter(day)} variant={day === filter ? 'primary' : 'secondary'} className={day === today ? 'fw-bold' : ' '} value={day}>
                {day}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
          {/* Visislbe on large screens */}
          <ToggleButtonGroup className='d-none d-lg-block d-xl-none' type='radio' name='daySelector' value={filter}>
            {Object.values(Days).map((day) => (
              <ToggleButton key={'daySelectorLg' + day} onClick={() => setFilter(day)} variant={day === filter ? 'outline-primary' : 'secondary'} className={day === today ? 'fw-bold' : ' '} value={day}>
                {day.substring(0, 3)}
              </ToggleButton>
            ))}
          </ToggleButtonGroup>
          {/* Visible on screens md and smaller */}
          <Dropdown className='d-md-block d-lg-none'>
            <Dropdown.Toggle variant='secondary' style={{ width: '8rem' }}>
              {filter}
            </Dropdown.Toggle>
            <Dropdown.Menu variant='dark' style={{ minWidth: '8rem' }}>
              <Dropdown.Item className='p-0 d-sm-none'>
                <ButtonGroup className='w-100 rounded-0'>
                  <Button className='rounded-0' variant='secondary' onClick={handleChangeMealsIndex} data-change='remove'>
                    <FontAwesomeIcon icon={faAngleLeft} />
                  </Button>
                  <Button className='rounded-0' variant='secondary' onClick={handleChangeMealsIndex} data-change='weekpicker'>
                    <FontAwesomeIcon icon={faCalendarWeek} />
                  </Button>
                  <Button className='rounded-0' variant='secondary' onClick={handleChangeMealsIndex} data-change='add'>
                    <FontAwesomeIcon icon={faAngleRight} />
                  </Button>
                </ButtonGroup>
              </Dropdown.Item>
              <Dropdown.Divider className='d-sm-none' />
              {Object.values(Days).map((day) => (
                <Dropdown.Item key={'daySelectorDropDown' + day} onClick={() => setFilter(day)} className={(day === today ? 'fw-bold' : ' ') + (day === filter ? ' bg-primary' : ' ')} value={day}>
                  {day}
                </Dropdown.Item>
              ))}
              <Dropdown.Divider />
              <Dropdown.Item key='FilterSelectorViewAll' value='View All' className={'fw-bold' + (filter === 'View All' ? ' bg-primary' : ' ')} onClick={() => setFilter('View All')}>
                View All
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>

          <ButtonGroup className='d-none d-sm-block'>
            <Button variant='secondary' onClick={handleChangeMealsIndex} data-change='remove'>
              <FontAwesomeIcon icon={faAngleLeft} />
            </Button>
            <Button variant='secondary' onClick={handleChangeMealsIndex} data-change='weekpicker'>
              <FontAwesomeIcon icon={faCalendarWeek} />
            </Button>
            <Button variant='secondary' onClick={handleChangeMealsIndex} data-change='add'>
              <FontAwesomeIcon icon={faAngleRight} />
            </Button>
          </ButtonGroup>
        </div>

        <SyncIndicator forceState={syncState} />
      </div>

      {!!mealsIndex && <div className='w-100 text-center'>
        <span className='mx-auto text-muted fw-bold'>{selectedWeek.format('MMM Do YY')} - {selectedWeek.clone().endOf('week').format('MMM Do YY')}</span>
      </div>}
      
      <DragDropContext onDragEnd={handleDragEnd}>
        {showAll ? Object.values(Days).map((day, index) => <Row key={day} rowId={day} label={selectedWeek.clone().add(index, 'day').format('dddd MMM Do')} data={data} docPath={docPath} syncState={handleSyncState} addComponent={handleAddComponent} />)
        : <Row key={filter} rowId={filter} label={selectedDate.format('dddd MMM Do')} data={data} docPath={docPath} syncState={handleSyncState} addComponent={handleAddComponent} isOnly />}
      </DragDropContext>

      { syncState === 'saving' && <div className='position-absolute start-0 end-0 top-0 bottom-0' style={{ zIndex: 5, backgroundColor: 'rgba(1,1,1,0.1)' }} /> }
    </>
  );
}
