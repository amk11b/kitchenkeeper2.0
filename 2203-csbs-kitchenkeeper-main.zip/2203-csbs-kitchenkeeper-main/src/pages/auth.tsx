import StyledFirebaseAuth from 'react-firebaseui/StyledFirebaseAuth';
import { getAuth } from 'firebase/auth';
import { isEmpty, useFirebase } from 'react-redux-firebase';
import { useSelector } from 'react-redux';

export default function Auth() {
  const firebase = useFirebase();
  const auth = useSelector((state: any) => state.firebase.auth);

  // Configure FirebaseUI.
  const uiConfig = {
    signInFlow: 'popup',
    signInSuccessUrl: '/dashboard',
    signInOptions: ['google.com'],
  };

  if (isEmpty(auth)) {
    return (
      <div className='text-center p-3 pt-5'>
        <h1 className='py-5'>Kitchen Keeper</h1>
        <StyledFirebaseAuth uiConfig={uiConfig} firebaseAuth={getAuth(firebase.app)} />
      </div>
    );
  }

  return (
    <div className='text-center p-3 pt-5'>
      <h1 className='py-5'>Kitchen Keeper</h1>
      <span>Welcome {firebase.auth().currentUser?.displayName}! You are now signed-in!</span>
    </div>
  );
}
