import { Outlet } from 'react-router-dom';
import Categories from '../Components/RecipeComponents/Category';
import Search from '../Components/RecipeComponents/Search';

export default function Recipes() {
  return (
    <>
      <div className='px-5 mx-auto my-4 vstack gap-4' style={{ maxWidth: '648px' }}>
        <Search />
        <Categories />
      </div>
      <Outlet />
    </>
  );
}