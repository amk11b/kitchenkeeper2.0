
export default function Landing() {
  return (
    <div className="mx-auto text-center">
      <h1>Your Best Kitchen Companion!</h1>
      <p className="about-para">
        Keep track of all your kitchen consumables.
        <br />
        Automatically generate your shopping List.
        <br />
        Power your dinners with AI meal suggestions!
      </p>
      <br />

      <br />

      <img src="./inventory.svg" alt=""/>
      <p className="about-para">
        Manually enter or scan your consumable
        <br />
        items to add to your kitchen inventory.
      </p>
      <br />

      <img src="./recipes.svg" alt=""/>
      <p className="about-para">
        See all recipes from a large database,
        <br />
        or use our AI to suggest recipes with what you
        <br />
        currently have in inventory.
      </p>
      <br />

      <img src="./shopping.svg" alt=""/>
      <p className="about-para">
        As you use your inventory, KitchenKeeper
        <br />
        will automatically track what you use and
        <br />
        generate a shopping list.
      </p>
      <br />
    </div>
  );
}
