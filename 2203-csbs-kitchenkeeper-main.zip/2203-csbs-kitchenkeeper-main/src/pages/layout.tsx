import { Outlet} from 'react-router-dom';
import Sidebar from '../Components/Sidebar/sidebar';

export default function Layout() {
  return (
    <div className='App'>
      <script src='https://developer.edamam.com/attribution/badge.js'></script>

      <Sidebar />

      <div className='page-wrapper'>
        <Outlet />
      </div>

      <footer className='footer border-top'>
        <span>Made by Team: Publish or Bust | A Full Sail University Team | Development Started: 03/16/2022 |</span>
        <button onClick={() => window.location.href = 'mailto:cadodson@student.fullsail.edu?subject=Feedback_On_KitchenKeeper&body=Description' }
          title='support@example.com' className='click-me'>Contact Us</button>
      </footer>
    </div>
  );
}
