import { useFirestore, useFirebase } from 'react-redux-firebase';
import { useSelector } from 'react-redux';
import { IProfile } from '../objects/Profile';
import { Button, ToggleButton } from 'react-bootstrap';
import { useCallback, useState } from 'react';
import QRCode from 'react-qr-code';
import { ToastNotification } from '../Components/ToastNotification';
import LoadingSpinner from '../Components/loadingSpinner';
import moment from 'moment';
import { NumericStepper } from '../Components/numericStepper';
import { debounce } from 'lodash';

export default function Settings() {
  const firestore = useFirestore();
  const firebase = useFirebase();
  const auth = useSelector((state: any) => state.firebase.auth);
  const profile = useSelector((state: any) => state.firebase.profile as IProfile);
  const path_profile = 'users/' + auth.uid;
  const [showConfirm, setShowConfirm] = useState(false);
  const [showError, setShowError] = useState(false);
  const [showReAuth, setShowReAuth] = useState(false);
  const [loading, setLoading] = useState(false);

  const deleteFailed = () => {
    setShowConfirm(false);
    setShowError(true);
    setLoading(false);
  };

  const mustReauth = () => {
    setShowConfirm(false);
    setShowReAuth(true);
    setLoading(false);
  };

  const deleteAccount = async () => {
    setLoading(true);
    const auth = firebase.auth();
    if (!auth.currentUser) return deleteFailed();
    if (moment().diff(auth.currentUser.metadata.lastSignInTime, 'minutes') >= 5) return mustReauth();
    const batch = firestore.batch();
    batch.delete(firestore.collection('users').doc(auth.currentUser.uid));
    if (auth.currentUser.uid === profile.dataId) batch.delete(firestore.collection('data').doc(profile.dataId));
    await batch.commit();
    await auth.currentUser.delete();
    await firebase.logout();
  };

  const confirm = () => setShowConfirm(true);
  const hideError = () => setShowError(false);
  const hideReAuth = () => setShowReAuth(false);

  const toggleExpirationNotification = () => firestore.update(path_profile, { expiration_notification: !profile.expiration_notification });

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const expirationNoticeChange = useCallback(
    debounce(value => {
      firestore.update(path_profile, { expiration_notice: value });
    }, 999), []);

  return (
    <>
      {loading && <LoadingSpinner />}
      <ToastNotification show={showError} onHide={hideError} />
      <ToastNotification show={showReAuth} onHide={hideReAuth} bg='info' delay={10000} text='Must attempt account deletion within 4 minutes of logging in.' />

      <div className='mx-auto vstack gap-4 mt-5'>
        <div className='vstack text-center'>
          <span className='my-2 fs-5'>Share my Pantry</span>
          <QRCode size={128} value={profile.dataId} className='mx-auto' />
        </div>

        <hr className='mx-auto w-100' style={{ maxWidth: '96px' }} />

        <div className='position-relative p-4 mx-auto vstack gap-4' style={{ maxWidth: '36rem' }}>

          <ToggleButton type='checkbox' value={1} variant='outline-primary' checked={profile.expiration_notification} onClick={toggleExpirationNotification}>
            Expiration Notifications
            <span className='ms-2 fw-bold'>{ profile.expiration_notification ? 'On' : 'Off' }</span>
          </ToggleButton>

          <div className='row row-cols-2 g-2'>
            <span className='col col-8 pt-1'>Notify days till expiration</span>
            <div className='col col-4'>
              <NumericStepper
                size='xsm'
                thumbColor='#DC8B32'
                activeButtonColor='rgba(108 117 125, .1)'
                inactiveIconColor='#adadad'
                inactiveTrackColor='rgba(108 117 125, .1)'
                activeTrackColor='#adadad'
                disabledIconColor='rgba(108 117 125, .1)'
                hoverIconColor='rgba(108 117 125, .1)'
                initialValue={profile.expiration_notice ?? 4}
                minimumValue={0}
                maximumValue={99}
                thumbShadowAnimationOnTrackHoverEnabled={false}
                onChange={expirationNoticeChange}
              />
            </div>
          </div>

        </div>

        <hr className='mx-auto w-100' style={{ maxWidth: '96px' }} />

        <span className='text-center'>
          Delete Account&emsp;
          {!showConfirm && (
            <Button variant='primary' onClick={confirm}>
              Delete
            </Button>
          )}
          {showConfirm && (
            <Button variant='danger' onClick={deleteAccount}>
              Confirm
            </Button>
          )}
        </span>
      </div>
    </>
  );
}
