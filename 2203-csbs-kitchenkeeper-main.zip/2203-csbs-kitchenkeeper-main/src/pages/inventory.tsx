import { useState, useEffect } from 'react';
import { Button, ButtonGroup, Dropdown } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPlus, faFilter, faEllipsisVertical } from '@fortawesome/free-solid-svg-icons';
import { IProducts, IProduct, IOrderedProduct, ProductFilters, DefaultProductFilters, DefaultProduct, IDisplayProductsExtended, IScannerProducts } from '../objects/Product';
import { IProfile } from '../objects/Profile';
import { Locations, filter, e_scroll } from '../objects/types';
import { useSelector } from 'react-redux';
import { useFirestore, ReduxFirestoreQuerySetting, OrderByOptions, WhereOptions } from 'react-redux-firebase';
import LoadingSpinner from '../Components/loadingSpinner';
import ItemCard, { CardColor, PItemCard } from '../Components/ItemCard';
import InventorySearch from '../Components/InventorySearch';
import ScannerModal from '../Components/Modals/ScannerModal';
import ProductDetailsModal from '../Components/Modals/ProductDetailsModal';
import { ToastNotification } from '../Components/ToastNotification';
import { SortIndicator } from '../Components/SortIndicator';
import { increment } from 'firebase/firestore';
import { EllipsisDropdown } from '../Components/EllipsisDropdown';

export default function Inventory() {
  const firestore = useFirestore();
  const firestoreProducts = useSelector((state: any) => state.firestore.ordered.products);
  const firestoreSearchResults = useSelector((state: any) => state.firestore.ordered.InventorySearchResults);
  const profile = useSelector((state: any) => state.firebase.profile as IProfile);
  const path: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'products' }] };
  const [products] = useState<IProducts>(new Map());
  const [searchProducts] = useState<IProducts>(new Map());
  const [recentProducts, setRecentProducts] = useState<IDisplayProductsExtended>(new Map());
  const [filters, setFilters] = useState<ProductFilters>(DefaultProductFilters);
  const [modalProduct, setModalProduct] = useState<IProduct>(DefaultProduct);
  const [modalUpc, setModalUpc] = useState('');
  const [detailsEditState, setDetailsEditState] = useState(false);
  const [detailsState, setDetailsState] = useState(false);
  const [scannerState, setScannerState] = useState(false);
  const [searchState, setSearchState] = useState(false);
  const [errorState, setErrorState] = useState(false);
  const [loading, setLoading] = useState(false);
  const [more, setMore] = useState(true);
  const [fetchCount, setFetchCount] = useState(0);
  const [loadCount, setLoadCount] = useState(0);
  const [searchCount, setSearchCount] = useState(0);
  const [stepCount, setStepCount] = useState(0);

  useEffect(() => {
    if (fetchCount === 0) fetchProducts(true);
    if (!firestoreProducts || loadCount === fetchCount) return;
    setMore(firestoreProducts.length >= step);
    firestoreProducts.forEach((product: IOrderedProduct) => products.set(product.id, product));
    setLoadCount(loadCount + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firestoreProducts]);

  useEffect(() => {
    searchProducts.clear();
    if (!firestoreSearchResults) return setSearchCount(searchCount + 1);
    firestoreSearchResults.forEach((product: IOrderedProduct) => searchProducts.set(product.id, product));
    setSearchCount(searchCount + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [firestoreSearchResults]);

  const viewW = window.innerWidth;
  const viewH = window.innerHeight;

  const countW = Math.floor(viewW / 350);
  const countH = Math.floor(viewH / 105);

  const step = Math.floor(countW * countH);

  const fetchProducts = async (start?: boolean) => {
    if (searchState || !more || fetchCount > loadCount) return;
    setFetchCount(fetchCount + 1);
    setLoading(true);
    const lastDoc: IProduct = firestoreProducts ? firestoreProducts.at(-1) : undefined;
    const fetchAfter = lastDoc ? [lastDoc.product_name] : undefined;
    const query = {
      ...path,
      storeAs: 'products',
      startAfter: start ? undefined : fetchAfter,
      limit: step,
      orderBy: buildOrderBy(),
      where: buildWhere(),
    };
    await firestore.get(query);
    setLoading(false);
  };

  const buildOrderBy = (): OrderByOptions[] => {
    const options: OrderByOptions[] = [];
    if (filters.product_name.active) options.push(['product_name', filters.product_name.direction]);
    if (filters.package_count.active) options.push(['package_count', filters.package_count.direction]);
    if (filters.brand.active) options.push(['brand', filters.brand.direction]);
    if (filters.labels.active) options.push(['labels', filters.labels.direction]);
    if (filters.expirations.active) options.push(['expirations', filters.expirations.direction]);
    return !!options.length ? options : [['product_name', 'desc']];
  };

  const buildWhere = (): WhereOptions | undefined => {
    if (filters.location === 'All') return undefined;
    return ['location', '==', filters.location];
  };

  const handleScroll = (e: e_scroll) => {
    const containerHeight = e.currentTarget.clientHeight;
    const scrollHeight = e.currentTarget.scrollHeight;
    const scrollTop = e.currentTarget.scrollTop;
    if ((scrollTop + containerHeight) / scrollHeight >= 0.9) fetchProducts();
  };

  const clearRecentProducts = () => setRecentProducts(new Map());
  const removeProduct = (key: string) => {
    products.delete(key);
    recentProducts.delete(key);
  }
  
  const toggleSearchState = (state?: boolean) => setSearchState(state ?? !searchState);
  const pushUpdate = (id: string, update: any) => firestore.update({ ...path, subcollections: [{ collection: 'products', doc: id }] }, update);
  const updateFilters = (filter: filter) => setFilters({ ...filters, [filter.key]: filter });
  const showScanner = () => setScannerState(true);
  const hideScanner = () => setScannerState(false);

  const reloadProducts = () => {
    products.clear();
    searchProducts.clear();
    setFetchCount(0);
    setLoadCount(0);
    setSearchCount(0);
    setMore(true);
    fetchProducts(true);
  };

  const hideDetails = () => {
    setDetailsState(false);
    setDetailsEditState(false);
    setDetailsState(false);
    setModalUpc('');
    setModalProduct(DefaultProduct);
  };

  const viewProduct = (upc: string) => {
    const product = products.get(upc);
    const recentProduct = recentProducts.get(upc);
    if (!product && !recentProduct)
      return setErrorState(true);
    if (product)
      setModalProduct(product);
    else if (recentProduct)
      setModalUpc((recentProduct.code)!);
    setDetailsState(true);
  };

  const manualEntry = () => {
    setModalProduct(DefaultProduct);
    setDetailsEditState(true);
    setDetailsState(true);
  };

  const stepperChange_existing = (value: number, key: string) => {
    const product = products.get(key);
    const recentProduct = recentProducts.get(key);
    if (!product && !recentProduct) return setErrorState(true);
    if (product) products.set(key, { ...product, package_count: value });
    if (recentProduct && recentProduct.badge !== 'scan') recentProducts.set(key, { ...recentProduct, package_count: value });
    pushUpdate(key, { package_count: value });
    setStepCount(stepCount + 1);
  };

  const stepperChange_recent = (value: number, key: string) => {
    const product = products.get(key);
    const recentProduct = recentProducts.get(key);
    if (!product && !recentProduct) return setErrorState(true);
    if (product) products.set(key, { ...product, package_count: product.package_count + value });
    if (recentProduct) recentProducts.set(key, { ...recentProduct, package_count: recentProduct.package_count + value });
    pushUpdate(key, { package_count: increment(value) });
    setStepCount(stepCount + 1);
  };

  const saveProductDetails = (product: IProduct) => {
    const existingProduct = products.get(product.code);
    const recentProduct = recentProducts.get(product.code);
    if (existingProduct) products.set(product.code, product);
    if (recentProduct) recentProducts.set(product.code, { ...product, badge: 'edited' });
    if (!existingProduct && !recentProduct) {
      recentProducts.set(product.code, { ...product, badge: 'new' });
      if (!more) products.set(product.code, product);
    }
  };

  const saveScannedProducts = (scannedProducts: IScannerProducts) => {
    scannedProducts.forEach(product => {
      recentProducts.set(product.code, { ...product, badge: product.new ? 'new' : 'scan' });
      delete product.new;
      delete product.saved;
      const existingProduct = products.get(product.code);
      if (existingProduct) products.set(existingProduct.code, {...existingProduct, package_count: existingProduct.package_count + product.package_count });
      if (!existingProduct && !more) products.set(product.code, product);
    });
  };

  const recentCards: JSX.Element[] = [];
  const productCards: JSX.Element[] = [];

  const badgBgColors = new Map<string, CardColor>([['new', CardColor.success], ['edited', CardColor.primary], ['scan', CardColor.info], ['recent', CardColor.primary]]);

  // Show recent scans at top
  if (!searchState) {
    recentProducts.forEach((product, key) => {
      const amount = product.package_size && product.package_count > 0 ? parseInt(product.package_size) * product.package_count : undefined;
      const cardProps: PItemCard = {
        title: product.product_name,
        img: product.image_url,
        onClick: () => viewProduct(key),
        badge: {
          bg: badgBgColors.get(product.badge ?? '') ?? CardColor.danger,
          text: product.badge ?? 'NA',
        },
        stepper: {
          value: product.package_count,
          onChange_Amount: (value) => stepperChange_recent(value, key),
          valueOverride: product.package_count,
        },
        subDisplayValue: amount,
        subDisplayValueUnit: amount ? product.package_size_unit : undefined,
        ...( product.badge === 'scan' ? 
          { thumb: { bg: CardColor.info, valuePrefix: '+' } } :
          product.badge === 'new' ?
          { thumb: { bg: CardColor.success } } :
          { }      
        )
      }
      recentCards.push(
        <ItemCard
          key={'recent-' + product.badge + key}
          {...cardProps}
        />
      );
    });
  }

  // Assemble product cards from search or products
  (searchState ? searchProducts : products).forEach((product, key) => {
    const amount = product.package_size && product.package_count > 0 ? parseInt(product.package_size) * product.package_count : undefined;
    productCards.push(
      <ItemCard
        key={key}
        title={product.product_name}
        img={product.image_url}
        onClick={() => viewProduct(key)}
        stepper={{
          value: product.package_count,
          onChange_Total: (value) => stepperChange_existing(value, key),
          valueOverride: product.package_count,
        }}
        subDisplayValue={amount}
        subDisplayValueUnit={amount ? product.package_size_unit : undefined}
      />
    );
  });

  return (
    <>
      <ScannerModal path={path} show={scannerState} onHide={hideScanner} resultCallback={saveScannedProducts} />
      <ProductDetailsModal path={path} show={detailsState} edit={detailsEditState} onHide={hideDetails} onRemove={removeProduct} upc={modalUpc} fetch={!!modalUpc} onSave={saveProductDetails} product_data={modalProduct} />

      <ToastNotification show={errorState} onHide={() => setErrorState(false)} />

      <div id='inventory-topbar' className='d-flex align-content-start justify-content-between flex-nowrap gap-3 py-2 position-fixed top-0 text-nowrap shadow-sm w-100 bg-white' style={{ zIndex: 5 }}>

        <div className='d-flex gap-3 ms-5'>
          <Dropdown autoClose='outside' className='d-none d-sm-block'>
            <Dropdown.Toggle variant='secondary'>
              <FontAwesomeIcon icon={faFilter} />
            </Dropdown.Toggle>
            <Dropdown.Menu variant='dark'>
              {Object.entries(filters).map(
                ([key, filter]) =>
                  key !== 'location' && (
                    <Dropdown.Item key={'filter-' + key}>
                      <SortIndicator filter={filter} setFilter={updateFilters} />
                    </Dropdown.Item>
                  )
              )}

              <Dropdown.Divider />

              <Dropdown>
                <Dropdown.Toggle variant='' size='sm' className='w-100 text-white border-0'>
                  {filters.location}&nbsp;
                </Dropdown.Toggle>
                <Dropdown.Menu variant='dark'>
                  {Object.values(Locations).map((location) => (
                    <Dropdown.Item key={'filter-' + location} onClick={() => setFilters({ ...filters, location: location })}>
                      {location}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>

              <Dropdown.Divider />

              <Dropdown.Item>
                <Button
                  variant='primary'
                  size='sm'
                  className='w-100'
                  onClick={(e: any) => {
                    e.stopPropagation();
                    reloadProducts();
                  }}>
                  Apply Filters
                </Button>
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>

          <span className='vr d-none d-sm-block' />

          <InventorySearch path={path} isActive={toggleSearchState} />
        </div>

        <div className='me-5 d-none d-sm-block'>
          <Dropdown as={ButtonGroup}>
            <Button variant='primary' className='d-none d-md-block' onClick={showScanner}>
              <FontAwesomeIcon icon={faPlus} />
              <span className='ps-2'>Add Product</span>
            </Button>
            <Button variant='primary' className='d-sm-block d-md-none rounded-start' onClick={showScanner}>
              <FontAwesomeIcon icon={faPlus} />
            </Button>

            <Dropdown.Toggle split variant='primary' />

            <Dropdown.Menu variant='dark'>
              <Dropdown.Item onClick={manualEntry}>Manual Entry</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>

        <Dropdown className='d-sm-none' autoClose='outside'>
          <Dropdown.Toggle as={EllipsisDropdown}>
            <FontAwesomeIcon className='mx-auto fs-5' icon={faEllipsisVertical} />
          </Dropdown.Toggle>

          <Dropdown.Menu variant='dark'>
            <Dropdown.Item className='bg-primary' onClick={showScanner}>
              <FontAwesomeIcon icon={faPlus} />
              <span className='ps-2'>Add Product</span>
            </Dropdown.Item>
            <Dropdown.Item onClick={manualEntry}>
              <span className='ps-2'>Manual Entry</span>
            </Dropdown.Item>

            <Dropdown.Divider />

            {Object.entries(filters).map(
                ([key, filter]) =>
                  key !== 'location' && (
                    <Dropdown.Item key={'filter-' + key}>
                      <SortIndicator filter={filter} setFilter={updateFilters} />
                    </Dropdown.Item>
                  )
              )}

              <Dropdown.Divider />

              <Dropdown>
                <Dropdown.Toggle variant='' size='sm' className='w-100 text-white border-0'>
                  {filters.location}&nbsp;
                </Dropdown.Toggle>
                <Dropdown.Menu variant='dark'>
                  {Object.values(Locations).map((location) => (
                    <Dropdown.Item key={'filter-' + location} onClick={() => setFilters({ ...filters, location: location })}>
                      {location}
                    </Dropdown.Item>
                  ))}
                </Dropdown.Menu>
              </Dropdown>

              <Dropdown.Divider />

              <Dropdown.Item>
                <Button
                  variant='primary'
                  size='sm'
                  className='w-100'
                  onClick={(e: any) => {
                    e.stopPropagation();
                    reloadProducts();
                  }}>
                  Apply Filters
                </Button>
              </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>

      </div>

      <div onScroll={handleScroll} className='d-flex align-content-start justify-content-evenly flex-wrap gap-3 overflow-auto position-absolute start-0 bottom-0 end-0 py-4 px-2' style={{ top: '54px' }}>
        {!!recentCards.length && (
          <div className='w-100'>
            <Button variant='close' className='float-end me-3' onClick={clearRecentProducts} />
          </div>
        )}
        {recentCards}
        {!!recentCards.length && <hr className='rounded border border-2 border-white-200 bg-white-200 w-100' />}
        {productCards}
        {!productCards.length && searchState && <span className='text-muted fs-5'>No matching products found</span>}
        {!productCards.length && !recentCards.length && !searchState && <span className='text-muted fs-5'>No products found</span>}
        {loading && <LoadingSpinner />}
      </div>
    </>
  );
}
