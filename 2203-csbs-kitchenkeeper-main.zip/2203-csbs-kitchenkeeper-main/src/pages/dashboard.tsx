import moment from 'moment';
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { DragDropContext, DropResult } from 'react-beautiful-dnd';
import { ReduxFirestoreQuerySetting, useFirestore, useFirestoreConnect } from 'react-redux-firebase';
import { buildUpdateFromMove } from '../Components/MealsComponents/helpers';
import Row from '../Components/MealsComponents/Row';
import Suggested from '../Components/RecipeComponents/Suggested';
import { MealsConverter } from '../helpers/converters';
import { IMealsData } from '../objects/Meals';
import { Days } from '../objects/types';

export default function Dashboard() {
  const firestore = useFirestore();
  const profile = useSelector((state: any) => state.firebase.profile);
  const weekId = moment().startOf('week').format('YYYYMD').toString();
  const docPath: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'meals', doc: weekId }] };
  useFirestoreConnect({ ...docPath, storeAs: 'meals' });
  const firestoreMeals = useSelector((state: any) => state.firestore.data.meals);
  const [data, setData] = useState<IMealsData>(new Map());
  
  useEffect(() => {
    if (firestoreMeals)
      setData(MealsConverter.fromFirestore(firestoreMeals));
  }, [firestoreMeals]);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;
    const update = buildUpdateFromMove(data, result);
    if (!update) return;
    firestore.update(docPath, MealsConverter.toFirestore(update));
    setData(new Map([...data, ...(update as IMealsData)]));
  };

  return (
    <>
      <h3 className='text-muted mt-5 mb-0 ms-5'>Todays Meal Plan</h3>
      <DragDropContext onDragEnd={handleDragEnd}>
        <Row rowId={moment().format('dddd') as Days} data={data} docPath={docPath} isOnly />
      </DragDropContext>

      <h3 className='text-muted mt-5 mb-2 ms-5'>Suggested Recipes</h3>
      <Suggested />
    </>
  );
}
