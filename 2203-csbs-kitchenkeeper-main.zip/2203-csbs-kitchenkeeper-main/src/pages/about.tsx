import React from 'react';
import { Accordion } from 'react-bootstrap';

export default function About() {
  return (
    <>
      <div className='mx-auto px-3 text-center pt-5' style={{ maxWidth: '500px' }}>

        <h1 className='about-header'>Kitchen Keeper</h1>
        
        <p className='about-para'>
          An easy, automated, and intelligent food management system
        </p>

        <h3 className='about-header'>Our Mission</h3>

        <p className='about-para'>
          Deliver intelligent solutions for everyday tasks.
        </p>

        <h3 className='about-header'>Team Publish or Bust</h3>

        <p className='about-para'>
          We are a small team of developers working on our Capstone Project while
          attending Full Sail University.
        </p>

        <img src='./Lord.png' alt='' className='shadow rounded-circle' style={{ width: '200px' }}/>

        <br />
        <br />

        <Accordion flush>
          <Accordion.Item eventKey='0'>
            <Accordion.Header><div className='accordion-header-center'>Cody Dodson</div></Accordion.Header>
            <Accordion.Body>
                Cody is a software engineer located in Idaho.
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <br />
        <br />
        <br />

        <img src='./Ash.svg' alt='' className='shadow rounded-circle' style={{ width: '200px' }}/>

        <br />
        <br />
        
        <Accordion flush>
          <Accordion.Item eventKey='0'>
            <Accordion.Header><div className='accordion-header-center'>Ashleigh Jacobs</div></Accordion.Header>
            <Accordion.Body>
              Ashleigh is a software engineer at CoreLogic located in Birmingham, UK. 
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <br />
        <br />
        <br />

        <img src='./Brian.svg' alt='' className='shadow rounded-circle' style={{ width: '200px' }}/>

        <br />
        <br />
        
        <Accordion flush>
          <Accordion.Item eventKey='0'>
            <Accordion.Header><div className='accordion-header-center'>Brian DeGuire</div></Accordion.Header>
            <Accordion.Body>
              Brian is a software engineer and full stack developer located Wisconsin.
            </Accordion.Body>
          </Accordion.Item>
        </Accordion>

        <br />

      </div>
    </>
    
  );
}
