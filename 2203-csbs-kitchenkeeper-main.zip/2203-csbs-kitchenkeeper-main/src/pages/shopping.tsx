import { useState, useEffect } from 'react';
import { Button, ButtonGroup, Dropdown, FormControl, InputGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRefresh, faDoorOpen, faClipboard, faSearch, faTimes, faEllipsisVertical } from '@fortawesome/free-solid-svg-icons';
import { IOrderedProduct, IShoppingProducts, IProducts } from '../objects/Product';
import { IProfile } from '../objects/Profile';
import { useSelector } from 'react-redux';
import { useFirestore, ReduxFirestoreQuerySetting } from 'react-redux-firebase';
import LoadingSpinner from '../Components/loadingSpinner';
import ItemCard, { CardColor, PItemCard } from '../Components/ItemCard';
import { ToastNotification } from '../Components/ToastNotification';
import { e_change, e_key } from '../objects/types';
import fuzzysort from 'fuzzysort'
import NoteModal from '../Components/Modals/NoteModal';
import { nanoid } from 'nanoid';
import AddProductsModal from '../Components/Modals/AddProductsModal';
import moment from 'moment';
import { increment } from 'firebase/firestore';
import { useFirstMountState } from '../helpers/useFirstMount';
import { EllipsisDropdown } from '../Components/EllipsisDropdown';
import { FaCheck, FaRegMinusSquare, FaRegSquare } from 'react-icons/fa';

export const LOCALSTORAGE_SHOPPINGLIST = 'ShoppingList';

export default function Shopping() {
  const firestore = useFirestore();
  const shopping_inventory = useSelector((state: any) => state.firestore.ordered.shopping_inventory);
  const profile = useSelector((state: any) => state.firebase.profile as IProfile);
  const path: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'products' }] };
  const [shopping, setShopping] = useState<IShoppingProducts>(new Map());
  const [productsOptions, setProductOptions] = useState(false);
  const [noteOptions, setNoteOptions] = useState<{ note?: string, code: string } | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');
  const [highlight, setHighlight] = useState<string[]>([]);
  const [searchState, setSearchState] = useState(false);
  const [errorState, setErrorState] = useState(false);
  const [loading, setLoading] = useState(false);
  const [hasCompleted, setHasCompleted] = useState(false);
  const [isBuilt, setIsBuilt] = useState(false);
  const [preExisting, setPreExisting] = useState(false);
  const [hideComplete, setHideComplete] = useState(false);
  const firstMount = useFirstMountState();

  // Gets shopping from local cache
  useEffect(() => {
    const savedShopping = localStorage.getItem(LOCALSTORAGE_SHOPPINGLIST);
    if (!savedShopping) return;
    setShopping(new Map(JSON.parse(savedShopping)));
  }, []);

  // Saves shopping to local cache
  useEffect(() => {
    if (firstMount) return;
    cacheShopping();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shopping]);

  // shopping list expiration date
  useEffect(() => {
    if (!shopping_inventory || firstMount) return;
    shopping_inventory.forEach((product: IOrderedProduct) => {
      if (!product.desired_count) return;
      // Shopping list quantity
      let shopping_count = 0;
      // Find expiring products
      product.track_expiration && product.expirations?.forEach(expiration => {
        if (moment(expiration).diff(moment(), 'days') <= (profile.expiration_notice ?? 4))
          shopping_count++;
      });
      // Calculate Shopping list quantity
      shopping_count = product.track_expiration ?
        product.desired_count - (product.package_count - shopping_count) :
        product.desired_count - product.package_count;
      // Add product to shopping list if needed
      if (shopping_count > 0)
        shopping.set(product.id, {
          code: product.code,
          product_name: product.product_name,
          package_count: shopping_count,
          image_url: product.image_url,
          location: product.location
        });
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shopping_inventory]);

  // Gets products from cloud pantry that user wants to track
  const fetchPossibleShoppingFromInventory = async () => {
    const query: ReduxFirestoreQuerySetting = { collection: 'data', doc: profile.dataId, subcollections: [{ collection: 'products' }], storeAs: 'shopping_inventory', where: [[ 'desired_count', '>', 0 ]] };
    await firestore.get(query);
  };
  
  const buildShopping = async () => {
    setLoading(true);
    setIsBuilt(true);
    setHideComplete(false);
    clearHighlight();
    shopping.clear();
    await fetchPossibleShoppingFromInventory();
    // fetch products needed for meal plan
    setLoading(false);
    cacheShopping();
  };

  const cacheShopping = () => {
    setHasCompleted(false);
    localStorage.setItem(LOCALSTORAGE_SHOPPINGLIST, JSON.stringify(Array.from(shopping)));
    shopping.forEach(item => { if (item.complete) setHasCompleted(true); });
  };

  const showProducts = () => setProductOptions(true);
  const hideProducts = () => setProductOptions(false);
  const showNote = () => setNoteOptions({ code: nanoid() });
  const hideNote = () => setNoteOptions(undefined);
  const viewError = () => setErrorState(true);
  const clearHighlight = () => setHighlight([]);
  const toggleHideCompleted = () => setHideComplete(!hideComplete);
  const handleProductStepperChange = (value: number, code: string) => {
    const product = shopping.get(code);
    if (!product) return viewError();
    if (value <= 0) return removeProduct(code);
    shopping.set(code, {...product, package_count: value });
    setShopping(new Map([...shopping]));
  };

  const toggleProductComplete = async (code: string) => {    
    const product = shopping.get(code);
    if (!product) return viewError();
    setLoading(true);
    shopping.set(code, {...product, complete: !product.complete });
    if (product.package_count)
      await firestore.update(`data/${profile.dataId}/products/${code}`, { package_count: increment(!product.complete ? product.package_count : -product.package_count) });
    setShopping(new Map([...shopping]));
    setLoading(false);
    clearHighlight();
  };

  const removeProduct = (code?: string) => {
    if (!code) return viewError();
    shopping.delete(code);
    setShopping(new Map([...shopping]));
    setNoteOptions(undefined);
    clearHighlight();
  };

  const saveNote = (note: string) => {
    if (!noteOptions) return viewError();
    shopping.set(noteOptions?.code, { code: noteOptions.code, note: note });
    setShopping(new Map([...shopping]));
    setNoteOptions(undefined);
    clearHighlight();
  };

  const saveProducts = (products: IProducts) => {
    const newHighlights: string[] = [];
    products.forEach(product => {
      newHighlights.push(product.code);
      if (shopping.has(product.code)) return setPreExisting(true);
      shopping.set(product.code, {
        code: product.code,
        image_url: product.image_url,
        package_count: 1,
        location: product.location,
        product_name: product.product_name,
        complete: false
      });
    });
    hideProducts();
    setShopping(new Map([...shopping]));
    setHighlight(newHighlights);
  };

  const removeCompleted = () => {
    shopping.forEach(item => {
      if (item.complete) shopping.delete(item.code)
    });
    setShopping(new Map([...shopping]));
    clearHighlight();
  }

  const searchCallback = (query?: string) => {
    setSearchQuery(query ?? '');
    if (!query) return setSearchState(false);
    setSearchState(true);
    clearHighlight();
  };

  const fuzzyresults = fuzzysort.go(searchQuery, Array.from(shopping.values()), {
    threshold: -100, limit: 50, all: true,
    keys: ['product_name', 'desc'],
    scoreFn: a => Math.max(a[0]?a[0].score: -1000, a[1]?a[1].score-100: -1000)
  });
  
  const products = fuzzyresults.map(result => result.obj);

  const productCards: JSX.Element[] = [];

  products.forEach(product => {
    if (hideComplete && product.complete) return;
    const cardProps: PItemCard = product.note ? 
    { 
      note: product.note,
      onEdit: () => setNoteOptions({ code: product.code, note: product.note }),
      onClick: () => toggleProductComplete(product.code),
      borderColor: product.complete ? CardColor.success : undefined,
    } : {
      title: product.product_name,
      img: product.image_url,
      ...( product.complete ? { displayValue: product.package_count } : { stepper: {
        value: product.package_count!,
        onChange_Total: (value) => handleProductStepperChange(value, product.code),
      }}),
      thumb: { bg: product.complete ? CardColor.success : CardColor.primary },
      borderColor: product.complete ? CardColor.success : highlight.includes(product.code) ? CardColor.info : undefined,
      onClick: () => toggleProductComplete(product.code),
    }

    productCards.push(
      <ItemCard
        key={product.code + '-searchResult'}
        {...cardProps}
      />
    );
  });  

  return (
    <>
      <NoteModal show={!!noteOptions} onHide={hideNote} resultCallback={saveNote} note={noteOptions?.note} onRemove={() => removeProduct(noteOptions?.code)} />
      <AddProductsModal show={productsOptions} onHide={hideProducts} resultCallback={saveProducts} path={path} />
      <ToastNotification show={errorState} onHide={() => setErrorState(false)} />
      <ToastNotification show={preExisting} onHide={() => setPreExisting(false)} bg='info' text='Some products were already on your shopping list' />

      <div id='inventory-topbar' className='d-flex align-content-start justify-content-between flex-nowrap gap-3 py-2 position-fixed top-0 text-nowrap shadow-sm w-100 bg-white' style={{ zIndex: 5 }}>

        <ShoppingSearch className='ms-5' search={searchCallback} />

        <Dropdown className='d-sm-none'>
          <Dropdown.Toggle as={EllipsisDropdown} disabled={loading}>
            <FontAwesomeIcon className='mx-auto fs-5' icon={faEllipsisVertical} />
          </Dropdown.Toggle>

          <Dropdown.Menu variant='dark'>
            { hasCompleted && <> 
              <Dropdown.Item disabled={loading} onClick={toggleHideCompleted}>
                { hideComplete ? <FaCheck className='text-primary' /> : <FaRegSquare /> }
                <span className='ps-2'>Hide Competed</span>
              </Dropdown.Item>
              <Dropdown.Item disabled={loading} onClick={removeCompleted}>
                <FaRegMinusSquare />
                <span className='ps-2'>Remove Competed</span>
              </Dropdown.Item>
              <Dropdown.Divider /> 
            </> }
            <Dropdown.Item disabled={loading} onClick={showProducts}>
              <FontAwesomeIcon icon={faDoorOpen} />
              &nbsp;&nbsp; Add Product
            </Dropdown.Item>
            <Dropdown.Item disabled={loading} onClick={showNote}>
              <FontAwesomeIcon icon={faClipboard} />
              &nbsp;&nbsp; Add Note
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item disabled={loading} onClick={buildShopping}>
              <FontAwesomeIcon icon={faRefresh} />
              &nbsp;&nbsp; Refresh
            </Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>

        <div className='d-none d-sm-block'>
          <div className='me-5 hstack gap-3'>

            { hasCompleted && <Dropdown as={ButtonGroup}>
              <Button variant='primary' className='d-none d-lg-block' disabled={loading} onClick={toggleHideCompleted} data-bs-toggle='tooltip' title='Hide completed items'>
                { hideComplete ? <FaCheck className='svg-inline--fa' /> : <FaRegSquare className='svg-inline--fa' /> }
                <span className='ps-2'>Completed</span>
              </Button>
              <Button variant='primary' className='d-sm-block d-lg-none rounded-start' disabled={loading} onClick={toggleHideCompleted} data-bs-toggle='tooltip' title='Hide completed items'>
                { hideComplete ? <FaCheck className='svg-inline--fa' /> : <FaRegSquare className='svg-inline--fa' /> }
              </Button>

              <Dropdown.Toggle split variant='primary' />

              <Dropdown.Menu variant='dark'>
                <Dropdown.Item disabled={loading} onClick={removeCompleted} data-bs-toggle='tooltip' title='Remove completed items'>
                  <FaRegMinusSquare className='svg-inline--fa' />
                  <span className='ps-2'>Remove Completed</span>
                </Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown> }

            <ButtonGroup className='d-sm-block d-lg-none'>
              <Button variant='secondary' disabled={loading} onClick={showProducts} data-bs-toggle='tooltip' title='Add an Item'>
                <FontAwesomeIcon icon={faDoorOpen} />
              </Button>
              <Button variant='secondary' disabled={loading} onClick={showNote} data-bs-toggle='tooltip' title='Add a Note'>
                <FontAwesomeIcon icon={faClipboard} />
              </Button>
            </ButtonGroup>

            <ButtonGroup className='d-none d-lg-block'>
              <Button variant='secondary' disabled={loading} onClick={showProducts} data-bs-toggle='tooltip' title='Add an Item'>
                <FontAwesomeIcon icon={faDoorOpen} />
                <span className='ps-2'>Product</span>
              </Button>
              <Button variant='secondary' disabled={loading} onClick={showNote} data-bs-toggle='tooltip' title='Add a Note'>
                <FontAwesomeIcon icon={faClipboard} />
                <span className='ps-2'>Note</span>
              </Button>
            </ButtonGroup>

            <Button variant='secondary' disabled={loading} onClick={buildShopping}>
              <FontAwesomeIcon icon={faRefresh} />
            </Button>
          </div>
        </div>

      </div>

      <div className='d-flex align-content-start justify-content-evenly flex-wrap gap-3 overflow-auto position-absolute start-0 bottom-0 end-0 py-4' style={{ top: '54px' }}>
        { !shopping.size && !loading && !isBuilt && <Button variant='primary' onClick={buildShopping} className='d-block mx-auto mt-4 fw-bold' style={{ width: '16rem' }}>Generate Shopping List</Button> }
        { !shopping.size && !loading && !firstMount && isBuilt && <span className='text-muted fs-5'>You have everything you need!</span> }
        { !!shopping.size && !loading && !firstMount && !productCards.length && !searchState && <span className='text-muted fs-5'>You've completed your Shopping List!</span> }
        { !productCards.length && searchState && <span className='text-muted fs-5'>No results found</span> }
        { productCards }
        { loading && <LoadingSpinner /> }
      </div>
    </>
  );
}


export interface PShoppingSearch {
  search: (query?: string) => void;
  className?: string;
}

export function ShoppingSearch({ className, search }: PShoppingSearch) {
  const [searchText, setSearchText] = useState('');
  const [showClear, setShowClear] = useState(false);

  const clear = () => {
    setSearchText('');
    setShowClear(false);
    search();
  };

  const handleInputChange = (e: e_change) => {
    const txt = e.currentTarget.value;
    setSearchText(txt);
    setShowClear(!!txt.trim());
    if (!txt.trim()) clear();
  };

  const searchKeyDown = (e: e_key) => {
    if (e.key !== 'Enter') return;
    search(searchText);
  };

  return (
    <div className={className + ' position-relative'}>
      <InputGroup>
        <FormControl placeholder='Search...' aria-label='Search existing Pantry Items' onChange={handleInputChange} onKeyDown={searchKeyDown} value={searchText} />
        <Button variant='primary px-4' onClick={() => search(searchText)}>
          <FontAwesomeIcon icon={faSearch} />
        </Button>
      </InputGroup>

      {showClear && (
        <Button variant='' className='position-absolute top-0' style={{ right: '66px', zIndex: 5 }} onClick={clear}>
          <FontAwesomeIcon className='text-muted' icon={faTimes} />
        </Button>
      )}
    </div>
  );
}
