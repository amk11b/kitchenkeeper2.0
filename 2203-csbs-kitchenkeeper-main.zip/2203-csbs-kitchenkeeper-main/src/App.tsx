import './Custom.scss'
import './App.css';

import Layout from './pages/layout';
import Auth from './pages/auth';
import About from './pages/about';
import RequireUser from './Components/RequireUser';
import SetupUser from './Components/SetupUser';

import Inventory from './pages/inventory';
import Meals from './pages/meals';
import Shopping from './pages/shopping';
import Recipes from './pages/recipes';
import Dashboard from './pages/dashboard';
import Landing from './pages/landing';
import Settings from './pages/settings';
import Cuisine from './Components/RecipeComponents/Cuisine';
import Results from './Components/RecipeComponents/Results';
import Details from './Components/RecipeComponents/Details';

import { Route, Routes } from 'react-router-dom';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { isLoaded, isEmpty } from 'react-redux-firebase';

import { DEBUG } from './index';
import Suggested from './Components/RecipeComponents/Suggested';

// App Component
export default function App() {

  if (DEBUG) DebugLog(); // Log Debug stuff if running in dev environment

  return (
    <>      
      <Routes>
        <Route path='/' element={ <Layout /> }>

          {/* Component Testing Routes */}
          <Route caseSensitive={false} path='SetupUser' element={ <SetupUser /> } /> 
          
          {/* NON-AUTH PAGES */}
          <Route index element={<Landing /> } />
          <Route caseSensitive={false} path='about' element={<About /> } />
          <Route caseSensitive={false} path='login' element={<Auth /> } />
          <Route caseSensitive={false} path='register' element={<Auth /> } />
          
          {/* AUTH PAGES */}
          <Route caseSensitive={false} path='dashboard' element={ <RequireUser><Dashboard /></RequireUser> } />
          <Route caseSensitive={false} path='inventory' element={ <RequireUser><Inventory /></RequireUser> } />
          <Route caseSensitive={false} path='meals' element={ <RequireUser><Meals /></RequireUser> } />
          <Route caseSensitive={false} path='shopping' element={ <RequireUser><Shopping /></RequireUser> } />
          {/* <Route caseSensitive={false} path='recipes' element={ <RequireUser><Recipes /></RequireUser> } /> */}
          <Route caseSensitive={false} path='settings' element={ <RequireUser><Settings /></RequireUser> } />
          
          <Route caseSensitive={false} path='recipes' element={ <RequireUser><Recipes /></RequireUser> }>
            <Route caseSensitive={false} path='suggested' element={ <RequireUser><Suggested /></RequireUser> } />
            <Route caseSensitive={false} path='cuisine/:type' element={ <RequireUser><Cuisine /></RequireUser> } />
            <Route caseSensitive={false} path='results/:search' element={ <RequireUser><Results /></RequireUser> } />
            <Route caseSensitive={false} path='details/:id' element={ <RequireUser><Details /></RequireUser> } />
          </Route>
          
        </Route>
      </Routes>
    </>
  );
}

// Logs data as it changes - Does not log when deployed
function DebugLog() {
  const profile = useSelector((state: any) => state.firebase.profile);
  const auth = useSelector((state: any) => state.firebase.auth);

  const state = useSelector((state: any) => state);

  useEffect(() => {
    if (isLoaded(auth) && !isEmpty(auth)) {
      console.log('User ID: ', auth.uid);
      console.log('User Data: ', auth);
    }
  }, [auth]);

  useEffect(() => {
    console.log('Profile: ', profile);
    console.log('Data Id: ', profile.dataId);
  }, [profile]);

  useEffect(() => {
    console.log('Data', state.firestore.data);
  }, [state.firestore.data]);

  useEffect(() => {
    console.log('Ordered', state.firestore.ordered);
  }, [state.firestore.ordered]);
}