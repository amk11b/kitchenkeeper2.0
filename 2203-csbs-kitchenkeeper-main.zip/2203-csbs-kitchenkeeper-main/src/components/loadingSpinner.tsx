import { CSSProperties } from 'react';
import { ScaleLoader } from 'react-spinners';

export interface PLoadingSpinner {
  style?: CSSProperties | undefined;
}

// Simple loading spinner of sorts
export default function LoadingSpinner({ style }: PLoadingSpinner) {
  return (
    <div className='position-absolute start-50 top-50 translate-middle' style={{ zIndex: 4, ...style }}>
      <ScaleLoader color='#DC8B32' loading={true} />
    </div>
  );
}
