import { IProducts, IProductsUpdate, IScannerProduct } from '../objects/Product';
import { IMealsData, IMealsUpdate } from '../objects/Meals';
import { IRecipe, IDisplayRecipe } from '../objects/Recipe';

export const ProductsConverter = {
  toFirestore: (data: IProducts | IProductsUpdate) => {
    return Object.fromEntries(data);
  },
  fromFirestore: (data: any) => {
    return new Map(Object.entries(data)) as IProducts;
  }
}

export const ProductConverter = {
  toFirestore: (data: IScannerProduct) => {
    return {...data};
  },
  fromFirestore: (data: any) => {
    return ({
      code: data.code,
      offid: data.offid,
      tags: data.tags,
      product_name: data.product_name,
      package_size: data.package_size,
      package_size_unit: data.package_size_unit,
      package_count: data.package_count,
      image_url: data.image_url,
      categories: data.categories,
      brand: data.brand,
      image_ingredients_url: data.image_ingredients_url,
      ingredients: data.ingredients,
      traces: data.traces,
      labels: data.labels,
      expirations: data.expirations,
      location: data.location,
      track_expiration: data.track_expiration,
      keywords: data.keywords 
    });
  }
}

export const ScannerProductConverter = {
  toFirestore: (data: IScannerProduct) => {
    return {...data};
  },
  from: (data: any) => {
    return ({
      code: data.code,
      product_name: data.product_name,
      package_count: data.package_count,
      image_url: data.image_url,
      package_size: data.package_size,
      package_size_unit: data.package_size_unit,
      expirations: data.expirations,
      ...(data.new ? { new: data.new } : undefined),
      ...(data.source ? { source: data.source } : undefined),
    });
  }
}

export const MealsConverter = {
  toFirestore: (data: IMealsData | IMealsUpdate) => {
    return Object.fromEntries(data);
  },
  fromFirestore: (data: any) => {
    return new Map(Object.entries(data)) as IMealsData;
  }
}

export const RecipeToDisplay = (recipe: IRecipe): IDisplayRecipe => ({ 
  id: recipe.id, 
  title: recipe.title, 
  image: recipe.image, 
  servings: recipe.servings, 
  multiplier: recipe.multiplier ?? recipe.servings
});