import convert from 'convert-units';
import { simplifiedUnits } from '../objects/types';

export const rng16 = () => '000000' + Math.floor(Math.random() * 899999 + 1000000000);

export const cleanStr = (str: string) => str.replace(/(<([^>]+)>)/gi, ' ');

export const units = {
  all: simplifiedUnits,
  mass: () => convert().possibilities('mass'),
  volume: () => convert().possibilities('volume'),
  metric: {
    mass: () => convert().list('mass').map( unit => unit.system === 'metric' ? unit.abbr : undefined),
    volume: () => convert().list('volume').map( unit => unit.system === 'metric' ? unit.abbr : undefined)
  },
  imperial: {
    mass: () => convert().list('mass').map( unit => unit.system === 'imperial' ? unit.abbr : undefined),
    volume: () => convert().list('volume').map( unit => unit.system === 'imperial' ? unit.abbr : undefined)
  }
}