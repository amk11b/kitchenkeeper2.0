# 2203-csbs-kitchenkeeper
Kitchen Keeper application for CSBS

This is a kitchen inventory tracking web app, built with React Typescript. This app provides users with a smart inventory tracking system. It also gives users the ability to create a Meal Plan and search for Recipes. 


## What you need to know...

In the project directory, you can run:

### `npm i`
To install node_modules.

### `firebase deploy --project kitchenkeeper-dev`
Deploys the contents of the build dir to firebase hosting services
Open [https://kitchenkeeper-dev.web.app](https://kitchenkeeper-dev.web.app) to view it in your browser.


This project requires your own .env file in the root. Without the .env file, this project won't function. it holds API keys & tokens:
REACT_APP_FIREBASE_APIKEY=
REACT_APP_APPCHECK_TOKEN=
REACT_APP_SPOONACULAR_APIKEY=

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

Dashboard - Today's Meal Plan and Suggested Recipes
![image](https://user-images.githubusercontent.com/65096932/177838198-61f3d244-91eb-42b3-b3e8-b12b8fc406fb.png)

Meal Plan - Create a Meal Plan for each week and review previous plans
![image](https://user-images.githubusercontent.com/65096932/177838895-5c10c184-d73d-4d75-8c65-672ae4ada9e8.png)

Recipe Search - Search for recipes with keywords with over 200k recipes that include ingredients and instructions
![image](https://user-images.githubusercontent.com/65096932/177839517-b4007ab5-8dd7-492a-89e8-c13ed6aa247a.png)

Contributors: Ashley Jacobs, Brian DeGuire, & Cody Dodson
